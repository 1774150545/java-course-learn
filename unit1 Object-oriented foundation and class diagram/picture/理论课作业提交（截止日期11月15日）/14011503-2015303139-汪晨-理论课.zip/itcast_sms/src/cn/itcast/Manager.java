package cn.itcast;

/**
 * ����Ա��
 * 
 * @author Administrator
 * 
 */
public class Manager {
	
	public String username;
	public String password;
	
	public Manager() {
		username = "admin";
		password = "admin";
	}

	
}