import java.util.ArrayList;

/**
 * 
 */

/**
 * MetroLine������·��
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class MetroLine {
	private String code;
	private String firstTime;
	private String lastTime;
	private double length;
	private ArrayList<MetroStation> stations;
	private static final String NEW_LINE = System.getProperty("line.separator");

	/**
	 * ���췽��
	 * 
	 * @param initialCode
	 * @param initialFirstTime
	 * @param initialLastTime
	 * @param initialLength
	 * @param initialStations
	 */
	public MetroLine(String initialCode, String initialFirstTime, String initialLastTime, double initialLength,
			ArrayList<MetroStation> initialStations) {
		code = initialCode;
		firstTime = initialFirstTime;
		lastTime = initialLastTime;
		length = initialLength;
		stations = initialStations;
	}

	/**
	 * ��ȡ��·��
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * ��ȡ�װ೵ʱ��
	 * 
	 * @return the firstTime
	 */
	public String getFirstTime() {
		return firstTime;
	}

	/**
	 * ��ȡĩ�೵ʱ��
	 * 
	 * @return the lastTime
	 */
	public String getLastTime() {
		return lastTime;
	}

	/**
	 * ��ȡ��·����
	 * 
	 * @return the length
	 */
	public double getLength() {
		return length;
	}

	/**
	 * ��ʽ�����������
	 * 
	 * @return
	 */
	public String fomatter() {
		String format = "��·��:" + getCode() + NEW_LINE + "�װ೵ʱ��: " + getFirstTime() + NEW_LINE + "ĩ�೵ʱ��: "
				+ getLastTime() + NEW_LINE + "��·����: " + getLength() + "km" + NEW_LINE + "********����·������վ����********"
				+ NEW_LINE;
		for (MetroStation station : stations) {
			format = format + station.getName() + NEW_LINE;
		}
		return format;
	}

}
