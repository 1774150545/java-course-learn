import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

/**
 * 
 */

/**
 * MetroStation����վ���� ʵ��Iterable<String>�ӿ�
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class MetroStation implements Iterable<String> {
	private String name;
	private String code;
	private String longitude;
	private String latitude;
	private boolean transforStation;
	private ArrayList<String> indexs;
	private static final String NEW_LINE = System.getProperty("line.separator");

	/**
	 * ���췽��
	 * 
	 * @param initialName
	 * @param initialCode
	 * @param initialLongitude
	 * @param initialLatitude
	 * @param initialTransforStation
	 * @param initialIndexs
	 */
	public MetroStation(String initialName, String initialCode, String initialLongitude, String initialLatitude,
			boolean initialTransforStation, ArrayList<String> initialIndexs) {
		name = initialName;
		code = initialCode;
		longitude = initialLongitude;
		latitude = initialLatitude;
		transforStation = initialTransforStation;
		indexs = initialIndexs;
	}

	/**
	 * ��ȡվ����
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * ��ȡվ����
	 * 
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * ��ȡվ�㾭��
	 * 
	 * @return the longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * ��ȡվ��γ��
	 * 
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * ��ȡ�Ƿ�Ϊ����վ
	 * 
	 * @return the transforStation
	 */
	public boolean isTransforStation() {
		return transforStation;
	}

	/**
	 * ��ʽ�����������
	 * 
	 * @return
	 * @throws DataFormatException
	 */
	public String fomatter() throws DataFormatException {
		String format = "վ��: " + getName() + NEW_LINE + "���: " + getCode() + NEW_LINE + "����: " + getLongitude()
				+ NEW_LINE + "γ��: " + getLatitude() + NEW_LINE + "�Ƿ񻻳�վ: " + String.valueOf(isTransforStation())
				+ NEW_LINE;
		for (String index : indexs) {
			StringTokenizer tokenizer = new StringTokenizer(index, "-");
			if (tokenizer.countTokens() != 2) {
				throw new DataFormatException(index);
			} else {
				format = format + "��վ��" + tokenizer.nextToken() + "���ߵĵ�" + tokenizer.nextToken() + "վ" + NEW_LINE;
			}
		}
		return format;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	/**
	 * �����������ת��Ϊ�ַ���
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name + code + longitude + latitude + transforStation + indexs;
	}

	/**
	 * ��дiterator()����
	 */
	@Override
	public Iterator<String> iterator() {
		// TODO Auto-generated method stub
		return indexs.iterator();
	}

}
