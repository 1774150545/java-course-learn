/**
 * 
 */

/**
 * CatalogĿ¼�ӿ�
 * 
 * @author Mr.hou
 * @version 1.0
 */
public interface Catalog {

}
