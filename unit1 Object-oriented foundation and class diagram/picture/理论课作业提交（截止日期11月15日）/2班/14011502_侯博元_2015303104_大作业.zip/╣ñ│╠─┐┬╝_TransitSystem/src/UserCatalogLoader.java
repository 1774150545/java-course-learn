import java.io.*;
import java.util.StringTokenizer;

/**
 * 
 */

/**
 * UserCatalogLoader�� ʵ��CatalogLoader�ӿ�
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class UserCatalogLoader implements CatalogLoader {
	private static final String USER_PREFIX = "User";
	private static final String NORMALCARD_PREFIX = "NormalCard";
	private static final String AGEDCARD_PREFIX = "AgedCard";
	private static final String STUDENTCARD_PREFIX = "StudentCard";
	private static final String DELIM = "_";
	private static final String SUB_DELIM = ",";

	/**
	 * ��дloadCatalog���� �����û�Ŀ¼
	 */
	@Override
	public UserCatalog loadCatalog(String fileName) throws FileNotFoundException, IOException, DataFormatException {
		// TODO Auto-generated method stub
		UserCatalog catalog = new UserCatalog();
		BufferedReader reader = new BufferedReader(new FileReader(fileName));
		String line = reader.readLine();
		while (line != null) {
			User user = null;
			if (line.startsWith(USER_PREFIX)) {
				user = readUser(line);
			} else {
				throw new DataFormatException(line);
			}
			catalog.addUser(user);
			line = reader.readLine();
		}
		return catalog;
	}

	/**
	 * ��ȡ�û�
	 * 
	 * @param line
	 * @return the user
	 * @throws DataFormatException
	 */
	private User readUser(String line) throws DataFormatException {
		StringTokenizer tokenizer = new StringTokenizer(line, DELIM);
		if (tokenizer.countTokens() != 5) {
			throw new DataFormatException(line);
		} else {
			try {
				String prefix = tokenizer.nextToken();
				String name = tokenizer.nextToken();
				String id = tokenizer.nextToken();
				String password = tokenizer.nextToken();
				String str_card = tokenizer.nextToken();
				Card card = readCard(str_card);
				return new User(name, id, password, card);
			} catch (NumberFormatException nfe) {
				throw new DataFormatException(line);
			}
		}
	}

	/**
	 * ��ȡ�û�һ��ͨ
	 * 
	 * @param str_card
	 * @return the card
	 * @throws DataFormatException
	 */
	private Card readCard(String str_card) throws DataFormatException {
		Card card = null;
		if (str_card.startsWith(NORMALCARD_PREFIX)) {
			card = readNormal(str_card);
		} else if (str_card.startsWith(AGEDCARD_PREFIX)) {
			card = readAged(str_card);
		} else if (str_card.startsWith(STUDENTCARD_PREFIX)) {
			card = readStudent(str_card);
		}
		return card;
	}

	/**
	 * ��ȡѧ����
	 * 
	 * @param str_card
	 * @return the studentCard
	 * @throws DataFormatException
	 */
	private StudentCard readStudent(String str_card) throws DataFormatException {
		// TODO Auto-generated method stub
		StringTokenizer tokenizer = new StringTokenizer(str_card, SUB_DELIM);
		if (tokenizer.countTokens() != 5) {
			throw new DataFormatException(str_card);
		} else {
			try {
				String prefix = tokenizer.nextToken();
				String code = tokenizer.nextToken();
				double balance = Double.parseDouble(tokenizer.nextToken());
				String studentCode = tokenizer.nextToken();
				boolean avalibility = Boolean.parseBoolean(tokenizer.nextToken());

				return new StudentCard(code, balance, studentCode, avalibility);
			} catch (NumberFormatException nfe) {
				throw new DataFormatException(str_card);
			}
		}
	}

	/**
	 * ��ȡ���꿨
	 * 
	 * @param str_card
	 * @return the agedCard
	 * @throws DataFormatException
	 */
	private AgedCard readAged(String str_card) throws DataFormatException {
		// TODO Auto-generated method stub
		StringTokenizer tokenizer = new StringTokenizer(str_card, SUB_DELIM);
		if (tokenizer.countTokens() != 5) {
			throw new DataFormatException(str_card);
		} else {
			try {
				String prefix = tokenizer.nextToken();
				String code = tokenizer.nextToken();
				double balance = Double.parseDouble(tokenizer.nextToken());
				String agedCode = tokenizer.nextToken();
				boolean avalibility = Boolean.parseBoolean(tokenizer.nextToken());

				return new AgedCard(code, balance, agedCode, avalibility);
			} catch (NumberFormatException nfe) {
				throw new DataFormatException(str_card);
			}
		}
	}

	/**
	 * ��ȡ��ͨ��
	 * 
	 * @param str_card
	 * @return the normalCard
	 * @throws DataFormatException
	 */
	private NormalCard readNormal(String str_card) throws DataFormatException {
		// TODO Auto-generated method stub
		StringTokenizer tokenizer = new StringTokenizer(str_card, SUB_DELIM);
		if (tokenizer.countTokens() != 3) {
			throw new DataFormatException(str_card);
		} else {
			try {
				String prefix = tokenizer.nextToken();
				String code = tokenizer.nextToken();
				double balance = Double.parseDouble(tokenizer.nextToken());
				return new NormalCard(code, balance);
			} catch (NumberFormatException nfe) {
				throw new DataFormatException(str_card);
			}
		}
	}

}
