import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * 
 */

/**
 * MetroLineCatalogLoader������·Ŀ¼������ ʵ��CatalogLoader�ӿ�
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class MetroLineCatalogLoader implements CatalogLoader {
	private static final String METROLINE_PREFIX = "MetroLine";
	private static final String DELIM = "_";
	private static final String SUB_DELIM = "/";

	@Override
	/**
	 * ��дloadCatalog()���� ����Ŀ¼
	 */
	public MetroLineCatalog loadCatalog(String fileName)
			throws FileNotFoundException, IOException, DataFormatException {
		// TODO Auto-generated method stub
		MetroLineCatalog catalog = new MetroLineCatalog();
		BufferedReader reader = new BufferedReader(new FileReader(fileName));
		String line = reader.readLine();
		while (line != null) {
			MetroLine metroLine = null;
			if (line.startsWith(METROLINE_PREFIX)) {
				metroLine = readMetroLine(line);
			} else {
				throw new DataFormatException(line);
			}
			catalog.addLine(metroLine);
			line = reader.readLine();
		}
		return catalog;
	}

	/**
	 * ��ȡ������·
	 * 
	 * @param line
	 * @return
	 * @throws DataFormatException
	 */
	private MetroLine readMetroLine(String line) throws DataFormatException {
		StringTokenizer tokenizer = new StringTokenizer(line, DELIM);
		if (tokenizer.countTokens() != 6) {
			throw new DataFormatException(line);
		} else {
			try {
				String prefix = tokenizer.nextToken();
				String code = tokenizer.nextToken();
				String firstTime = tokenizer.nextToken();
				String lastTime = tokenizer.nextToken();
				double length = Double.parseDouble(tokenizer.nextToken());
				String str_stations = tokenizer.nextToken();
				ArrayList<MetroStation> stations = readStation(str_stations);
				return new MetroLine(code, firstTime, lastTime, length, stations);
			} catch (NumberFormatException nfe) {
				throw new DataFormatException(line);
			}
		}
	}

	/**
	 * ��ȡ����վ��
	 * 
	 * @param str_stations
	 * @return
	 * @throws DataFormatException
	 */
	private ArrayList<MetroStation> readStation(String str_stations) throws DataFormatException {
		StringTokenizer tokenizer = new StringTokenizer(str_stations, SUB_DELIM);
		ArrayList<MetroStation> stations = new ArrayList<MetroStation>();
		MetroStationCatalogLoader read = new MetroStationCatalogLoader();
		while (tokenizer.hasMoreTokens()) {
			stations.add(read.readMetroStation(tokenizer.nextToken()));
		}
		return stations;
	}

}
