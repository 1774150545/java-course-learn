import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * 
 */

/**
 * CatalogLoader����Ŀ¼�ӿ�
 * 
 * @author Mr.hou
 * @version 1.0
 */
public interface CatalogLoader {
	public Catalog loadCatalog(String fileName) throws FileNotFoundException, IOException, DataFormatException;

}
