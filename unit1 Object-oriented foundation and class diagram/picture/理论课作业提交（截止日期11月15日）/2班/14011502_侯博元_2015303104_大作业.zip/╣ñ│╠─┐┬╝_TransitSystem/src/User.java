/**
 * 
 */

/**
 * User�û���
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class User {
	private String name;
	private String id;
	private String password;
	private Card card;

	/**
	 * ���췽��
	 * 
	 * @param initialName
	 * @param initialId
	 * @param initialPassword
	 * @param initialCard
	 */
	public User(String initialName, String initialId, String initialPassword, Card initialCard) {
		name = initialName;
		id = initialId;
		password = initialPassword;
		card = initialCard;

	}

	/**
	 * ��ȡ����
	 * 
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * ��������
	 * 
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * ��ȡ�û�����
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * ��ȡ�û�id
	 * 
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * ��ȡ�û���һ��ͨ
	 * 
	 * @return the card
	 */
	public Card getCard() {
		return card;
	}

	/**
	 * �����������ת��Ϊ�ַ���
	 */
	public String toString() {
		return "User_" + name + "_" + id + "_" + password + "_" + card.toString();
	}

}
