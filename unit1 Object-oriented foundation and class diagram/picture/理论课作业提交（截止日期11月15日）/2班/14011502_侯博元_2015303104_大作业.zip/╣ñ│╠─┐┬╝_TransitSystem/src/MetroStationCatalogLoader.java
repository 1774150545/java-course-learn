import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * 
 */

/**
 * MetroStationCatalogLoader����վ��Ŀ¼������ ʵ��CatalogLoader�ӿ�
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class MetroStationCatalogLoader implements CatalogLoader {
	private static final String METROSTATION_PREFIX = "MetroStation";
	private static final String DELIM = ",";
	private static final String SUB_DELIM = ".";

	/**
	 * ��дloadCatalog()���� ����Ŀ¼
	 */
	@Override
	public MetroStationCatalog loadCatalog(String fileName)
			throws FileNotFoundException, IOException, DataFormatException {
		// TODO Auto-generated method stub
		MetroStationCatalog catalog = new MetroStationCatalog();
		BufferedReader reader = new BufferedReader(new FileReader(fileName));
		String line = reader.readLine();
		while (line != null) {
			MetroStation station = null;
			if (line.startsWith(METROSTATION_PREFIX)) {
				station = readMetroStation(line);
			} else {
				throw new DataFormatException(line);
			}
			catalog.addStation(station);
			line = reader.readLine();
		}
		return catalog;
	}

	/**
	 * ��ȡ����վ��
	 * 
	 * @param line
	 * @return
	 * @throws DataFormatException
	 */
	public MetroStation readMetroStation(String line) throws DataFormatException {
		StringTokenizer tokenizer = new StringTokenizer(line, DELIM);
		if (tokenizer.countTokens() != 7) {
			throw new DataFormatException(line);
		} else {
			try {
				String prefix = tokenizer.nextToken();
				String name = tokenizer.nextToken();
				String code = tokenizer.nextToken();
				String longitude = tokenizer.nextToken();
				String latitude = tokenizer.nextToken();
				boolean transforStation = Boolean.parseBoolean(tokenizer.nextToken());
				String str_indexs = tokenizer.nextToken();
				ArrayList<String> indexs = readIndex(str_indexs);
				return new MetroStation(name, code, longitude, latitude, transforStation, indexs);
			} catch (NumberFormatException nfe) {
				throw new DataFormatException(line);
			}
		}
	}

	/**
	 * ��ȡ"��·_վ���"�б�
	 * 
	 * @param str_indexs
	 * @return
	 */
	private ArrayList<String> readIndex(String str_indexs) {
		ArrayList<String> indexs = new ArrayList<String>();
		StringTokenizer tokenizer = new StringTokenizer(str_indexs, SUB_DELIM);
		while (tokenizer.hasMoreTokens()) {
			indexs.add(tokenizer.nextToken());
		}
		return indexs;
	}

}
