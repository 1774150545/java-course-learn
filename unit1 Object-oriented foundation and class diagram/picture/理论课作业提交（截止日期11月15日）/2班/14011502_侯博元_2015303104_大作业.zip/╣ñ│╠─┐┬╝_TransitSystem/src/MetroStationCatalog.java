
/**
 * 
 */

import java.util.ArrayList;

/**
 * MetroStationCatalog����վ��Ŀ¼�� ʵ��Catalog�ӿ�
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class MetroStationCatalog implements Catalog {
	private ArrayList<MetroStation> metroStations;

	/**
	 * �޲������췽��
	 */
	public MetroStationCatalog() {
		metroStations = new ArrayList<MetroStation>();
	}

	/**
	 * ����վ��
	 * 
	 * @param station
	 */
	public void addStation(MetroStation station) {
		metroStations.add(station);
	}

	/**
	 * ͨ��վ��������վ��
	 * 
	 * @param name
	 * @return the station or null
	 */
	public MetroStation getStationByName(String name) {
		for (MetroStation station : metroStations) {
			if (station.getName().equals(name))
				return station;
		}
		return null;
	}

}
