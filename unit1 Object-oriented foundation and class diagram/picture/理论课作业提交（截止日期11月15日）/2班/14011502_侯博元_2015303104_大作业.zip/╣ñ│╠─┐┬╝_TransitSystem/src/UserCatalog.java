
/**
 * 
 */

import java.util.ArrayList;

/**
 * UserCatalog�� ʵ��Catalog�ӿ�
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class UserCatalog implements Catalog {
	private ArrayList<User> users;

	/**
	 * �޲������췽��
	 */
	public UserCatalog() {
		users = new ArrayList<User>();
	}

	/**
	 * �����û�
	 * 
	 * @param user
	 */
	public void addUser(User user) {
		users.add(user);
	}

	/**
	 * ͨ��id�����û�
	 * 
	 * @param id
	 * @return the user or null
	 */
	public User getUserById(String id) {
		for (User user : users) {
			if (user.getId().equals(id)) {
				return user;
			}
		}
		return null;
	}

}
