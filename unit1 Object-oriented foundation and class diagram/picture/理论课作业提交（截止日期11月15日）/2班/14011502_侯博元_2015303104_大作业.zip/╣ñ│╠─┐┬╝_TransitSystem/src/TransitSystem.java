import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/**
 * 
 */

/**
 * TransitSystem������ͨϵͳ��
 * 
 * @author Mr.hou
 * @version 1.0
 */
public class TransitSystem {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private static final String NEW_LINE = System.getProperty("line.separator");

	private UserCatalog userCatalog;
	private User currentUser;
	private MetroSystem metroSystem;

	/**
	 * ������
	 * 
	 * @param args
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws DataFormatException
	 */
	public static void main(String[] args) throws IOException, InterruptedException, DataFormatException {
		UserCatalog userCatalog = null;
		try {
			userCatalog = (new UserCatalogLoader()).loadCatalog("userCatalog.dat");
		} catch (FileNotFoundException fnfe) {
			stdErr.println("The file does not exist");

			System.exit(1);

		} catch (DataFormatException dfe) {
			stdErr.println("The file contains malformed data: " + dfe.getMessage());

			System.exit(1);
		}

		TransitSystem application = new TransitSystem(userCatalog);

		application.run();
	}

	/**
	 * ���췽��
	 * 
	 * @param initialUserCatalog
	 */
	private TransitSystem(UserCatalog initialUserCatalog) {

		this.userCatalog = initialUserCatalog;

	}

	/**
	 * �������߳�
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws DataFormatException
	 */
	private void run() throws IOException, InterruptedException, DataFormatException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				login();
			} else if (choice == 2) {
				regist();
			}
			choice = getChoice();
		}
	}

	/**
	 * ��ȡ������ͨϵͳ��һ���˵����û�ѡ��
	 * 
	 * @return the input
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private int getChoice() throws IOException, InterruptedException {

		int input;

		do {
			try {
				Thread.sleep(500);
				stdErr.println();
				stdErr.print("[0]  �˳�\n" + "[1]  ��¼\n" + "[2]  ע��\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 2 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	/**
	 * ��¼ϵͳ
	 * 
	 * @throws IOException
	 * @throws DataFormatException
	 * @throws InterruptedException
	 */
	private void login() throws IOException, DataFormatException, InterruptedException {
		stdOut.println("������id");
		String input_id = stdIn.readLine();
		stdOut.println("����������");
		String input_passworld = stdIn.readLine();
		User user = this.userCatalog.getUserById(input_id);
		if (user == null) {
			stdErr.println("id������");
		} else {
			String password = user.getPassword();
			if (!password.equals(input_passworld)) {
				stdErr.println("�˺����벻ƥ��");
			} else {
				currentUser = createCurrentUser(user);
				int choice = getChoice1();
				while (choice != 0) {
					if (choice == 1) {
						metroSystem = new MetroSystem(currentUser);
						metroSystem.run();
					} else if (choice == 2) {
						userInf();
					}
					choice = getChoice1();
				}
			}
		}
	}

	/**
	 * ע��ϵͳ
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void regist() throws IOException, InterruptedException {
		stdOut.println("***********ע��***********");
		stdOut.println("������������");
		String name = stdIn.readLine();
		stdOut.println("������id��");
		String id = stdIn.readLine();
		stdOut.println("���������룺");
		String password = stdIn.readLine();
		stdOut.println("***********��һ��ͨ***********");
		Card card = null;
		stdOut.println("��ѡ��һ��ͨ����");
		int choice = getTypeChoice();
		if (choice == 0) {
			card = bindingNoraml();
		} else if (choice == 1) {
			card = bindingStudent();
		} else if (choice == 2) {
			card = bindingAged();
		}
		User user = new User(name, id, password, card);
		userCatalog.addUser(user);
		String user_inf = user.toString();
		writeFile("userCatalog.dat", user_inf);
	}

	/**
	 * ���ļ���д������ ���ı��ļ��е�ԭ������
	 * 
	 * @param fileName
	 * @param content
	 * @throws IOException
	 */
	private void writeFile(String fileName, String content) throws IOException {
		PrintWriter writer = new PrintWriter(new FileWriter(fileName, true));
		BufferedReader reader = new BufferedReader(new FileReader(fileName));
		String data = reader.readLine();
		if (data != null) {
			writer.println("");
		}
		writer.print(content);
		writer.close();
	}

	/**
	 * ��ȡ��½��һ���˵����û�ѡ��
	 * 
	 * @return the input
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private int getChoice1() throws IOException, InterruptedException {

		int input;

		do {
			try {
				Thread.sleep(500);
				stdErr.println();
				stdErr.print("[0]  ����\n" + "[1]  �˳�\n" + "[2]  ������Ϣ\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 2 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	/**
	 * ��ȡ�û���һ��ͨ���͵�ѡ��
	 * 
	 * @return the input
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private int getTypeChoice() throws IOException, InterruptedException {

		int input;

		do {
			try {
				Thread.sleep(500);
				stdErr.println();
				stdErr.print("[0]  ��ͨ��\n" + "[1]  ѧ����\n" + "[2]  ���꿨\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 2 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	/**
	 * ����ͨ��
	 * 
	 * @return the mormalCard
	 * @throws IOException
	 */
	private NormalCard bindingNoraml() throws IOException {
		stdOut.println("�����뿨��");
		String code = stdIn.readLine();
		stdOut.println("���������");
		double balance = Double.parseDouble(stdIn.readLine());
		return new NormalCard(code, balance);
	}

	/**
	 * ��ѧ����
	 * 
	 * @return the studentCard
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private StudentCard bindingStudent() throws IOException, InterruptedException {
		do {
			try {
				stdOut.println("�����뿨��");
				String code = stdIn.readLine();
				stdOut.println("���������");
				double balance = Double.parseDouble(stdIn.readLine());
				stdOut.println("������ѧ��֤��");
				String studentCode = stdIn.readLine();
				stdOut.println("��ȷ���Ƿ�����Ч��");
				boolean avalibility = trueOrFalse();
				return new StudentCard(code, balance, studentCode, avalibility);
			} catch (NumberFormatException nfe) {
				stdErr.println("�������");
			}
		} while (true);
	}

	/**
	 * �����꿨
	 * 
	 * @return the adedCard
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private AgedCard bindingAged() throws IOException, InterruptedException {
		do {
			try {
				stdOut.println("�����뿨��");
				String code = stdIn.readLine();
				stdOut.println("���������");
				double balance = Double.parseDouble(stdIn.readLine());
				stdOut.println("����������֤��");
				String agedCode = stdIn.readLine();
				stdOut.println("��ȷ���Ƿ�����Ч��");
				boolean avalibility = trueOrFalse();
				return new AgedCard(code, balance, agedCode, avalibility);
			} catch (NumberFormatException nfe) {
				stdErr.println("�������");
			}
		} while (true);

	}

	/**
	 * �û�������Ϣѡ���Ӳ˵�
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void userInf() throws IOException, InterruptedException {
		int choice = getChoice12();

		while (choice != 0) {
			if (choice == 1) {
				showInf();
			} else if (choice == 2) {
				changePassword();
			}
			choice = getChoice12();
		}
	}

	/**
	 * ��ʾ�û�������Ϣ
	 */
	private void showInf() {
		stdOut.println("********���ĸ�����Ϣ*******");
		stdOut.println("����: " + currentUser.getName());
		stdOut.println("id:  " + currentUser.getId());
		stdOut.println("********����һ��ͨ��Ϣ*********");
		stdOut.println(currentUser.getCard().formatter());
	}

	/**
	 * ��ȡ�û����û�������Ϣѡ���Ӳ˵��е�ѡ��
	 * 
	 * @return the input
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private int getChoice12() throws IOException, InterruptedException {

		int input;

		do {
			try {
				Thread.sleep(500);
				stdErr.println();
				stdErr.print("[0]  ����\n" + "[1]  �鿴������Ϣ\n" + "[2]  �޸�����\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 2 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	/**
	 * ��������
	 * 
	 * @throws IOException
	 */
	private void changePassword() throws IOException {
		stdErr.println("�����������룺");
		String newPassword = stdIn.readLine();
		BufferedReader searchReader = new BufferedReader(new FileReader("userCatalog.dat"));
		String newFileContent = "";
		String searchLine = searchReader.readLine();
		while (searchLine != null) {
			if (searchLine.equals(currentUser.toString())) {
				currentUser.setPassword(newPassword);
				searchLine = currentUser.toString();
			}
			if (newFileContent != "") {
				newFileContent = newFileContent + NEW_LINE + searchLine;
			} else {
				newFileContent = searchLine;
			}
			searchLine = searchReader.readLine();
		}
		replaceFile("userCatalog.dat", newFileContent);
	}

	/**
	 * ���ļ���д����Ϣ ɾ��ԭ������
	 * 
	 * @param fileName
	 * @param content
	 * @throws IOException
	 */
	private void replaceFile(String fileName, String content) throws IOException {
		PrintWriter writer = new PrintWriter(new FileWriter(fileName));
		writer.print(content);
		writer.close();
	}

	/**
	 * ��ʼ��currentUser����
	 * 
	 * @param user
	 * @return
	 */
	private User createCurrentUser(User user) {
		currentUser = user;
		return currentUser;
	}

	/**
	 * ��ȡ�û�ѡ�����true����false
	 * 
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private boolean trueOrFalse() throws IOException, InterruptedException {
		int choice = getChoiceTOrF();
		if (choice == 0) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * ��ȡ�û���boolean���ͱ�����ѡ��
	 * 
	 * @return the input
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private int getChoiceTOrF() throws IOException, InterruptedException {

		int input;

		do {
			try {
				Thread.sleep(500);
				stdErr.println();
				stdErr.print("[0]  ��\n" + "[1]  ��\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 1 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

}