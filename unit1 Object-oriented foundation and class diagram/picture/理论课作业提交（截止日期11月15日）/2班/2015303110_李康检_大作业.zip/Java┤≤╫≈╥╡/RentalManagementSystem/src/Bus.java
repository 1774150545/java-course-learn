/*
 *����ͳ���
 * */
public class Bus extends MotoVehicle {
	private int seatCount;

	public Bus() {
	}

	public Bus(String brand, int perRent, String vehicleId, int seatCount) {
		super(brand, perRent, vehicleId);
		this.seatCount = seatCount;
	}

	public void setSeatCount(int seatCount) {
		this.seatCount = seatCount;
	}

	public int getSeatCount() {
		return this.seatCount;
	}

	// �������
	/*
	 * days>=3��9�� days>=7��8�� days>=30��7�� days>=150��6��
	 */
	public double calcRent(int days) {
		double price = this.getPerRent() * days;
		if (days >= 3 && days < 7) {
			price = price * 0.9;
		} else if (days >= 7 && days < 30) {
			price = price * 0.8;
		} else if (days >= 30 && days < 150) {
			price = price * 0.7;
		} else if (days >= 150) {
			price = price * 0.6;
		}
		return price;
	}
	
	public String toString(){
		String str= "�ͳ�"+this.getBrand()+"_"+ this.getVehicleId()+"_"+this.getSeatCount();
		return str;
	}

}
