/*
 * ���ࣺ�γ���
 * */
public class Car extends MotoVehicle {
	// �ͺ�
	private String type;

	public Car() {
	}

	public Car(String brand, int perRent, String vehicleId, String type) {
		super(brand, perRent, vehicleId);
		this.type = type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getType() {
		return this.type;
	}

	// �������
	/*
	 * days>7��9�� days>30��8�� days>150��7��
	 */
	public double calcRent(int days) {
		double price = this.getPerRent() * days;
		if (days > 7 && days <= 30) {
			price = price * 0.9;
		} else if (days > 30 && days <= 150) {
			price = price * 0.8;
		} else if (days > 150) {
			price = price * 0.7;
		}
		return price;
	}
	
	public String toString(){
		String str= "�γ�"+this.getBrand()+"_"+"_"+this.getVehicleId()+"_"+this.getType();
		return str;
	}
}