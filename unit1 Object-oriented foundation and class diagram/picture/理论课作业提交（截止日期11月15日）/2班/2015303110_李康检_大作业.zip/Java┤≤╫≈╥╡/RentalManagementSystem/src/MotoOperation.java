import java.awt.DisplayMode;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.zip.DataFormatException;


/**
 * ����ҵ����
 * @author ���
 * @version 1.0
 */
public class MotoOperation {
	
	MotoVehicle[] motos = new MotoVehicle[15];

	// ��ʼ������
	public void init() throws IOException, DataFormatException {
		
		int i=0;
		
		BufferedReader reader = new BufferedReader ( new FileReader ("MotoVehicle.dat") );
		String line = reader.readLine();
		while(line!=null){
			if(line.startsWith ("car")) {
				motos[i++] = readCar(line);
			}
			if(line.startsWith ("bus")) {
				motos[i++] = readBus(line);
			}
			line = reader.readLine();
		}
		reader.close();
	}
	
	private Car readCar (String line) throws DataFormatException {
		StringTokenizer tokenizer=new StringTokenizer(line,"_");
			if(tokenizer.countTokens()==5){
				String car=tokenizer.nextToken();
				String brand=tokenizer.nextToken();
				int perRent=Integer.parseInt(tokenizer.nextToken());
				String vehicleId=tokenizer.nextToken();
				String type=tokenizer.nextToken();
				return new Car(brand, perRent, vehicleId, type);
			}else{
				return null;
			}
		}
	
	private Bus readBus (String line) throws DataFormatException {
		StringTokenizer tokenizer=new StringTokenizer(line,"_");
			if(tokenizer.countTokens()==5){
				String bus=tokenizer.nextToken();
				String brand=tokenizer.nextToken();
				int perRent=Integer.parseInt(tokenizer.nextToken());
				String vehicleId=tokenizer.nextToken();
				int seatCount=Integer.parseInt(tokenizer.nextToken());
				return new Bus(brand, perRent, vehicleId, seatCount);
			}else{
				return null;
			}
		}

	// �ṩ���޷���
	// �����û����⳵����ȥ������Ӧ��������������Ӧ����
	// �û����⳵�����������Ĳ���
	public MotoVehicle rentVehicle(String brand, String type, int seatCount) {
		MotoVehicle rentMoto = null;
		for (MotoVehicle moto : motos) {
			if (moto instanceof Car) {
				moto = (Car) moto;
				if (brand.equals(moto.getBrand()) && type.equals(((Car) moto).getType())) {
					rentMoto = moto;
					break;
				}
			}
			if (moto instanceof Bus) {
				moto = (Bus) moto;
				if(brand.equals(moto.getBrand()) && ((Bus)moto).getSeatCount()==seatCount){
					rentMoto=moto;
					break;
				}
				
			}	
		}
		return rentMoto;
	}
}

