import java.util.ArrayList;
import java.util.Iterator;



/**
 * @author Lijiaang
 * @version 1.0
 * @date 2016/11/10
 *
 */
public class List {


	/**
	 * 私有属性 list item的集合
	 */
	private ArrayList<Item> list = new ArrayList<Item>();
	
	
	/**
	 * 含参数构造函数
	 * @param list
	 */
	public List(ArrayList<Item> list) {
		super();
		this.list = list;
	}

	/**
	 * 获取list item的集合list
	 * @return
	 */
	public ArrayList<Item> getList() {
		return list;
	}

	/**
	 * 重写list 
	 * @param list
	 */
	public void setList() {
		this.list = list;
	}

	/**
	 * 添加item到list里
	 * @param item
	 */
	public void addItem(Item item ){
		this.list.add(item);
	}
	
	/**
	 * 删除item
	 * @param item
	 */
	public void removeItem(Item item){
		this.list.remove(item);
	}
	/**
	 * 通过code在list中获取item
	 * @param item
	 * @return
	 */
	public Item getItem(String code){
		if(list!=null){
		for( Item a: list){
			if(a.getCode().equals(code)){
				return a;
			}
		}
		}
		return null;
	}
	/**
	 * 遍历list 迭代器
	 * @return
	 */
	public Iterator<Item> iterator(){
		return list.iterator();
	}
	/**
	 * 获取list中item的数量
	 * @return
	 */
	public int getNumberOfItems(){
		int sum = 0;
		if(list!=null){
			sum= list.size();
			return sum;
		}
		else return 0;
	}

	/**
	 * 展示list
	 */
	public String toString(){
		String str="";
		for(Item b : list){
			str+=b.getCode()+"-"+b.getTitle()+"\n";
		}
		return str;
	}
}
