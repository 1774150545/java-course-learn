
/**
 * 书籍
 * @author Lijiaang
 * @version 1.0
 * @date 2016/11/10
 *
 */
public class Book extends Item {

	/**
	 * 私有属性 author 作者
	 * numberOfPages 页码数量
	 */
	private String author;
	private int numberOfPages;
	
	/**
	 * 含参数的构造方法
	 * @param code
	 * @param year
	 * @param title
	 * @param availability
	 * @param author
	 * @param numberOfPages
	 */
	public Book(String code, String year, String title, boolean availability, String author, int numberOfPages) {
		super(code, year, title, availability);
		this.author= author;
		this.numberOfPages= numberOfPages;
		// TODO Auto-generated constructor stub
	}

	/**
	 * 无参数的构造方法
	 */
	public Book() {
		// TODO Auto-generated constructor stub
	}


	/**
	 * 重新编写author的信息
	 * @param author
	 */
	public void setAuthor(String author) {
		this.author = author;
	}



	/**
	 * 重新编写numberOfPages的信息
	 * @param numberOfPages
	 */
	public void setNumberOfPages(int numberOfPages) {
		this.numberOfPages = numberOfPages;
	}



	/**
	 * 获取author的信息
	 * @return
	 */
	public String getAuthor() {
		return author;
	}
	/**
	 * 获取numberOfPages的信息，页码数量
	 * @return
	 */
	public int getNumberOfPages() {
		return numberOfPages;
	}
	/**
	 * 覆写item中的toString方法
	 * 展示出相关信息
	 * 添加了author和numberOfPages的信息
	 */
	public String toString(){
		String str ="";
		str+= super.toString()+"_"+this.getAuthor()+"_"+this.getNumberOfPages();
		return str;
	}
	
}
