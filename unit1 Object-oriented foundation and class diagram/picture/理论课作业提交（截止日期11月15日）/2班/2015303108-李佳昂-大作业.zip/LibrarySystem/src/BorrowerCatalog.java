import java.util.ArrayList;
import java.util.Iterator;


/**
 * 读者的目录，读者集合
 * @author Lijiaang
 * @version 1.0
 * @date 2016/11/10 
 */
public class BorrowerCatalog implements Iterable<Borrower> {

	/**
	 * 私有属性 borrowers
	 * 所有读者的集合
	 */
	private ArrayList<Borrower> borrowers = new ArrayList<Borrower>();
	/**
	 * 添加一个读者
	 * @param borrower
	 */
	public void addBorrower(Borrower borrower){
		this.borrowers.add(borrower);
	}
	
	/**
	 * 获取相关读者
	 * @return
	 */
	public ArrayList<Borrower> getBorrowers() {
		return borrowers;
	}


	/**
	 * 通过code来查找相关读者
	 * @param code
	 * @return
	 */
	public Borrower getBorrower(String code){
		for(int i = 0; i<borrowers.size();i++){
			if(borrowers.get(i).getId().equals(code)){
				return borrowers.get(i);
			}
		}
		return null;
	}
	/**
	 * 遍历borrowers的迭代器
	 * @return
	 */
	public Iterator<Borrower> iterator(){
		return borrowers.iterator();
	}
	/**
	 * 获取读者的总数量
	 * @return
	 */
	public int getNumberOfBorrowers(){
		int sum = 0;
		if(borrowers!=null){
			sum=borrowers.size();
		}
		return sum;
	}
}
