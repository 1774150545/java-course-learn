import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
/**
 * 简单的图书管理系统
 * @author Lijiaang
 * @version 1.0
 * @date 2016/11/12
 */
public class LibrarySystem {
	
	/**
	 * 私有静态变量 输入，输出 I/O
	 */
	private static BufferedReader  stdIn =
			new  BufferedReader(new  InputStreamReader(System.in));
		private static PrintWriter  stdOut =
			new  PrintWriter(System.out, true);
		private static PrintWriter  stdErr =
			new  PrintWriter(System.err, true);

		/**
		 * 私有属性
		 * catalog item 的目录
		 * borrowerCatalog borrower 的目录
		 */
		private Catalog catalog;
		private BorrowerCatalog borrowerCatalog;

		
		/**
		 * 静态方法 开始运行程序
		 * @param args
		 * @throws IOException
		 */
		public static void  main(String[] args) throws IOException  {

			LibrarySystem  application = new LibrarySystem();
			application.run();

		}

		/**
		 * 私有无参构造方法
		 */

		private LibrarySystem() {

			this.catalog = loadCatalog();
			this.borrowerCatalog = loadBorrowerCatalog();
		}

		/**
		 * 私有方法 新建 catalog 输入item的信息
		 * @return
		 */
		private Catalog loadCatalog() {

			Catalog catalog = new Catalog();
			
			Item item1 = new Book("b001","1987","book1",true,"author1",193);
			Item item2 = new Book("b002","2000","book2",false,"author2",300);
			Item item3 = new Book("b003","2016","book3",true,"author3",654);
			Item item4 = new Recording("r001","2015","recording1",true,"CD","LI");
			Item item5 = new Recording("r002","2016","recording2",false,"DVD","JIA");
						
			catalog.addItem(item1);
			catalog.addItem(item2);
			catalog.addItem(item3);
			catalog.addItem(item4);
			catalog.addItem(item5);
			return catalog;
		}

		/**
		 * 私有方法 创造新的borrowerCatalog 添加borrower的数据
		 * @return
		 */
		private BorrowerCatalog loadBorrowerCatalog() {
			BorrowerCatalog borrowerCatalog = new BorrowerCatalog();
			
			Item item1 = new Book("b001","1987","book1",true,"author1",193);
			Item item2 = new Book("b002","2000","book2",false,"author2",300);
			Item item3 = new Book("b003","2016","book3",true,"author3",654);
			Item item4 = new Recording("r001","2015","recording1",true,"CD","LI");
			Item item5 = new Recording("r002","2016","recording2",false,"DVD","JIA");
			
			ArrayList<Item> list1 = new ArrayList<Item>(Arrays.asList(item2,item5));
			ArrayList<Item> list2 = new ArrayList<Item>(Arrays.asList(item1,item4));
			ArrayList<Item> list3 = new ArrayList<Item>(Arrays.asList(item3,item5));
			ArrayList<Item> list4 = new ArrayList<Item>(Arrays.asList(item2,item4));
			
			Borrower person1 = new Borrower("A001","name1",list1);
			Borrower person2 = new Borrower("A002","name2",list2);
			Borrower person3 = new Borrower("A003","name3",null);
			Borrower person4 = new Borrower("A004","name4",list3);

			Borrower person5 = new Borrower("A005","name5",list4);
			
			
			borrowerCatalog.addBorrower(person1);
			borrowerCatalog.addBorrower(person2);
			borrowerCatalog.addBorrower(person3);
			borrowerCatalog.addBorrower(person4);
			
			borrowerCatalog.addBorrower(person5);

			return borrowerCatalog;

		}

		/**
		 * 给用户一个界面，供用户选择
		 * @throws IOException
		 */
		private void run() throws IOException  {

			int choice = getChoice();

			while (choice != 0)  {
				if (choice == 1)  {
					displayCatalog();
				} else if (choice == 2)  {
					displayItemInfo();
				} else if (choice == 3)  {
					addItem();
				} else if (choice == 4)  {
					displayBorrower();
				} else if (choice == 5)  {
					removeItem();
				} else if (choice == 6) {
					addBorrower();
				}
				choice = getChoice();
			}
		}

		/**
		 * 获取用户选择的方法
		 * @return
		 * @throws IOException
		 */

		private int  getChoice() throws IOException  {

			int  input;

			do  {
				try  {
					stdErr.println();
					stdErr.print(
						  "[0] Quit\n"
						+ "[1] Display item catalog\n"
						+ "[2] Display item\n"
						+ "[3] Add item for Catalog\n"
						+ "[4] Display borrower\n"
						+ "[5] Remove item from Catalog\n"
						+ "[6] Add Borrower for borrowerCatalog\n"
						+ "choice> ");
					stdErr.flush();

					input = Integer.parseInt(stdIn.readLine());

					stdErr.println();

					if (0 <= input && 9 >= input)  {
						break;
					} else {
						stdErr.println("Invalid choice:  " + input);
					}
				} catch (NumberFormatException  nfe)  {
					stdErr.println(nfe);
				}
			}  while (true);

			return  input;
		}

		/**
		 * 展示catalog，将所有item信息显示出来
		 */
		public void displayCatalog() {

			int size = this.catalog.getNumberOfItems();
			
			if (size == 0) {
				stdErr.println("The catalog is empty");
			} else {
				
				for (Item item : this.catalog.getItems()) {
					stdOut.println(item.toString());
				}
			}
		}

		/**
		 * 通过code找到所需item 并将其显示出来
		 * @throws IOException
		 */
	
		public void displayItemInfo() throws IOException  {

			int size = this.catalog.getNumberOfItems();
			String str = "";
			str +="Number Of Items:"+size;
			stdOut.println(str);

			Item item = readItem();

			if (item instanceof Book) {
				Book book = (Book) item;
				System.out.println(book.toString());
			} else if (item instanceof Recording) {
				Recording recording = (Recording) item;
				System.out.println(recording.toString());
			}
			run();
		}
		
		/**
		 * 展示读者信息
		 * @throws IOException
		 */
		public void displayBorrower() throws IOException {
			// TODO Auto-generated method stub
			int size= this.borrowerCatalog.getNumberOfBorrowers();
			String str= "";
			str +="Number Of Borrowers:"+size+"\n";
			stdOut.println(str);
			Borrower borrower2 = readBorrower();
			
			if(borrower2!=null){
				System.out.println(borrower2.toString());
			}
			run();
		}
		

		/**
		 * 添加item
		 * @throws IOException
		 */
		public void addItem()  throws IOException  {

			Item item = readItem();

			if (item == null) {
				Item tempItem = new Item();
				stdErr.println("Now you can add the new one");

				stdErr.println("Please input title>");
				tempItem.setTitle(stdIn.readLine());
				stdErr.println("Please input year>");
				tempItem.setYear(stdIn.readLine());
				stdErr.println("Please input availability(true or false)>");
				tempItem.setAvailability(Boolean.valueOf(stdIn.readLine()));
				stdErr.println("Please input code>");
				tempItem.setCode(stdIn.readLine());
				//				add product
				this.catalog.addItem(tempItem);
				System.out.println("Add Item Successful!!");
			} else{
				stdErr.println("The Item is already exist!");
			}
		}
		/**
		 * 添加borrower
		 * @throws IOException
		 */
		public void addBorrower()  throws IOException  {

			Borrower borrower = readBorrower();

			if (borrower == null) {
				Borrower tempBorrower = new Borrower();
				stdErr.println("Now you can add the new one");

				stdErr.println("Please input id>");
				tempBorrower.setId(stdIn.readLine());
				stdErr.println("Please input name>");
				tempBorrower.setName(stdIn.readLine());

				//				add product
				this.borrowerCatalog.addBorrower(tempBorrower);
				System.out.println("Add Borrower Successful!!");
			} else{
				stdErr.println("The Borrower is already exist!");
			}
		}

		/**
		 * 删除一个item
		 * @throws IOException
		 */
 
		public void removeItem()  throws IOException  {

			Item item = readItem();
			if(item !=null){
				for(int i = 0 ;i<catalog.getNumberOfItems();i++){
					Item temp = catalog.getItems().get(i);
					if(temp.getCode().equals(item.getCode())){
						this.catalog.getItems().remove(i);
						stdErr.println("delete successfully!");
					}
				}
			}
		}
		
		
		
		/**
		 * 读取item，通过所输入的code来读取是否有相应的item
		 * @return
		 * @throws IOException
		 */
		private Item readItem() throws IOException  {
				
				stdErr.print("Item code> ");
				stdErr.flush();
				
				Item item = this.catalog.getItem(stdIn.readLine());
				if (item != null) {
					return item;
				} else {	
					stdErr.println("There are no item with that code");
					return null;
				}
		}
		

		/**
		 * 读取读者信息，通过code来找到相应读者
		 * @return
		 * @throws IOException
		 */
		private Borrower readBorrower() throws IOException  {
			stdErr.print("Borrower code> ");
			stdErr.flush();

			Borrower borrower = this.borrowerCatalog.getBorrower(stdIn.readLine());
			if (borrower != null) {
				return borrower;
			} else {	
				stdErr.println("There are no borrower with that code");
				return null;
			}
		}
}
