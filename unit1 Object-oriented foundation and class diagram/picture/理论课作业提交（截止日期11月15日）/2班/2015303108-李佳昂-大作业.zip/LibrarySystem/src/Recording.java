

/**
 * 音频
 * @author Lijiaang
 * @version 1.0
 * @date 2016/11/10 *
 */
public class Recording extends Item{

	/**
	 * 私有属性 format 格式
	 * performer 演奏者
	 */
	private String format;
	private String performer;
	
	
	/**
	 * 含参数构造函数
	 * @param code
	 * @param year
	 * @param title
	 * @param availability
	 * @param format
	 * @param performer
	 */
	public Recording(String code, String year, String title, boolean availability, String format, String performer) {
		super(code, year, title, availability);
		this.format = format;
		this.performer = performer;
	}
	/**
	 * 获取format 格式
	 * @return
	 */
	public String getFormat() {
		return format;
	}
	/**
	 * 
	 * @return
	 */
	public String getPerformer() {
		return performer;
	}
	
	/**
	 * 重设format
	 * @param format
	 */
	public void setFormat(String format) {
		this.format = format;
	}
	/**
	 * 重设 performer
	 * @param performer
	 */
	public void setPerformer(String performer) {
		this.performer = performer;
	}
	/**
	 * 展示信息
	 */
	public String toString(){
		String str="";
		str+=super.toString()+"_"+this.getFormat()+"_"+this.getPerformer();
		return str;
	}
	
	
	
}
