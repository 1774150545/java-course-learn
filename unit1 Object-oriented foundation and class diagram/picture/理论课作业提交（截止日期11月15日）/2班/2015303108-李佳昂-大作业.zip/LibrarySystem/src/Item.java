

/**
 * @author Lijiaang
 * @version 1.0
 * @date 2016/11/10
 *
 */
public class Item {

	/**
	 * 私有属性
	 * code 编码
	 * year 年份
	 * title 标题
	 * availability 可否借阅
	 */
	private String code;
	private String year;
	private String title;
	private boolean availability;
	/**
	 * 含参数构造函数
	 * @param code
	 * @param year
	 * @param title
	 * @param availability
	 */
	public Item(String code, String year, String title, boolean availability) {
		super();
		this.code = code;
		this.year = year;
		this.title = title;
		this.availability = availability;
	}
	/**
	 * 无参数构造函数
	 */
	public Item() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 获取item的code
	 * @return
	 */
	public String getCode() {

		return this.code;
	}
	
	/**
	 * 获取item的year
	 * @return
	 */
	public String getYear() {
		return year;
	}

	/**
	 * 获取item 的title
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * 获取item 的Availability信息
	 * @return
	 */
	public boolean isAvailability() {
		return availability;
	}

	/**
	 * 重写code
	 * @param code
	 */
	
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 重写year
	 * @param year
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * 重写title
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * 重写availability
	 * @param availability
	 */
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	/**
	 * 判断两个item是否相同
	 */
	public boolean equals(Object object) {
		if(object instanceof Item){
			Item e= (Item) object;
			return this.getCode().equals(e.getCode())
					&&this.getYear().equals(e.getYear())
					&&this.getTitle().equals(e.getTitle())
					&&this.isAvailability()==(e.isAvailability());}
		else{
			return false;
			
		}
		
	}
	/**
	 * 展示item的信息
	 */
	public String toString() {

		return getCode() + "_" + getYear()  + "_" + getTitle() + "_"+ isAvailability();
	}

}
