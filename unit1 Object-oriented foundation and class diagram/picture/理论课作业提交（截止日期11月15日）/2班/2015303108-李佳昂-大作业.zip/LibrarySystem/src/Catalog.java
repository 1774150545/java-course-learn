import java.util.ArrayList;
import java.util.Iterator;


/**
 * 所有图书馆物品的集合
 * @author Lijiaang
 * @version 1.0
 * @date 2016/11/10
 *
 */
public class Catalog implements Iterable<Item> {

	/**
	 * 私有属性 items
	 * item 的集合
	 */
	private ArrayList<Item> items = new ArrayList<Item>();
	/**
	 * 添加一个item
	 * @param item
	 */
	public void addItem(Item item){
		this.items.add(item);
	}
	
	/**
	 * 获取item的集合items
	 * @return
	 */
	public ArrayList<Item> getItems() {
		return items;
	}


	/**
	 * 通过code来查找相关item
	 * @param code
	 * @return
	 */
	public Item getItem(String code){
		for(int i = 0; i<items.size();i++){
			if(items.get(i).getCode().equals(code)){
				return items.get(i);
			}
		}
		return null;
	}
	/**
	 * 遍历item的迭代器
	 */
	public Iterator<Item> iterator(){
		return items.iterator();
	}
	/**
	 * 获取item 的数量
	 * @return
	 */
	public int getNumberOfItems(){
		int sum = 0;
		if(items!=null){
			sum=items.size();
		}
		return sum;
	}
}
