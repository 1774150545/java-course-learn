import java.util.ArrayList;

/**
 * 读者
 * @author Lijiaang
 * @version 1.0
 * @date 2016/11/10
 *
 */
public class Borrower extends BorrowerCatalog{


	/**
	 * 私有属性 list item的集合
	 * id 读者编号
	 * name 读者姓名
	 */
	private ArrayList<Item> list = new ArrayList<Item>();
	private String id;
	private String name;
	
	
	/**
	 * 含参数构造方法
	 * @param lists
	 * @param id
	 * @param name
	 */
	public Borrower( String id, String name, ArrayList<Item> list) {
		super();
		this.id = id;
		this.name = name;
		this.list = list;
	}

	/**
	 * 无参数构造方法
	 */
	public Borrower() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 获取读者的id
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * 获取读者的姓名
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * 获取borrower 的list
	 * @return
	 */
	public ArrayList<Item> getList() {
		return list;
	}

	/**
	 * 重写borrower 的list
	 * @return
	 */
	public void setList(ArrayList<Item> list) {
		this.list = list;
	}

	/**
	 * 重写id
	 * @return
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * 重写name
	 * @return
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 获取读者所借阅的item，并返回到list中
	 * @return
	 */
	public ArrayList<Item> getItems() {
		return list;
	}
	/**
	 * 获取读者所借阅的item的数量
	 * @return
	 */
	public int getNumberOfItem(){
		int sum=0;
		if(list!=null){
		for(Item list1 : list){
			sum++;
		}
		return sum;
	}
		else return 0;
	}
	/**
	 * 展示读者信息
	 */
	public String toString(){
		String str="";
		str+=this.getName()+"_"+this.getId()+"_list:"+this.getItems();
		return str;
		
	}
	
}
