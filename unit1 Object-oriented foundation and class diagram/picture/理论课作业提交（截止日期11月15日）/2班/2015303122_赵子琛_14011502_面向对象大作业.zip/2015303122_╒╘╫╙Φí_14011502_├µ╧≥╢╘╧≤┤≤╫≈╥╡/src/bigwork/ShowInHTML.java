/**
 * 
 */
package bigwork;

import java.util.ArrayList;

/**
 * ����ѧ����Ϣ��HTML��ʽ��ʾ
 * 
 * @author zzc
 * @version 1.0
 */
public class ShowInHTML implements ShowInfomition {
	private final static String NEW_LINE = System.getProperty("line.separator");

	private static ShowInHTML singletonInstance;

	/**
	 * ˽�й��췽��
	 */
	private ShowInHTML() {

	}

	/**
	 * ��ȡShowInHTML�ĵ�һʵ��
	 * 
	 * @return ShowInHTML
	 */
	public static ShowInHTML getSingletonInstance() {
		if (singletonInstance == null) {
			singletonInstance = new ShowInHTML();
		}
		return singletonInstance;
	}

	/**
	 * ����ѧ����Ϣ��HTML��ʽ�ı�ʾ
	 */
	@Override
	public String showInfomition(ArrayList<Person> persons) {
		String out = "<html>" + NEW_LINE + "<body>" + NEW_LINE + " " + "<center><h2>Student Informition</h2></center>"
				+ NEW_LINE;
		for (Person person : persons) {
			if (person instanceof Newer) {
				Newer e = (Newer) person;
				out += "<hr>" + NEW_LINE + "<h4>" + e.toString() + "</h4>" + NEW_LINE;
			} else {
				Older e = (Older) person;
				out += "<hr>" + NEW_LINE + "<h4>" + e.toString() + "</h4>" + NEW_LINE;
			}
			out += "</blockquote>" + NEW_LINE;
		}
		out += "</body>" + NEW_LINE + "</html>";
		return out;
	}
}
