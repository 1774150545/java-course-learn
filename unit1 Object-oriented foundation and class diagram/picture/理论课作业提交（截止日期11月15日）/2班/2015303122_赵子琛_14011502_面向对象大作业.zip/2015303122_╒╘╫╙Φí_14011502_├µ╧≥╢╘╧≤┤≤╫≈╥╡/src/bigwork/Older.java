/**
 * 
 */
package bigwork;

import java.util.ArrayList;

/**
 * �϶�Ա������Ϣ��
 * 
 * @author zzc
 * @version 1.0
 */
public class Older extends Person {
	private int numberOfBooks;

	/**
	 * @param name
	 *            ����
	 * @param id
	 *            ѧ��
	 * @param instittion
	 *            ѧԺ
	 * @param tel
	 *            �绰
	 * @param qq
	 *            QQ
	 * @param projects
	 *            ������Ŀ
	 * @param numberOfBooks
	 *            ���ѧϰ��Ŀ
	 */
	public Older(String name, String id, String instittion, String tel, String qq, ArrayList<Project> projects,
			int numberOfBooks) {
		super(name, id, instittion, tel, qq, projects);
		this.numberOfBooks = numberOfBooks;
	}

	/**
	 * @return the numberOfBooks
	 */
	public int getNumberOfBooks() {
		return numberOfBooks;
	}

	/**
	 * @param numberOfBooks
	 *            Ҫ�޸ĵ���Ŀ
	 */
	public void setNumberOfBooks(int numberOfBooks) {
		this.numberOfBooks = numberOfBooks;
	}

	/**
	 * toString����
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Older [name=" + getName() + ", id=" + getId() + ", instittion=" + getInstittion() + ", tel=" + getTel()
				+ ", Qq=" + getQq() + ", numberOfProject=" + getNumberOfProject() + ", numberOfBooks=" + numberOfBooks
				+ "]";
	}
}
