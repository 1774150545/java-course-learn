/**
 * 
 */
package bigwork;

import java.util.ArrayList;

/**
 * �¶�Ա������Ϣ��
 * 
 * @author zzc
 * @version 1.0
 */
public class Newer extends Person {

	private int numberOfAbance;

	private int numberOfLate;

	/**
	 * ���췽��
	 */
	public Newer() {
		super();
	}

	/**
	 * @param name
	 *            ����
	 * @param id
	 *            ѧ��
	 * @param instittion
	 *            ѧԺ
	 * @param tel
	 *            �绰
	 * @param qq
	 *            QQ
	 * @param projects
	 *            ������Ŀ
	 * @param numberOfAbance
	 *            ǩ��ȱϯ����
	 * @param numberOfLate
	 *            �ٵ�����
	 */
	public Newer(String name, String id, String instittion, String tel, String qq, ArrayList<Project> projects,
			int numberOfAbance, int numberOfLate) {
		super(name, id, instittion, tel, qq, projects);
		this.numberOfAbance = numberOfAbance;
		this.numberOfLate = numberOfLate;
	}

	/**
	 * @return ȱϯ����
	 */
	public int getNumberOfAbance() {
		return numberOfAbance;
	}

	/**
	 * @param numberOfAbance
	 *            �޸�ȱϯ����
	 */
	public void setNumberOfAbance(int numberOfAbance) {
		this.numberOfAbance = numberOfAbance;
	}

	/**
	 * @return �ٵ�����
	 */
	public int getNumberOfLate() {
		return numberOfLate;
	}

	/**
	 * @param numberOfLate
	 *            ���óٵ�����
	 * 
	 */
	public void setNumberOfLate(int numberOfLate) {
		this.numberOfLate = numberOfLate;
	}

	/**
	 * toString����
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Newer [name=" + getName() + ", id=" + getId() + ", instittion=" + getInstittion() + ", tel()="
				+ getTel() + ", qq=" + getQq() + ", numberOfProject=" + getNumberOfProject() + ", numberOfAbance="
				+ numberOfAbance + ", numberOfLate=" + numberOfLate + "]";
	}

}
