/**
 * 
 */
package bigwork;

import java.util.ArrayList;

/**
 * �ӿ���
 * 
 * @author zzc
 *
 */
public interface ShowInfomition {

	String showInfomition(ArrayList<Person> persons);
}
