/**
 * 
 */
package bigwork;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * ����ѧ����Ϣ����ϵͳ�������ࣩ
 * 
 * @author zzc
 * @version 1.0
 */
public class CatalogSystem {

	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);

	private Catalog catalog;
	private ShowInfomition showInformition;

	/**
	 * ���췽��
	 */
	public CatalogSystem() {
		this.catalog = LoadCatalog();
		showInformition = null;
	}

	/**
	 * ��ʼ������
	 * 
	 * @return
	 */
	private Catalog LoadCatalog() {

		Catalog catalog = new Catalog();

		Project project1 = new Project("�Ӿ�����", "A001", "2016-12-30", 10000.0);
		Project project2 = new Project("��̬����", "A002", "2017-5-30", 8000.0);
		Project project3 = new Project("�㷨�", "A003", "2017-3-30", 8000.0);
		Project project4 = new Project("������", "A004", "2016-12-30", 10000.0);

		Newer person1 = new Newer("����", "2015303101", "����", "18832824431", "2123212312",
				new ArrayList<Project>(Arrays.asList(project1, project2)), 0, 0);
		Newer person2 = new Newer("���", "2015303102", "�����", "18832852312", "21232342",
				new ArrayList<Project>(Arrays.asList(project2, project3)), 1, 0);
		Older person3 = new Older("����", "2014303103", "�Զ���", "18933323869", "1689726351",
				new ArrayList<Project>(Arrays.asList(project1, project3, project4)), 6);
		Older person4 = new Older("��ΰ", "2014303105", "����", "18933323669", "1689726351",
				new ArrayList<Project>(Arrays.asList(project2)), 3);

		catalog.add(person1);
		catalog.add(person2);
		catalog.add(person3);
		catalog.add(person4);

		return catalog;
	}

	public static void main(String[] args) throws IOException {

		CatalogSystem application = new CatalogSystem();
		application.run();

	}

	/**
	 * ѡ��
	 * 
	 * @return choice
	 * @throws IOException
	 */
	private int getChoice() throws IOException {
		int input;
		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" + "[1] Display Informition in TXT \n" + "[2] Display Informition in HTML\n"
						+ "[3] Display Informition in XML\n" + "[4] Add Newer Or Display informition\n"
						+ "[5] Remove Student\n" + "[6] Display numberOfstudent\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 6 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);
		return input;
	}

	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				ShowInTxt show = ShowInTxt.getSingletonInstance();
				setShows(show);
				Shows();
			} else if (choice == 2) {
				ShowInHTML show = ShowInHTML.getSingletonInstance();
				setShows(show);
				Shows();
			} else if (choice == 3) {
				ShowInXML show = ShowInXML.getSingletonInstance();
				setShows(show);
				Shows();
			} else if (choice == 4) {
				addNewer();
			} else if (choice == 5) {
				removePerson();
			} else if (choice == 6) {
				displayNumberOfPersons();
			}
			choice = getChoice();
		}
	}

	/**
	 * ���������л�ȡѧ���Եõ���Ӧ��ѧ��������Ϣ
	 * 
	 * @return ��Ӧѧ�ŵ�ѧ����Ϣ
	 * @throws IOException
	 */
	private Person readPerson() throws IOException {

		stdErr.print("Person id> ");
		stdErr.flush();

		Person person = catalog.getPerson(stdIn.readLine());
		if (person != null) {
			return person;
		} else {
			stdErr.println("There are no person with that code");
			return null;
		}
	}

	/**
	 * �����¶�Ա
	 * 
	 * @throws IOException
	 */
	public void addNewer() throws IOException {

		Person person = readPerson();

		if (person == null) {
			Newer tempNewer = new Newer();

			stdErr.println("Now you can add the new one");

			stdErr.println("Please input id>");
			tempNewer.setId(stdIn.readLine());

			stdErr.println("Please input name>");

			tempNewer.setName(stdIn.readLine());
			stdErr.println("Please input institution>");
			tempNewer.setInstittion(stdIn.readLine());
			stdErr.println("Please input tel>");
			tempNewer.setTel(stdIn.readLine());
			stdErr.println("Please input qq>");
			tempNewer.setQq(stdIn.readLine());

			stdErr.println("Please input numberofproject>");
			int tem = Integer.valueOf(stdIn.readLine());

			ArrayList<Project> projects = new ArrayList<Project>();
			for (int s = 1; s <= tem; s++) {
				Project project = new Project();
				stdErr.print("Project");
				stdErr.println(s);
				stdErr.println("Please input projectname>");
				project.setName(stdIn.readLine());
				stdErr.println("Please input projectcode>");
				project.setCode(stdIn.readLine());
				stdErr.println("Please input projectdeadline>");
				project.setDeadline(stdIn.readLine());
				stdErr.println("Please input projectmoney>");
				double t = Double.valueOf(stdIn.readLine());
				project.setMoney(t);
				projects.add(project);
			}
			tempNewer.setProjects(projects);

			this.catalog.add(tempNewer);
			System.out.println("Add Product Successful!!");
		} else {
			stdErr.println("The product is already exist!The Informitionofstudent:");
			if (person instanceof Newer) {
				Newer e = (Newer) person;
				stdErr.println(e.toString());
			} else {
				Older e = (Older) person;
				stdErr.println(e.toString());
			}
		}
	}

	/**
	 * ɾ����Ա
	 * 
	 * @throws IOException
	 */
	public void removePerson() throws IOException {

		Person person = readPerson();
		if (person != null) {
			catalog.getPersons().remove(person);
			stdErr.println("delete successfully!");
		}
	}

	/**
	 * �ı�ѧ����Ϣ����ʾ��ʽ
	 * 
	 * @param newshows
	 */
	private void setShows(ShowInfomition newshows) {
		showInformition = newshows;
	}

	/**
	 * ��ʾѧ����Ϣ
	 */
	private void Shows() {
		stdOut.println(showInformition.showInfomition(catalog.getPersons()));
	}

	/**
	 * ��ʾ��ǰ����ӵ�е�ѧ����Ŀ
	 */
	private void displayNumberOfPersons() {
		stdErr.println("The number of Person is>");
		stdErr.println(catalog.getPersons().size());
	}
}
