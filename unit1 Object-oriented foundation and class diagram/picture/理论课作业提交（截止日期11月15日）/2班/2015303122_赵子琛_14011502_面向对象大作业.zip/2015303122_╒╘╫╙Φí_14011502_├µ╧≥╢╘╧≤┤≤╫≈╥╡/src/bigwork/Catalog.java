/**
 * 
 */
package bigwork;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * ѧ����ϢĿ¼��
 * 
 * @author zzc
 * @version 1.0
 */
public class Catalog implements Iterable<Person> {
	private ArrayList<Person> persons;

	/**
	 * ���췽��
	 */
	public Catalog() {
		persons = new ArrayList<Person>();
	}

	/**
	 * ���췽��
	 * 
	 * @param persons
	 *            ѧ��
	 */
	public Catalog(ArrayList<Person> persons) {
		super();
		this.persons = persons;
	}

	/**
	 * ϵͳ������ѧ��
	 * 
	 * @param person
	 *            Ҫ���ӵ�ѧ��
	 */
	public void add(Person person) {
		persons.add(person);
	}

	/**
	 * ʵ�ֽӿ�
	 */
	public Iterator<Person> iterator() {
		return persons.iterator();
	}

	/**
	 * ����ѧ�Ų�ѯѧ��
	 * 
	 * @param id
	 *            ѧ��
	 * @return ��Ӧѧ�ŵ�ѧ��
	 */
	public Person getPerson(String id) {
		for (Person person : persons) {
			if (person.getId().equals(id)) {
				return person;
			}
		}
		return null;
	}

	/**
	 * ɾ��ѧ��
	 * 
	 * @param person
	 *            Ҫɾ����ѧ��
	 * @return boolean
	 */
	public boolean remove(Person person) {
		return persons.remove(person);
	}

	/**
	 * ��ѯѧ����Ŀ
	 * 
	 * @return ѧ����Ŀ
	 */
	public int getNumberOfPerson() {
		int count = 0;
		for (Person person : persons) {
			count++;
		}
		return count;
	}

	/**
	 * @return the persons
	 */
	public ArrayList<Person> getPersons() {
		return persons;
	}

}
