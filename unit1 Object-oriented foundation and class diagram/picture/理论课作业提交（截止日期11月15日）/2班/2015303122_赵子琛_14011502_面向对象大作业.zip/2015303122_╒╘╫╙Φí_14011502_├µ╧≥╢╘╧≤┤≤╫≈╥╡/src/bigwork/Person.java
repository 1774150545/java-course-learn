package bigwork;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * ѧ��������Ϣ��
 * 
 * @author zzc
 * @version 1.0
 */
public class Person implements Iterable<Project> {

	private String name;
	private String id;
	private String instittion;
	private String tel;
	private String qq;
	private ArrayList<Project> projects;

	/**
	 * ���췽��
	 */
	public Person() {
		super();
		projects = new ArrayList<Project>();
	}

	/**
	 * @param name
	 *            ����
	 * @param id
	 *            ѧ��
	 * @param instittion
	 *            ѧԺ
	 * @param tel
	 *            �绰
	 * @param qq
	 *            QQ
	 * @param projects
	 *            ���ڿ�����Ŀ
	 */
	public Person(String name, String id, String instittion, String tel, String qq, ArrayList<Project> projects) {
		super();
		this.name = name;
		this.id = id;
		this.instittion = instittion;
		this.tel = tel;
		this.qq = qq;
		this.projects = projects;
	}

	/**
	 * @param name
	 *            ��������
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param id
	 *            ����ѧ��
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @param instittion
	 *            ����ѧԺ
	 */
	public void setInstittion(String instittion) {
		this.instittion = instittion;
	}

	/**
	 * @param tel
	 *            ���õ绰
	 */
	public void setTel(String tel) {
		this.tel = tel;
	}

	/**
	 * @param qq
	 *            ����QQ
	 */
	public void setQq(String qq) {
		this.qq = qq;
	}

	/**
	 * @param projects
	 *            ������Ŀ
	 */
	public void setProjects(ArrayList<Project> projects) {
		this.projects = projects;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the instittion
	 */
	public String getInstittion() {
		return instittion;
	}

	/**
	 * @return the tel
	 */
	public String getTel() {
		return tel;
	}

	/**
	 * @return the qq
	 */
	public String getQq() {
		return qq;
	}

	/**
	 * @return the projects
	 */
	public ArrayList<Project> getProjects() {
		return projects;
	}

	/**
	 * ���ص�����
	 */
	@Override
	public Iterator<Project> iterator() {
		return projects.iterator();
	}

	/**
	 * ���ӹ�����Ŀ
	 * 
	 * @param project
	 *            Ҫ���ӵ���Ŀ����
	 */
	public void add(Project project) {
		projects.add(project);
	}

	/**
	 * ������Ŀ���������Ŀ
	 * 
	 * @param code
	 *            ��Ŀ����
	 * @return project
	 */
	public Project getProjectByCode(String code) {
		for (Project project : projects) {
			if (project.getCode().equals(code)) {
				return project;
			}
		}
		return null;
	}

	/**
	 * ɾ����Ŀ
	 * 
	 * @param project
	 *            Ҫɾ������Ŀ
	 * @return boolean
	 */
	public boolean remove(Project project) {
		return projects.remove(project);
	}

	/**
	 * ����������Ŀ����
	 */
	public int getNumberOfProject() {
		int count = 0;
		for (Project project : projects) {
			count++;
		}
		return count;
	}

	/**
	 * equals����
	 */
	public boolean equals(Object o) {
		if (o instanceof Person) {
			Person e = (Person) o;
			return this.getId().equals(e.getId());
		} else {
			return false;
		}
	}
}
