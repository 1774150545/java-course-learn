/**
 * 
 */
package bigwork;

import java.util.ArrayList;

/**
 * ��ӡѧ����Ϣ��XML��ʽ
 * 
 * @author zzc
 * @version 1.0
 */
public class ShowInXML implements ShowInfomition {
	private final static String NEW_LINE = System.getProperty("line.separator");

	private static ShowInXML singletonInstance;

	/**
	 * ˽�й��췽��
	 */
	private ShowInXML() {

	}

	/**
	 * ��ȡShowInXML�ĵ�һʵ��
	 * 
	 * @return ShowInXML
	 */
	public static ShowInXML getSingletonInstance() {
		if (singletonInstance == null) {
			singletonInstance = new ShowInXML();
		}
		return singletonInstance;
	}

	/**
	 * ����ѧ����Ϣ��XML��ʽ�ı�ʾ
	 */
	@Override
	public String showInfomition(ArrayList<Person> persons) {
		String out = "<Student Informition>" + NEW_LINE;
		for (Person person : persons) {
			if (person instanceof Newer) {
				Newer e = (Newer) person;
				out += " <name=\"" + e.getName() + "\" id=\"" + e.getId() + "\" institution=\"" + e.getInstittion()
						+ "\" numberOfAbance=\"" + e.getNumberOfAbance() + "\">" + NEW_LINE;
			} else {
				Older e = (Older) person;
				out += " <name=\"" + e.getName() + "\" id=\"" + e.getId() + "\" institution=\"" + e.getInstittion()
						+ "\" numberOfBooks=\"" + e.getNumberOfBooks() + "\">" + NEW_LINE;
			}
		}
		return out;
	}
}
