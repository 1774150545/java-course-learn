/**
 * 
 */
package bigwork;

import java.util.ArrayList;

/**
 * ����ѧ��������Ϣ��txt�ı���ʽ��ʾ
 * 
 * @author zzc
 * @version 1.0
 */
public class ShowInTxt implements ShowInfomition {

	private final static String NEW_LINE = System.getProperty("line.separator");

	static private ShowInTxt singletonInstance = null;

	/**
	 * ˽�й��췽��
	 */
	private ShowInTxt() {

	}

	/**
	 * ��ȡShowInTxt�ĵ�һʵ��
	 * 
	 * @return ShowInTxt
	 */
	static public ShowInTxt getSingletonInstance() {
		if (singletonInstance == null) {
			singletonInstance = new ShowInTxt();
		}
		return singletonInstance;
	}

	/**
	 * ����ѧ����Ϣ��txt�ı���ʽ��ʾ
	 * 
	 * @return String out
	 */
	@Override
	public String showInfomition(ArrayList<Person> persons) {
		String out = "Student Informition" + NEW_LINE;

		for (Person person : persons) {
			if (person instanceof Newer) {
				Newer e = (Newer) person;
				out += e.toString();
			} else {
				Older e = (Older) person;
				out += e.toString();
			}
			out += NEW_LINE;
		}

		return out;
	}
}
