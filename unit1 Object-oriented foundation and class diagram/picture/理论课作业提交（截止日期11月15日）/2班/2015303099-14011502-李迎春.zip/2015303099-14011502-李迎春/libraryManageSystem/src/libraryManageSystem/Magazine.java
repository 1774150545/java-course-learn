/**
 * 
 */
package libraryManageSystem;

/**
 * This class models a Magazine which extends{@link Book}. it adds the following information:
 * <ol>
 * <li>the price  of the book, an <code>double</code></li>
 * </ol>
 * @author ��ӭ��
 * @version  1.0.0
 */
public class Magazine extends Book{

	private double price;
	/**
	 * construct a <code>Magazine</code> object without paramers.
	 */
	public Magazine() {
	
	}
	

	/**return the price
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	
	/**Constructs a <code>Magazine</code> object.
	 * @param price
	 */
	public Magazine(String title, String author, boolean availability, int id,double price) {
		super();
		this.price = price;
	}


	/**
	 * Returns the string representation of this Magazine.
	 *
	 * @return  the string representation of this Magazine.
	 */
	public String toString(){
		return super.toString()+"price: "+getPrice();
	}
}
