package libraryManageSystem;

import java.util.*;

/**
 * This class implements a method that obtains an HTML
 * representation of a {@link BorrowerDatabase} object.
 *
 * @author ��ӭ��
 * @version  1.2.0
 * @see BorrowersFormatter
 * @see BorrowerDatabase
 * @see Borrower
 * @see BorrowedItems
 * @see CatalogItem
 */
public class HTMLBorrowerFormater
	implements BorrowersFormater  {

	/* Line separator */
	private final static String NEW_LINE = System.getProperty("line.separator");

	/* single instance of this class */
	static private HTMLBorrowerFormater singletonInstance = null;

	/**
	 * Obtains the single instance of class
	 * <code>HTMLBorrowersFormatter</code>
	 *
	 * @return the single instance  of class
	 *         <code>HTMLBorrowersFormatter</code>
	 */
	static public HTMLBorrowerFormater getSingletonInstance() {

		if (singletonInstance == null) {
			singletonInstance = new HTMLBorrowerFormater();
		}

		return singletonInstance;
	}

	/**
	 * The constructor is declared private so other classes cannot
	 * create an instance of this class.
	 */
	private HTMLBorrowerFormater() {

	}

	/**
	 * Obtains an HTML representation of the specified borrower
	 * database.
	 *
	 * @param borrowerDB  the borrower database.
	 * @return  an HTML representation of the specified
	 *          {@link BorrowerDatabase} object.
	 */
	public String borrowerFormat (BorrowerDatebase borrowerDB) {

		String out = "<html>"
				+ NEW_LINE
				+ "  <body>"
				+ NEW_LINE + ""
				+ "    <center><h2>Borrower Database</h2></center>"
				+ NEW_LINE;
            ArrayList<Borrower> borrowers=new ArrayList<Borrower>();
		for (Borrower borrower : borrowers) {
			out += "    <hr>"
					+ NEW_LINE
					+ "    <h4>"
					+ borrower.getId()
					+ " "
					+ borrower.getName()
					+ "</h4>"
					+ NEW_LINE;

			BorrowedItem item = borrower.getBorrowedItem();

			ArrayList<Book> books=new ArrayList<Book>();
			
			if (item.getBookNum() > 0) {
				out += "      <blockquote>" + NEW_LINE;

				for (Book book : books) {
					out += "         "
							+ book.getTitle()
							+ " "
							+ book.getAuthor()
							+ " "
							+ book.isAvailability()
							+ " "
							+ book.getId()
							+ "<br>"
							+ NEW_LINE;
				}
				out += "      </blockquote>" + NEW_LINE;
			}
		}
		out += "  </body>" + NEW_LINE + "</html>";

		return out;
	}


}
/*!End Snippet:file*/