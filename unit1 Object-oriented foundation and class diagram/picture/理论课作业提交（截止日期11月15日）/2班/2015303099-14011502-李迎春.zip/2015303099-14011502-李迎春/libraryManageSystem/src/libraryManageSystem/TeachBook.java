/**
 * 
 */
package libraryManageSystem;
/**
 * This class models a TeachBook which extends{@link Book}. it adds the following information:
 * <ol>
 * <li>the page  of the book, an <code>int</code></li>
 * </ol>
 * @author ��ӭ��
 * @version  1.0.0
 */
public class TeachBook extends Book{

	private int page;
	/**
	 * construct a <code>TeachBook</code> object without paramters.
	 */
	public TeachBook() {
		
	}
	/**
	 * @return the page
	 */
	public int getPage() {
		return page;
	}
	/**Constructs a <code>TeachBook</code> object.
	 * @param page
	 */
	public TeachBook(String title, String author, boolean availability, int id,int page) {
		super();
		this.page = page;
	}


	/**
	 * Returns the string representation of this TeachBook.
	 *
	 * @return  the string representation of this TeachBook.
	 */
	public String toString(){
		return super.toString()+"page: "+getPage();
	}
}
