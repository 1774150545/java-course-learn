
package libraryManageSystem;


/**
 * This class models a book. it adds the following information:
 * <ol>
 * <li>the author of the book, a <code>String</code></li>
 * <li>the id  of the book, an <code>int</code></li>
 * <li>the availability of the book, a <code>bolean</code></li>
 * <li>the title of the book, a <code>String</code></li>
 * </ol>
 *
 * @author ��ӭ��
 * @version  1.0.0
 */
public class Book {

	private String title;
	private String author;
	private boolean availability;
	private int id;
	
	/**
	 * construct a <code>Book</code> object without paramers.
	 */
	public Book() {
		
	}
	
	

	/**
	 * Constructs a <code>Book</code> object.
	 * 
	 * @param title
	 * @param author
	 * @param availability
	 * @param id
	 */
	public Book(String title, String author, boolean availability, int id) {
		super();
		this.title = title;
		this.author = author;
		this.availability = availability;
		this.id = id;
	}



	/**
	 * Returns the title
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Returns the author
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**Returns the availability
	 * @return the availability
	 */
	public boolean isAvailability() {
		return availability;
	}

	/**Returns the id
	 * @return the id
	 */
	public int getId() {
		return id;
	}


	/**
	 * Returns the string representation of this book.
	 *
	 * @return  the string representation of this book.
	 */
	public String toString(){
		return "title: "+getTitle()+"author: "+getAuthor()+"availability :"+isAvailability()+"id: "+getId();
	}
	
	/**
	 * judge an object whether an {@link Book} object.
	 *
	 * @return  the judge result
	 *
	public boolean equals(Object o){
		
		if(o.equals.this.book)return true;
		else return false;
		
			
	}
*/
}
