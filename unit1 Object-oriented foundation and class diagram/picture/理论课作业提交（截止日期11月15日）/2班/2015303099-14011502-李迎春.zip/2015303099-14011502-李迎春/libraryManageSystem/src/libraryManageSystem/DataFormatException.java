
package libraryManageSystem;

/**
 *  This exception is thrown when malformed data is detected while
 * a file being parsed.
 *
 * @author ����
 * @version 1.2.0.
 */
public class DataFormatException extends Exception {

	/**
	 * Constructs a <code>DataFormatException</code> with no detail
	 * message.
	 */
	public DataFormatException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructs a <code>DataFormatException</code> with the
	 * specified detail message.
	 *
	 * @param message  the malformed data
	 */
	public DataFormatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
