/**
 * 
 */
package libraryManageSystem;

/**
 * This class models a novel which extends{@link Book}. it adds the following information:
 * <ol>
 * <li>the year  of the book, an <code>int</code></li>
 * </ol>
 * @author ��ӭ��
 * @version  1.0.0
 */
public class Novel extends Book{

	private int year;
	/**
	 * construct a <code>Novel</code> object without paramers.
	 */
	public Novel() {
		
	}
	/**Returns the year
	 * @return the year
	 */
	public int getYear() {
		return year;
	}
	
	/**Constructs a <code>Novel</code> object.
	 * @param year
	 */
	public Novel(String title, String author, boolean availability, int id,int year) {
		super();
		this.year = year;
	}
	
	/**
	 * Returns the string representation of this novel.
	 *
	 * @return  the string representation of this novel.
	 */
	public String toString(){
		return super.toString()+"year: "+getYear();
	}
}
