package libraryManageSystem;
/*!Begin Snippet:file*/
import java.util.*;

/**
 * This class implements a method that obtains an XML
 * representation of a {@link BorrowerDatabase} object.
 *
 * @author iCarnegie
 * @version  1.0.0
 * @see BorrowersFormatter
 * @see BorrowerDatabase
 * @see Borrower
 * @see BorrowedItems
 * @see CatalogItem
 */
public class XMLBorrowerFormater
	implements BorrowersFormater  {

	/* Line separator */
	private final static String NEW_LINE = System.getProperty("line.separator");

	/* single instance of this class */
	static private XMLBorrowerFormater singletonInstance = null;

	/**
	 * Obtains the single instance of class
	 * <code>XMLBorrowersFormatter</code>
	 *
	 * @return the single instance  of class
	 *         <code>XMLBorrowersFormatter</code>
	 */
	static public XMLBorrowerFormater getSingletonInstance() {

		if (singletonInstance == null) {
			singletonInstance = new XMLBorrowerFormater();
		}

		return singletonInstance;
	}

	/**
	 * The constructor is declared private so other classes cannot
	 * create an instance of this class.
	 */
	private XMLBorrowerFormater() {

	}

	/**
	 * Obtains an XML representation of the specified borrower
	 * database.
	 *
	 * @param borrowerDB  the borrower database.
	 * @return  a XML representation of the specified
	 *          {@link BorrowerDatabase} object.
	 */
	public String borrowerFormat (BorrowerDatebase borrowerDB) {

		String out = "<BorrowerDatabase>" + NEW_LINE ;

		 ArrayList<Borrower> borrowers=new ArrayList<Borrower>();
		for (Borrower borrower : borrowers) {
			out += "  <Borrower id=\""
					+ borrower.getId()
					+ "\" name=\""
					+ borrower.getName()
					+ "\">"
					+ NEW_LINE;

			BorrowedItem item = borrower.getBorrowedItem();

			ArrayList<Book> books=new ArrayList<Book>();
			
			if (item.getBookNum() > 0) {
				out += "    <BorrowedItems>" + NEW_LINE;

				for (Book book : books){
					out += "      <CatalogItem Title = \""
							+ book.getTitle()
							+ "\"    Author =  \""
							+ book.getAuthor()
							+ "\"    Availability = \""
							+ book.isAvailability()
							+ "\"    Id = \""
							+ book.getId()
							+ "\">"
							
							+ "</CatalogItem>" + NEW_LINE;
				}
				out += "    </BorrowedItems>" + NEW_LINE;
			}
			out += "  </Borrower>" + NEW_LINE;
		}
		out += "</BorrowerDatabase>";

		return out;
	}
}
