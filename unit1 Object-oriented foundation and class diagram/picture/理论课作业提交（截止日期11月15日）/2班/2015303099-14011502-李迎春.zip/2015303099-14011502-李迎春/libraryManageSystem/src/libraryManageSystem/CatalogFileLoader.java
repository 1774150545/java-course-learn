
package libraryManageSystem;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

/**
 * Creates a library catalog and loads it with data stored in
 * a file.
 *
 * @author ��ӭ��
 * @version  1.2.0
 * @see LibraryCatalogLoader
 * @see Borrower
 * @see BorrowedItem
 * @see BookCatalog
 * @see Book
 */
public class CatalogFileLoader implements LibraryCatalogLoader {

	/**
	 * 
	 */
	public CatalogFileLoader() {
		
	}
	
	private final static String NOVEL_PREFIX = "Novel";

	private final static String TEACH_PREFIX = "TeachBook";
	
	private final static String REFER_PREFIX = "ReferenceBook";

	private final static String MAGAZINE_PREFIX = "Magazine";
	
	private final static String DELIM = "_";

	/**
	 * Loads the information in the specified file into a library
	 * catalog and returns the BookCatalog.
	 *
	 * @param filename  The name of a file that contains BookCatalog
	 *                  information.
	 * @return a library BookCatalog.
	 * @throws IOException if there is an error reading the
	 *                     information in the specified file.
	 * @throws FileNotFoundException  if the specified file does not
	 *                                exist.
	 * @throws DataFormatException if the file contains malformed
	 *                             data.
	 */
	public BookCatalog fileLoader (String filename) throws IOException,
			FileNotFoundException, DataFormatException {

		BookCatalog catalog = new BookCatalog();

		BufferedReader reader =
			new BufferedReader(new FileReader(filename));
		String line =  reader.readLine();

		while (line != null) {

			Book book = null;

			if (line.startsWith(NOVEL_PREFIX)) {
				book = readNovel(line);
			} else if (line.startsWith(TEACH_PREFIX)) {
				book = readTeachBook(line);
			} else if (line.startsWith(REFER_PREFIX)) {
				book = readReferenceBook(line);
			} else if (line.startsWith(MAGAZINE_PREFIX)) {
				book = readMagazine(line);
			} else {

				throw new DataFormatException(line);
			}

			catalog.addBook(book);

			line =  reader.readLine();
		}

		reader.close();

		return catalog;
	}

	/**
	 * Extracts the Novel data in the specified line and returns
	 * a {@link Novel} object that encapsulates the book data.
	 *
	 * @param line  a string that contains Novel data.
	 * @return  a <code>Novel</code> object that encapsulates the
	 *          Novel data in the specified line.
	 * @throws DataFormatException if the line contains errors.
	 */
	private Novel readNovel (String line) throws DataFormatException {

		StringTokenizer tokenizer = new StringTokenizer(line, DELIM);

		if (tokenizer.countTokens() != 6) {

			throw new DataFormatException(line);
		} else {
			try {

				String prefix = tokenizer.nextToken();

				return new  Novel (tokenizer.nextToken(),
					tokenizer.nextToken(),
					Boolean.parseBoolean(tokenizer.nextToken()),
					Integer.parseInt(tokenizer.nextToken()),
					Integer.parseInt(tokenizer.nextToken()));

			} catch (NumberFormatException  nfe)  {
System.out.print("23333");
				throw new DataFormatException(line);
			}
		}
	}

	/**
	 * Extracts the TeachBook data in the specified line and returns
	 * a {@link TeachBook} object that encapsulates the book data.
	 *
	 * @param line  a string that contains TeachBook data.
	 * @return  a <code>TeachBook</code> object that encapsulates the
	 *          TeachBook data in the specified line.
	 * @throws DataFormatException if the line contains errors.
	 */
	private TeachBook readTeachBook (String line)
		throws DataFormatException {

		StringTokenizer tokenizer =	new StringTokenizer(line, DELIM);

		if (tokenizer.countTokens() != 6) {

			throw new DataFormatException(line);
		} else {
			try {

				String prefix = tokenizer.nextToken();

				return new TeachBook (
						tokenizer.nextToken(),
					tokenizer.nextToken(),
					Boolean.parseBoolean(tokenizer.nextToken()),
					Integer.parseInt(tokenizer.nextToken()),
					Integer.parseInt(tokenizer.nextToken()));

			} catch (NumberFormatException  nfe)  {

				throw new DataFormatException(line);
			}
		}
	}
	
	/**
	 * Extracts the ReferenceBook data in the specified line and returns
	 * a {@link ReferenceBook} object that encapsulates the book data.
	 *
	 * @param line  a string that contains ReferenceBook data.
	 * @return  a <code>ReferenceBook</code> object that encapsulates the
	 *          book data in the specified line.
	 * @throws DataFormatException if the line contains errors.
	 */
	private ReferenceBook readReferenceBook (String line) throws DataFormatException {

		StringTokenizer tokenizer = new StringTokenizer(line, DELIM);

		if (tokenizer.countTokens() != 6) {

			throw new DataFormatException(line);
		} else {
			try {

				String prefix = tokenizer.nextToken();

				return new  ReferenceBook (
						tokenizer.nextToken(),
						tokenizer.nextToken(),
						Boolean.parseBoolean(tokenizer.nextToken()),
						Integer.parseInt(tokenizer.nextToken()),
					tokenizer.nextToken()
					);

			} catch (NumberFormatException  nfe)  {

				throw new DataFormatException(line);
			}
		}
	}

	/**
	 * Extracts the Magazine data in the specified line and returns
	 * a {@link Magazine} object that encapsulates the book data.
	 *
	 * @param line  a string that contains Magazine data.
	 * @return  a <code>Magazine</code> object that encapsulates the
	 *          Magazine data in the specified line.
	 * @throws DataFormatException if the line contains errors.
	 */
	private Magazine readMagazine (String line)
		throws DataFormatException {

		StringTokenizer tokenizer =	new StringTokenizer(line, DELIM);

		if (tokenizer.countTokens() != 6) {

			throw new DataFormatException(line);
		} else {
			try {

				String prefix = tokenizer.nextToken();

				return new Magazine (
						tokenizer.nextToken(),
						tokenizer.nextToken(),
						Boolean.parseBoolean(tokenizer.nextToken()),
						Integer.parseInt(tokenizer.nextToken()),
					Double.parseDouble(tokenizer.nextToken()));

			} catch (NumberFormatException  nfe)  {

				throw new DataFormatException(line);
			}
		}
	}

}
