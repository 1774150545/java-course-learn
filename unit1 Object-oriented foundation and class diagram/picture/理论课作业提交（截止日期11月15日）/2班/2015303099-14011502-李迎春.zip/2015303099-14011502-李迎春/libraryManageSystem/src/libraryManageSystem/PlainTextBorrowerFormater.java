package libraryManageSystem;
/*!Begin Snippet:file*/
import java.util.*;

/**
 * This class implements a method that obtains a plain text
 * representation of a {@link BorrowerDatabase} object.
 * @author iCarnegie
 * @version  1.0.0
 * @see BorrowersFormatter
 * @see BorrowerDatabase
 * @see Borrower
 * @see BorrowedItems
 * @see CatalogItem
 */
public class PlainTextBorrowerFormater
	implements BorrowersFormater  {

	/* Line separator */
	private final static String NEW_LINE = System.getProperty("line.separator");

	/* single instance of this class */
	static private PlainTextBorrowerFormater singletonInstance = null;

	/**
	 * Obtains the single instance of class
	 * <code>PlainTextBorrowersFormatter</code>
	 *
	 * @return the single instance  of class
	 *         <code>PlainTextBorrowersFormatter</code>
	 */
	static public PlainTextBorrowerFormater getSingletonInstance(){

		if (singletonInstance == null) {
			singletonInstance = new PlainTextBorrowerFormater();
		}

		return singletonInstance;
	}

	/**
	 * The constructor is declared private so other classes cannot
	 * create an instance of this class.
	 */
	private PlainTextBorrowerFormater() {

	}

	/**
	 * Obtains a plain text representation of the specified borrower
	 * database.
	 *
	 * @param borrowerDB  the borrower database.
	 * @return  a plain text representation of the specified
	 *          {@link BorrowerDatabase} object.
	 */
	public String borrowerFormat (BorrowerDatebase borrowerDB) {

		String out = "Borrower Database" + NEW_LINE;
        int num=1;
		ArrayList<Borrower> borrowers= new ArrayList<Borrower>();
		for (Borrower borrower : borrowers) {
            out+="Borrower " + num + NEW_LINE;
			out +="Borrowers information: "+ borrower.getId() + "_" + borrower.getName()+NEW_LINE;
			
           ArrayList<Book>  books=new ArrayList<Book>();
           BorrowedItem item = borrower.getBorrowedItem();
           
           
        	   for (Book book : books) {

				out +=  " Book information:        "
						+ book.getTitle()
						+ " "
						+ book.getAuthor()
						+ " "
						+ book.isAvailability()
						+ " "
						+ book.getId()+NEW_LINE;
			}
			out += NEW_LINE;
			num++;
		}

		return out;
	}

}


	
