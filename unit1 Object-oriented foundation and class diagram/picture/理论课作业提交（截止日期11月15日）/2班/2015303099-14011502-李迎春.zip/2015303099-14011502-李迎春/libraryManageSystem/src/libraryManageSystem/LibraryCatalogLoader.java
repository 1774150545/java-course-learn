
package libraryManageSystem;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * This interface declares a method for obtaining a library book catalog
 * from a file.
 *
 * @author ��ӭ��
 * @version 1.2.0
 * @see BookCatalog
 */
public interface LibraryCatalogLoader {

	/**
	 * Loads the information in the specified file into a library
	 * catalog and returns the BookCatalog.
	 *
	 * @param filename  the name of the file that contains the
	 *                  book catalog data.
	 * @return  a {@link BookCatalog}.
	 * @throws IOException if there is an error reading the
	 *                     information in the specified file.
	 * @throws FileNotFoundException  if the specified file does not
	 *                                exist.
	 * @throws DataFormatException if the file contains badly-formed
	 *                             data.
	 */
	public BookCatalog fileLoader(String filename)throws IOException,
    FileNotFoundException, DataFormatException;
}
