/**
 * 
 */
package libraryManageSystem;
/**
 * This class models a ReferenceBook which extends{@link Book}. it adds the following information:
 * <ol>
 * <li>the type  of the book, an <code>String</code></li>
 * </ol>
 * @author ��ӭ��
 * @version  1.0.0
 */
public class ReferenceBook extends Book{

	private String type;
	/**
	 * construct a <code>ReferenceBook</code> object without paramers.
	 */
	public ReferenceBook() {
		
	}

	/**return the type
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**Constructs a <code>ReferenceBook</code> object.
	 * @param type
	 */
	public ReferenceBook(String title, String author, boolean availability, int id,String type) {
		super();
		this.type = type;
	}


	/**
	 * Returns the string representation of this ReferenceBook.
	 *
	 * @return  the string representation of this ReferenceBook.
	 */
	public String toString(){
		return super.toString()+"type: "+getType();
	}
}
