/**
 * 
 */
package libraryManageSystem;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Iterator;


/**
 * This class implements a sample of the library system.
 *
 * @author ��ӭ��
 * @version 1.2.0
 * @see BookCatalog
 * @see Book
 * @see BorrowedItem
 * @see Borrower
 * @see BorrowerDatebase
 * @see BorrowerFormater
 * @see PlainTextBorrowerFormater
 * @see HTMLBorrowerFormater
 * @see XMLBorrowerFormater
 * @see CatalogFileLoader
 * @see LibraryCatalogLoader
 */
public class LibrarySystem {

	private static BufferedReader  stdIn =
			new  BufferedReader(new  InputStreamReader(System.in));
	private static PrintWriter  stdOut =
			new  PrintWriter(System.out, true);
	private static PrintWriter  stdErr =
			new  PrintWriter(System.err, true);

	private BookCatalog  bookCatalog=load();

	private BorrowerDatebase borrowerDateBase;

	private BorrowersFormater borrowersFormater;

	public LibrarySystem() {
		
	}

	public static void  main(String[]  args) throws IOException {

		if (args.length != 1) {
			stdErr.println("Usage: java LibrarySystem filename");
		} else {

			BookCatalog bookCatalog = null;

			try {

				LibraryCatalogLoader loader =
						new CatalogFileLoader();

				bookCatalog = loader.fileLoader(args[0]);
			} catch (FileNotFoundException fnfe) {
				stdErr.println("The file does not exist");

				System.exit(1);
			
			} catch (DataFormatException dfe) {
				stdErr.println("The file contains malformed data: "
				               + dfe.getMessage());

				System.exit(1);
			}

			LibrarySystem  app = new LibrarySystem(bookCatalog);

			app.run();
		}
	}
	
	
	
	/**
	 * Constructs a <code>LibrarySystem</code> object.
	 * Initialize the catalog and borrower database with
	 * the values specified in the parameter.
	 */
	private LibrarySystem(BookCatalog bookCatalog) {

		
		borrowerDateBase = loadBorrowers(bookCatalog);
		borrowersFormater =
				PlainTextBorrowerFormater.getSingletonInstance();
		BookCatalog catalog  = load();
		loadBorrowers(catalog);
		
	}

	private BorrowerDatebase loadBorrowers(BookCatalog bookCatalog) {
		
		BorrowerDatebase borrowerDateBase = new BorrowerDatebase();
		
		Borrower borrower = new Borrower("ID001","Taylor");
		borrower.getBorrowedItem().addBook(
				bookCatalog.getById(001));		
		borrower.getBorrowedItem().addBook(
				bookCatalog.getById(002));		
		borrower.getBorrowedItem().addBook(
				bookCatalog.getById(003));
		
		borrower=new Borrower("ID002","Kata");
		borrowerDateBase.addBorrower(borrower);
		
		borrower=new Borrower("ID003","Lucy");
		borrower.getBorrowedItem().addBook(
				bookCatalog.getById(002));
		borrower.getBorrowedItem().addBook(
				bookCatalog.getById(003));
		borrowerDateBase.addBorrower(borrower);
		
		
		borrower=new Borrower("ID004","Fralor");
		borrower.getBorrowedItem().addBook(
				bookCatalog.getById(001));		
		borrower.getBorrowedItem().addBook(
				bookCatalog.getById(002));		
		borrower.getBorrowedItem().addBook(
				bookCatalog.getById(003));
		borrowerDateBase.addBorrower(borrower);
		
		borrower=new Borrower("ID005","Katty");
		borrowerDateBase.addBorrower(borrower);
		
		borrower = new Borrower("ID006", "Laura Novelle");
		borrower.getBorrowedItem().addBook(bookCatalog.getById(004));
		borrower.getBorrowedItem().addBook(bookCatalog.getById(002));
		borrowerDateBase.addBorrower(borrower);

		borrower = new Borrower("ID007", "David M. Prescott");
		borrower.getBorrowedItem().addBook(bookCatalog.getById(005));
		borrowerDateBase.addBorrower(borrower);

		borrower = new Borrower("ID008", "Francis Matthews");
		borrower.getBorrowedItem().addBook(bookCatalog.getById(006));
		borrower.getBorrowedItem().addBook(bookCatalog.getById(007));
		borrowerDateBase.addBorrower(borrower);

		borrower = new Borrower("ID009", "Thomas Ferris");
		borrowerDateBase.addBorrower(borrower);

		borrower = new Borrower("ID010", "John Johnson");
		borrower.getBorrowedItem().addBook(bookCatalog.getById(005));
		borrowerDateBase.addBorrower(borrower);
		
		return borrowerDateBase;
	}
	
	/**
	 * Loads the information of a Catalog object.
	 */
	private static BookCatalog load ()  {

		BookCatalog catalog = new BookCatalog();

		catalog.addBook(new Novel( "Effective Java Programming","Joshua Bloch", true,001,2012
		                          ));
		catalog.addBook(new Novel( "Design Patterns","Erich Gamma et al",false,002, 1995
		                          ));
		catalog.addBook(new Magazine("Refactoring","Martin Fowler",true,003, 
		                          31.00));
		catalog.addBook(new Magazine("The Mythical Man-Month","Frederick P. Brooks",true, 004,
		                          22.00));
		catalog.addBook(new ReferenceBook( "Code Complete", "Steve C McConnell",true, 005,"math"
		                         ));
		catalog.addBook(new ReferenceBook( "The Psychology of Comp. Progr.","Gerald M. Weinberg",
				                       true,006,"English"));
		catalog.addBook(new TeachBook( "Programming Pearls ",  "Jon Bentley",true,007,184
		                         ));
	
		return catalog;
	}

	
	
	/**
	 * Presents the user with a menu of options and processes the selection.
	 */
	private void run() throws IOException  {

		int  choice = getChoice();

		while (choice != 0)  {

			if (choice == 1)  {
				displayBookCatalog();
			} else if (choice == 2)  {
				displayBorrowedItem();
			} else if (choice == 3)  {
				this.borrowersFormater = HTMLBorrowerFormater.getSingletonInstance();
				displayBorrowers();
			} else if (choice == 4)  {
				this.borrowersFormater = XMLBorrowerFormater.getSingletonInstance();
				displayBorrowers();
			} else if (choice == 5)  {
				this.borrowersFormater = PlainTextBorrowerFormater.getSingletonInstance();
				displayBorrowers();
			} else if (choice == 6)  {
				displayBorrowerDatabase();
			} else if (choice == 7)  {
				displayBorrower();
			} else if (choice == 8)  {
				checkOut();
			} else if (choice == 9)  {
				checkIn();
			}

			choice = getChoice();
		}
	}

	

	
	/* Validates the user's choice. */
	private int  getChoice() throws IOException  {

		int  input;

		do  {
			try  {
				stdErr.println();
				stdErr.print("[0]  Quit\n"
				             + "[1]  Display the book catalogs\n"
				             + "[2]  Display the Borrowed items(Console)\n"
				             + "[3]  Display Borrowed items (Plain Text)\n"
				             + "[4]  Display Borrowed items(HTML)\n" 
				             + "[5]  Display Borrowed items(XML)\n"
				          
				             + "[6]  Display borrowers\n"
				             + "[7]  Display borrowed items\n"
				             + "[8]  Check out\n"
				             + "[9]  Check in\n"
				             + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 6 >= input)  {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException  nfe)  {
				stdErr.println(nfe);
			}
		}  while (true);

		return  input;
	}
	
	private void displayBookCatalog() {

		if (this.bookCatalog.getBookNum() == 0) {
				stdErr.println("The book catalog is empty!");
		} else {
			 Iterator<Book> iterator = this.bookCatalog.iterator();
			 for(;iterator.hasNext();) {
				 Book book = iterator.next();
			 	stdOut.println("    title = "+book.getTitle() + "     author= " + book.getAuthor()
			 	+ "     Availability = "
				               + book.isAvailability()+"    id ="+book.getId());
			 }
			 
		}
	}
	
	/**
	 * Displays a catalog item.
	 */
	private void displayBorrowedItem()  throws IOException  {

		Book item = readBorrowedItem();

		if (item != null) {
			stdOut.println("  Title: " + item.getTitle());
			stdOut.println("  Author: " + item.getAuthor());
			if (item instanceof Novel) {

				Novel novel = (Novel) item;

				stdOut.println("  Year: " + novel.getYear());
			
			} else if (item instanceof Magazine) {

				Magazine magazine = (Magazine) item;

				stdOut.println("  Price: " + magazine.getPrice());
			
			}if (item instanceof ReferenceBook) {

				ReferenceBook referenceBook = (ReferenceBook) item;

				stdOut.println("  Type: " + referenceBook.getType());
			
			} else if (item instanceof TeachBook) {

				TeachBook teachBook = (TeachBook) item;

				stdOut.println("  Number of pages: " + teachBook.getPage());
			
			}
			stdOut.println(
				"  Status: "
				+ (item.isAvailability() ? "Available" : "Not available"));
		} else {
			stdErr.println("There is no catalog item with that id");
		}
	}
	
	/**
	 * Displays a borrower.
	 */
	private void displayBorrower()  throws IOException  {

		Borrower borrower = readBorrower();

		if (borrower != null) {

			stdOut.println("  Name: " + borrower.getName());

			BorrowedItem borrowedItem = borrower.getBorrowedItem();
			
			Iterator<Book> iterator=borrowedItem.iterator();
            
			if (borrowedItem.getBookNum() == 0) {
				stdOut.println("  No books borrowed");
			} else {
				stdOut.println("  Books Borrowed:");
				
				for(;iterator.hasNext();) {
					 Book book = iterator.next();
				 	stdOut.println("    title = "+book.getTitle() + "     author= " + book.getAuthor()
				 	+ "     Availability = "
					               + book.isAvailability()+"    id ="+book.getId());
				 }
			}
		} else {
			stdErr.println("There is no borrower with that id");
		}
	}
	
	/**
	 * Displays the borrower database.
	 */
	private void displayBorrowerDatabase() {

		if (this.borrowerDateBase.getBorrowerNum() == 0) {
			stdErr.println("The database of borrowers is empty");
		} else {
			Iterator<Borrower> iterator=borrowerDateBase.iterator();
			for(;iterator.hasNext();) {
				Borrower borrower = iterator.next(); 
				stdOut.println(borrower.getId() + " " + borrower.getName());
			}
		}
	}
	
	/**
	 * Registers the loan of a item to a borrower.
	 */
	private void checkOut()  throws IOException  {

		Book item = readBorrowedItem();

		if (item == null) {
			stdErr.println("There is no book  with that id");
		} else if (item.isAvailability()) {

			Borrower borrower = readBorrower();

			if (borrower == null) {
				stdErr.println("There is no borrower with that id");
			} else {
				borrower.getBorrowedItem().addBook(item);
				stdOut.println("The book " + item.getTitle() +" with the id "+item.getId()
				               + " has been check out by " + borrower.getName());
			}
		} else {
			stdErr.println("The item " +  item.getId() +
			               " is not available");
		}
	}

	/**
	 * Registers the return of a book.
	 */
	private void checkIn()  throws IOException  {

		Book item = readBorrowedItem();

		if (item == null) {
			stdErr.println(
				"There is no book with that id");
		} else if (item.isAvailability()) {
			stdErr.println("The book " +  item.getId() + " is not borrowed");
		} else {

			Borrower borrower = readBorrower();

			if (borrower == null) {
				stdErr.println("There is no borrower with that id");
			} else {
				borrower.getBorrowedItem().removeBook(item);
				stdOut.println("The book" +  item.getId()
				               + " has been returned");
			}
		}
	}

	/**
	 * Obtains a CatalogItem object  .
	 */
	private  Book readBorrowedItem() throws IOException  {

		stdErr.print("Borrowed item id> ");
		stdErr.flush();

		return this.bookCatalog.getById(Integer.parseInt(stdIn.readLine()));
	}
	
	/**
	 * Obtains a Borrower object  .
	 */
	private  Borrower readBorrower()  throws IOException  {

		stdErr.print("Borrower id> ");
		stdErr.flush();

		return this.borrowerDateBase.getBorrower(stdIn.readLine());
	}


	/**
	 * Displays the sales information in the current format.
	 */
	private void displayBorrowers() {

		stdOut.println(this.borrowersFormater.borrowerFormat(this.borrowerDateBase));
	}
}
