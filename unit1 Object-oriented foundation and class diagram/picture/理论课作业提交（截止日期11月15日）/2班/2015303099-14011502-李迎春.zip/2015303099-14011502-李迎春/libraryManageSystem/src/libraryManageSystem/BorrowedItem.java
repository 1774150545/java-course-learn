
package libraryManageSystem;

import java.util.ArrayList;
import java.util.Iterator;


/**
 * @author ����
 *
 */
public class BorrowedItem implements Iterator<Book>{

	private ArrayList<Book> books=new ArrayList<Book>();
	/**
	 * 
	 */
	public BorrowedItem() {
		
	}
	

	/**
	 * Adds a {@link Book} object to this collection and
	 * sets the {@link Book} object as not available.
	 *
	 * @param catalogItem  the {@link Book} object.
	 */
	public boolean addBook(Book book)  {

		if(this.books.add(book))
		       return true;
		else  return false;
	}

	/**
	 * Removes a {@link Book} object from this collection
	 * and sets the {@link Book} object as available.
	 *
	 * @param id   the id of the book.
	 */
	public boolean  removeBook(Book book)  {

		for(Book b:books){
			if(book.equals(b)) return true;
		}
		return false;
		
	}

	/**
	 * Returns an iterator over the borrowed items in this collection.
	 *
	 * return  an {@link Iterator} of {@link CatalogItem}
	 */
	public Iterator<Book> iterator() {

		return this.books.iterator();
	}

	/**
	 * Returns the {@link Book} object with the specified
	 * <code>id</code>.
	 *
	 * @param id  the id of a book.
	 * @return  The {@link Book} object with the specified
	 *          id. Returns <code>null</code> if the object with
	 *          the id is not found.
	 */
	public Book getById(int id)  {

		for(Book book:books){ 
			if (id==book.getId()) {
				return book;
			}
		}

		return null;
	}

	/**
	 * Returns the {@link Book} object with the specified
	 * <code>title</code>.
	 *
	 * @param title  the title of a book.
	 * @return  The {@link Book} object with the specified
	 *          title. Returns <code>null</code> if the object with
	 *          the title is not found.
	 */
	public Book getByTitle(String title)  {

		for(Book book:books){ 
			if (title.equals(book.getTitle())) {
				return book;
			}
		}

		return null;
	}
	
	/**
	 * Returns the number of books.
	 *
	 * @return  the number of boos.
	 */
	public int  getBookNum()  {

		return this.books.size();
	}


	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public Book next() {
		// TODO Auto-generated method stub
		return null;
	}
}



