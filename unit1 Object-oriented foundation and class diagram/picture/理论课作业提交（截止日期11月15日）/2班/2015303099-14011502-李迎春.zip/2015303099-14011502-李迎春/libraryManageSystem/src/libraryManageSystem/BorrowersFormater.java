/**
 * 
 */
package libraryManageSystem;


/**
 * This interface defines a method that obtains a string
 * representation of a {@link BorrowerDatabase} object.
 *
 * @author ����
 * @version 1.2.0
 * @see BorrowerDatebase
 */
public interface BorrowersFormater {

	/**
	 * Obtains the string representation of the specified borrower
	 * database.
	 *
	 * @param borrowerDB  the borrower database.
	 * @return  the string representation of the specified
	 *          {@link BorrowerDatabase} object.
	 */
	public String borrowerFormat(BorrowerDatebase borrowerDB);
}
