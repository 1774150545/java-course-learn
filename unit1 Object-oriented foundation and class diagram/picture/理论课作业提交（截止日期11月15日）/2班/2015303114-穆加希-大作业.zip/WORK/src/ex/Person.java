package ex;

public class Person {
	private String name="";//���ո�����
	private String homeTelephone="";
	private String email="";
	/**
	 * ���캯��
	 */
	public Person(){
		
	}
	/**
	 * ���캯������
	 * @param name
	 * @param homeTelephone
	 * @param email
	 */
	public Person(String name, String homeTelephone, String email) {
		super();
		this.name = name;
		this.homeTelephone = homeTelephone;
		this.email = email;
	}
	/**
	 * �õ�����
	 * @return
	 */
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	/**
	 *�õ��绰����
	 * @return
	 */
	public String getHomeTelephone() {
		return homeTelephone;
	}
	public void setHomeTelephone(String homeTelephone) {
		this.homeTelephone = homeTelephone;
	}
	/**
	 * �õ�����
	 * @return
	 */
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String toString(){
		return " "+name+" "+ homeTelephone+" "+email;
	}

}
