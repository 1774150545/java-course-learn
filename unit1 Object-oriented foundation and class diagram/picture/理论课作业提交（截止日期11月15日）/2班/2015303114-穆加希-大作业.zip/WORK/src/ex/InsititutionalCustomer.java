package ex;
/**
 * �����ͻ���Ϣ��
 * @author admin
 *
 */
public class InsititutionalCustomer extends Customer {
	private Contact contact = new Contact();

	public InsititutionalCustomer(String customId, Contact contact) {
		super(customId);
		this.contact = contact;
	}
/**
 * �õ�contact
 * @return
 */
	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}
	public String toString(){
		return this.getCustomId();
	}
}
