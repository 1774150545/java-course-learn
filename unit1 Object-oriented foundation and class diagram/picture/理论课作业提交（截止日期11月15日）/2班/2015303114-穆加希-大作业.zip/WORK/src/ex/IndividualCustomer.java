package ex;
/***
 * ����ͻ���
 * @author admin
 *
 */
public class IndividualCustomer extends Customer{
	private Person person=new Person();
	
/**
 * ���캯��
 * @param customId
 * @param person
 */
	public IndividualCustomer(String customId,Person person) {
		super(customId);
		this.person = person;
	}
/**
 * �õ�person����
 * @return
 */
	public Person getPerson() {
		return person;
	}
/**
 * ����person
 * @param person
 */
	public void setPerson(Person person) {
		this.person = person;
	}
	public String toString(){
		return getCustomId();
	}
  
}
