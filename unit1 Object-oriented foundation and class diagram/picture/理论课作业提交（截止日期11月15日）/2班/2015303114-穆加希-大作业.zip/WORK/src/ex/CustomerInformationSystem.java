package ex;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.*;


/**
 * �˿���Ϣ����ϵͳ�����Խ��й˿���Ϣ������ɾ�����������
 * @author admin
 *
 */
public class CustomerInformationSystem{

	static ArrayList<Customer> customers=new ArrayList<Customer>();
	
	private static BufferedReader  stdIn =
		new  BufferedReader(new  InputStreamReader(System.in));
	private static PrintWriter  stdOut =
		new  PrintWriter(System.out, true);
	private static PrintWriter  stdErr =
		new  PrintWriter(System.err, true);
	
	/**
	 * ����һ��IndividualCustomer�ı���
	 * @throws IOException
	 */
	public void addIndividualCustomer()throws IOException{
		stdErr.println("customerId> ");
		String customerId=stdIn.readLine();
		for(int i=0;i<customers.size();i++){
			while(customers.get(i).getCustomId().equals(customerId)){
				stdErr.println("have repeating customerId ");
				stdErr.println("please printIn customerId again> ");
				customerId=stdIn.readLine();
			}
		}
		stdErr.println("name> ");
		String name=stdIn.readLine();
		stdErr.println("homeTelephone> ");
		String homeTelephone=stdIn.readLine();
		stdErr.println("email> ");
		String email=stdIn.readLine();
		Person person=new Person(name,homeTelephone,email);
		IndividualCustomer individualCustomerCustomer=new IndividualCustomer(customerId,person);
		customers.add(individualCustomerCustomer);
		stdErr.println("add success! ");
	}
	/**
	 * ����һ��InsititutionalCustomer�ı���
	 * @throws IOException
	 */
	public void addInsititutionalCustomer()throws IOException{
		stdErr.println("customerId> ");
		String customerId=stdIn.readLine();
		for(int i=0;i<customers.size();i++){
			while(customers.get(i).getCustomId().equals(customerId)){
				stdErr.println("have repeating customerId ");
				stdErr.println("please printIn customerId again> ");
				customerId=stdIn.readLine();
			}
		stdErr.println("name> ");
		String name=stdIn.readLine();
		stdErr.println("homeTelephone> ");
		String homeTelephone=stdIn.readLine();
		stdErr.println("email> ");
		String email=stdIn.readLine();
		stdErr.println("workTelephone> ");
		String workTelephone=stdIn.readLine();
		stdErr.println("jobPosition> ");
		String jobPosition=stdIn.readLine();
		Contact contact=new Contact(name,homeTelephone,email,workTelephone,jobPosition);
		InsititutionalCustomer insititutionalCustomer=new InsititutionalCustomer(customerId,contact);
		customers.add(insititutionalCustomer);
		stdErr.print("add success! ");
	}
	}
	/**
	 * ����id��customer����Ϣ
	 * @throws IOException
	 */
	
	public void getCustomer() throws IOException{
		stdErr.println("customerId> ");
		String str=stdIn.readLine();
		String customId=str;
		String a="";
		int w=0;// ���customerId�Ƿ���ƥ����
		for(int i=0;i<customers.size();i++){
			if(customers.get(i).getCustomId().equals(customId)&&customers.get(i) instanceof InsititutionalCustomer ){
				a+=customers.get(i).getCustomId()+" ";
				a+=((InsititutionalCustomer) customers.get(i)).getContact().toString();
				stdErr.println(a);
				w++;
			}
			else if(customers.get(i).getCustomId().equals(customId)&&customers.get(i) instanceof IndividualCustomer ){
				a+=customers.get(i).getCustomId()+" ";
				a+=((IndividualCustomer) customers.get(i)).getPerson().toString();
				stdErr.println(a);
				w++;
			}
		}
		if(w==0){
			stdErr.println("Donnot have this customer ");
		}
	}
	/**
	 * ����id�Ƴ�customer����Ϣ
	 * @throws IOException
	 */
	public void removeCustomer() throws IOException{
		stdErr.println("customerId> ");
		String str=stdIn.readLine();
		int w=0;// ���customerId�Ƿ���ƥ����
		for(int i=0;i<customers.size();i++){
			if(customers.get(i).getCustomId().equals(str)){
				customers.remove(customers.get(i));
				stdErr.println("delete successfully!");
				w++;
			}
		}
		if(w==0){
			stdErr.println("Donnot have this customer ");
		}
	}
	/**
	 * ����id��customer��������Ϣ
	 */
	public void displayCustomers() {

		int size = customers.size();
		
		if (size == 0) {
			stdErr.println("The catalog is empty");
		} else {
			for (int i=0;i<size;i++) {
				if(customers.get(i) instanceof InsititutionalCustomer ){
					
					stdErr.println(customers.get(i).getCustomId()+" "+((InsititutionalCustomer) customers.get(i)).getContact().toString());
				}
				else if(customers.get(i) instanceof IndividualCustomer ){
					stdErr.println(customers.get(i).getCustomId()+" "+((IndividualCustomer) customers.get(i)).getPerson().toString());
				}
			}
		}
	}
	public static void  main(String[] args) throws IOException  {
		Contact contact1=new Contact("zhangsan","15519898984","15519898984@qq.com","15589898921","shanghai");
		Contact contact2=new Contact("lisi","15419898934","15419898934@qq.com","15531232132","shanghai");
		Contact contact3=new Contact("wangwu","15419894345","15419891241@qq.com","15577772132","shandong");
		Contact contact4=new Contact("zhangyi","15419898555","15441248934@qq.com","1553123412","shanghai");
		Person  person1=new Person("wangsi","154198123235","154411248934@qq.com");
		Person  person2=new Person("zhaosi","154132334235","143934@qq.com");
		IndividualCustomer individualCustomer1=new IndividualCustomer("1",person1);
		IndividualCustomer individualCustomer2=new IndividualCustomer("2",person2);
		InsititutionalCustomer insititutionalCustomer1=new InsititutionalCustomer("3",contact1);
		InsititutionalCustomer insititutionalCustomer2=new InsititutionalCustomer("4",contact2);
		InsititutionalCustomer insititutionalCustomer3=new InsititutionalCustomer("5",contact3);
		InsititutionalCustomer insititutionalCustomer4=new InsititutionalCustomer("6",contact4);
		customers.add(individualCustomer1);
		customers.add(individualCustomer2);
		customers.add(insititutionalCustomer1);
		customers.add(insititutionalCustomer2);
		customers.add(insititutionalCustomer3);
		customers.add(insititutionalCustomer4);
		CustomerInformationSystem  application = new CustomerInformationSystem();
		application.run();
	}
	
	
		private void run() throws IOException  {

			int choice = getChoice();

			while (choice != 0)  {
				if (choice == 1)  {
					displayCustomers();
				} 
				else if (choice == 2) {
					addIndividualCustomer();
				} else if (choice == 3)  {
					addInsititutionalCustomer();
				} else if (choice == 4)  {
					removeCustomer();
				} else if (choice == 5)  {
					getCustomer();
				}	
				choice = getChoice();
			}
		}
		
		private int  getChoice() throws IOException  {

			int  input;

			do  {
				try  {
					stdErr.println();
					stdErr.print(
						  "[0] Quit\n"
						+ "[1] Display allcustomers\n"
						+ "[2] Add a InsititutionalCustomer into the system\n"
						+ "[3] Add a IndividualCustomer into the system\n"
						+ "[4] Remove a Customer by Id\n"
						+ "[5] find a customer by Id\n"
						+ "choice> ");
					stdErr.flush();

					input = Integer.parseInt(stdIn.readLine());

					stdErr.println();

					if (0 <= input && 5 >= input)  {
						break;
					} else {
						stdErr.println("Invalid choice:  " + input);
					}
				} catch (NumberFormatException  nfe)  {
					stdErr.println(nfe);
				}
			}  while (true);

			return  input;
		}
}
