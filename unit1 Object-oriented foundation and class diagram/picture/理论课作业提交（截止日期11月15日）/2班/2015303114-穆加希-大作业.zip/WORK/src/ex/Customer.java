package ex;
/**
 * �˿ͻ���
 * @author admin
 *
 */
public class Customer {
	private String customId="";
	/**
	 * ���캯��
	 * @param customId
	 */
	public Customer(String customId) {
		super();
		this.customId = customId;
	}
/**
 * �õ�id
 * @return
 */
	public String getCustomId() {
		return customId;
	}

	public void setCustomId(String customId) {
		this.customId = customId;
	}
	

}
