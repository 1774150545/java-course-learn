package ex;
/**
 * contact����
 * @author admin
 *
 */
public class Contact extends Person{

	private String workTelephone="";
	private String jobPosition="";
	/**
	 * ���캯��
	 */
	public Contact() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * ���캯������
	 * @param name
	 * @param homeTelephone
	 * @param email
	 * @param workTelephone
	 * @param jobPosition
	 */
	public Contact(String name, String homeTelephone, String email,String workTelephone, String jobPosition) {
		super(name,homeTelephone,email);
		this.workTelephone = workTelephone;
		this.jobPosition = jobPosition;
	}
	/**
	 * �õ������绰
	 * @return
	 */
	public String getWorkTelephone() {
		return workTelephone;
	}
	public void setWorkTelephone(String workTelephone) {
		this.workTelephone = workTelephone;
	}
	/**
	 * �õ�������ַ
	 * @return
	 */
	public String getJobPosition() {
		return jobPosition;
	}
	public void setJobPosition(String jobPosition) {
		this.jobPosition = jobPosition;
	}
	public String toString(){
		return super.toString()+" "+"InsititutionalCustomer"+" "+workTelephone+" "+jobPosition;
	 }
}
