package PersonalFinancial;

import java.util.ArrayList;
/**
 * �����Ŀ�
 * @author �쳿��
 *
 */
public class IncomeCatalog {
	private ArrayList<Income> income = new ArrayList<Income>();

	/**
	 * @param income
	 */
	public IncomeCatalog(ArrayList<Income> income) {
		super();
		this.income = new ArrayList<Income>();
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<Income> getIncome() {
		return income;
	}

	/**
	 * 
	 * @param income
	 */
	public void setIncome(ArrayList<Income> income) {
		this.income = income;
	}

	/**
	 * 
	 */
	@Override
	public String toString() {
		String str = new String();
		for (int i = 0; i < income.size(); i++) {
			str = str + income.get(i) + " ";
		}
		return str;
	}

	/**
	 * 
	 * @param readLine
	 * @return
	 */
	public Income findUserIncomeByCode(String readLine) {
		// TODO Auto-generated method stub
		for (int i = 0; i < income.size(); i++) {
			if (income.get(i).getCode().equals(readLine)) {
				return income.get(i);
			}
		}
		return null;
	}

	/**
	 * 
	 * @param tempIncome
	 */
	public void addIncome(Income tempIncome) {
		// TODO Auto-generated method stub
		income.add(tempIncome);
	}

}
