package PersonalFinancial;

public class Income extends User {

	private String source;
	private double number;

	/**
	 * @param source
	 * @param total
	 */
	public Income(String code, String name, String telephone, double total,
			String source, double number) {
		super(code, name, telephone, total);
		this.source = source;
		this.number = number;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public double getNumber() {
		return number;
	}

	public void setNumber(double number) {
		this.number = number;
	}
    /**
     * 
     */
	@Override
	public String toString() {
		return "o	------------------------" + "\n" + "o	code of the user:"
				+ getCode() + ";\n" + "o	name of the user:" + getName() + ";\n"
				+ "o	telephone of the user:" + getTelephone() + ";\n"
				+ "o	initialmoney of the user:" + getInitial() + ";\n"
				+ "o	source of the income:" + source + ";\n"
				+ "o	number of the income:" + number;
	}

}
