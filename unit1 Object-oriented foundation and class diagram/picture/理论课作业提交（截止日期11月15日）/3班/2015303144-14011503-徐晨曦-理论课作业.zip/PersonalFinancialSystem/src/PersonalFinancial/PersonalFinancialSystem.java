package PersonalFinancial;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.NumberFormat;

public class PersonalFinancialSystem {
	private static BufferedReader stdIn = new BufferedReader(
			new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);

	private static final NumberFormat CURRENCY = NumberFormat
			.getCurrencyInstance();

	private IncomeCatalog incomeCatalog;
	private DisbursementCatalog disbursementCatalog;

	private PersonalFinancialSystem() {

		this.incomeCatalog = loadIncomeCatalog();
		this.disbursementCatalog = loaddisbursementCatalog();
	}

	/**
	 * ��ʼ��֧��Ŀ¼
	 * @return
	 */
	private DisbursementCatalog loaddisbursementCatalog() {
		// TODO Auto-generated method stub
		DisbursementCatalog disbursementCatalog = new DisbursementCatalog(null);
		disbursementCatalog.addDisbursement(new Disbursement("A001", "С��",
				"13345623236", 1400.5, "daily", 657.9));
		disbursementCatalog.addDisbursement(new Disbursement("A002", "С��",
				"14388275631", 3100.89, "daily", 453.1));
		disbursementCatalog.addDisbursement(new Disbursement("A003", "С��",
				"18765431211", 450, "hospital", 1300));
		return disbursementCatalog;
	}

	/**
	 * ��ʼ������Ŀ¼
	 * @return
	 */
	private IncomeCatalog loadIncomeCatalog() {
		// TODO Auto-generated method stub
		IncomeCatalog incomeCatalog = new IncomeCatalog(null);
		incomeCatalog.addIncome(new Income("A001", "С��", "13345623236", 1400.5,
				"work", 1300));
		incomeCatalog.addIncome(new Income("A002", "С��", "14388275631",
				3100.89, "work", 1500.9));
		incomeCatalog.addIncome(new Income("A003", "С��", "18765431211", 450,
				"other", 2345));
		return incomeCatalog;
	}

	/**
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		PersonalFinancialSystem application = new PersonalFinancialSystem();
		application.run();

	}

	/**
	 * 
	 * @throws IOException
	 */
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				displayIncomeCatalog();
			} else if (choice == 2) {
				displayIncomeInfo();
			} else if (choice == 3) {
				diplayDisbursementCatalog();
			} else if (choice == 4) {
				displayDisbursementInfo();
			} else if (choice == 5) {
				addIncome();
			} else if (choice == 6) {
				addDisbursement();
			} else if (choice == 7) {
				removeIncome();
			} else if (choice == 8) {
				removeDisbursement();
			} else if (choice == 9) {
				findTotal();
			}
			choice = getChoice();
		}
	}

	/**
	 * ����code����ʹ���ߵ��ܽ�
	 * @return
	 * @throws IOException
	 */
	private double findTotal() throws IOException {
		// TODO Auto-generated method stub
		Income income = readIncome();
		Disbursement disbursement = readDisbursement();
		if (income.getCode().equals(disbursement.getCode())) {
			double total = income.getInitial();
			double incomemoney = income.getNumber();
			double disbursementmoney = disbursement.getExpenditure();
			stdErr.println("The total money of the user is:");
			stdErr.println(total + incomemoney - disbursementmoney);
		} else {
			stdErr.println("The codes are not the same!");
		}
		return 0;
	}

	/**
	 * ɾ��֧��
	 * @throws IOException
	 */
	private void removeDisbursement() throws IOException {
		// TODO Auto-generated method stub
		Disbursement disbursement = readDisbursement();
		if (disbursement != null) {
			for (int i = 0; i < disbursementCatalog.getDisbursement().size(); i++) {
				Disbursement temp = disbursementCatalog.getDisbursement()
						.get(i);
				if (temp.getCode().equals(disbursement.getCode())) {
					this.disbursementCatalog.getDisbursement().remove(i);
					stdErr.println("delete successfully!");
				}
			}
		}
	}

	/**
	 * ɾ������
	 * @throws IOException
	 */
	private void removeIncome() throws IOException {
		// TODO Auto-generated method stub
		Income income = readIncome();
		if (income != null) {
			for (int i = 0; i < incomeCatalog.getIncome().size(); i++) {
				Income temp = incomeCatalog.getIncome().get(i);
				if (temp.getCode().equals(income.getCode())) {
					this.incomeCatalog.getIncome().remove(i);
					stdErr.println("delete successfully!");
				}
			}
		}
	}

	/**
	 * ����֧��
	 * @throws IOException
	 */
	private void addDisbursement() throws IOException {
		// TODO Auto-generated method stub
		Disbursement disbursement = readDisbursement();

		if (disbursement == null) {
			Disbursement tempDisbursement = new Disbursement(null, null, null,
					0, null, 0);
			Double total = 0.0d;
			Double expenditure = 0.0d;
			stdErr.println("Now you can add the new one");
			stdErr.println("Please input user's code>");
			tempDisbursement.setCode(stdIn.readLine());
			stdErr.println("Please input user's name>");
			tempDisbursement.setName(stdIn.readLine());
			stdErr.println("Please input user's telephone>");
			tempDisbursement.setTelephone(stdIn.readLine());
			stdErr.println("Please input user's initial money>");
			total = Double.valueOf(stdIn.readLine());
			tempDisbursement.setInitial(total);
			stdErr.println("Please input the use of the user's disbursement>");
			tempDisbursement.setUse(stdIn.readLine());
			stdErr.println("Please input the expenditure of the user's disbursement>");
			expenditure = Double.valueOf(stdIn.readLine());
			tempDisbursement.setExpenditure(expenditure);
			// add disbursement
			this.disbursementCatalog.addDisbursement(tempDisbursement);
			System.out.println("Add Disbursement Successful!!");
		} else {
			stdErr.println("The disbursement is already exist!");
		}
	}

	/**
	 * ��������
	 * @throws IOException
	 */
	private void addIncome() throws IOException {
		// TODO Auto-generated method stub
		Income income = readIncome();

		if (income == null) {
			Income tempIncome = new Income(null, null, null, 0, null, 0);
			Double total = 0.0d;
			Double number = 0.0d;
			stdErr.println("Now you can add the new one");
			stdErr.println("Please input user's code>");
			tempIncome.setCode(stdIn.readLine());
			stdErr.println("Please input user's name>");
			tempIncome.setName(stdIn.readLine());
			stdErr.println("Please input user's telephone>");
			tempIncome.setTelephone(stdIn.readLine());
			stdErr.println("Please input user's initial money>");
			total = Double.valueOf(stdIn.readLine());
			tempIncome.setInitial(total);
			stdErr.println("Please input the source of the user's income>");
			tempIncome.setSource(stdIn.readLine());
			stdErr.println("Please input the number of the user's income>");
			number = Double.valueOf(stdIn.readLine());
			tempIncome.setNumber(number);
			// add income
			this.incomeCatalog.addIncome(tempIncome);
			System.out.println("Add Income Successful!!");
		} else {
			stdErr.println("The income is already exist!");
		}
	}

	/**
	 * ��ʾ�ض�֧��
	 * @throws IOException
	 */
	private void displayDisbursementInfo() throws IOException {
		// TODO Auto-generated method stub
		Disbursement disbursement = readDisbursement();
		System.out.println(disbursement.toString());
		run();
	}

	/**
	 * 
	 * @return
	 * @throws IOException
	 */
	private Disbursement readDisbursement() throws IOException {
		// TODO Auto-generated method stub
		stdErr.print("User code> ");
		stdErr.flush();
		Disbursement disbursement = this.disbursementCatalog
				.findUserDisbursementByCode(stdIn.readLine());
		if (disbursement != null) {
			return disbursement;
		} else {
			stdErr.println("There are no disbursement with that code");
			return null;
		}
	}

	/**
	 * ��ʾ����֧��
	 */
	private void diplayDisbursementCatalog() {
		// TODO Auto-generated method stub
		int size = this.disbursementCatalog.getDisbursement().size();
		if (size == 0) {
			stdErr.println("The catalog is empty");
		} else {
			for (Disbursement disbursement : this.disbursementCatalog
					.getDisbursement()) {
				stdOut.println(disbursement.toString());
			}
		}

	}

	/**
	 * 
	 * @throws IOException
	 */
	private void displayIncomeInfo() throws IOException {
		// TODO Auto-generated method stub
		Income income = readIncome();
		System.out.println(income.toString());
		run();
	}

	/**
	 * 
	 * @return
	 * @throws IOException
	 */
	private Income readIncome() throws IOException {
		// TODO Auto-generated method stub
		stdErr.print("User code> ");
		stdErr.flush();
		Income income = this.incomeCatalog.findUserIncomeByCode(stdIn
				.readLine());
		if (income != null) {
			return income;
		} else {
			stdErr.println("There are no income with that code!");
			return null;
		}
	}

	/**
	 * ��ʾ��������
	 */
	private void displayIncomeCatalog() {
		// TODO Auto-generated method stub
		int size = this.incomeCatalog.getIncome().size();
		if (size == 0) {
			stdErr.println("The catalog is empty");
		} else {
			for (Income income : this.incomeCatalog.getIncome()) {
				stdOut.println(income.toString());
			}
		}
	}

	/**
	 * 
	 * @return
	 * @throws IOException
	 */
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" + "[1] Display income catalog\n"
						+ "[2] Display income\n"
						+ "[3] Display disbursement catalog\n"
						+ "[4] Display disbursement\n"
						+ "[5] Add income for income catalog\n"
						+ "[6] Add disbursement for disbursement catalog\n"
						+ "[7] Remove income from income catalog\n"
						+ "[8] Remove disbursement from disbursement catalog\n"
						+ "[9] Find the total money by code\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 12 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

}
