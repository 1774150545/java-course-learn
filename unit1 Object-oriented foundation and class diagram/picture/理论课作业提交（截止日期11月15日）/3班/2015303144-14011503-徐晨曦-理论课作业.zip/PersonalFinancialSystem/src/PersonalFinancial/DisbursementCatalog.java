package PersonalFinancial;

import java.util.ArrayList;

public class DisbursementCatalog {
	private ArrayList<Disbursement> disbursement;

	/**
	 * @param disbursement
	 */
	public DisbursementCatalog(ArrayList<Disbursement> disbursement) {
		super();
		this.disbursement = new ArrayList<Disbursement>();
	}

	/**
	 * 
	 * @return
	 */
	public ArrayList<Disbursement> getDisbursement() {
		return disbursement;
	}

	/**
	 * 
	 * @param disbursement
	 */
	public void setDisbursement(ArrayList<Disbursement> disbursement) {
		this.disbursement = disbursement;
	}

	/**
	 * 
	 * @param dis
	 */
	public void addDisbursement(Disbursement dis) {
		disbursement.add(dis);
	}

	/**
	 * 
	 * @return
	 */
	public int getnumberofDisbursement() {
		return disbursement.size();
	}

	/**
	 * 
	 * @param readLine
	 * @return
	 */
	public Disbursement findUserDisbursementByCode(String readLine) {
		// TODO Auto-generated method stub
		for (int i = 0; i < disbursement.size(); i++) {
			if (disbursement.get(i).getCode().equals(readLine)) {
				return disbursement.get(i);
			}
		}
		return null;
	}

}
