package PersonalFinancial;

public class Disbursement extends User {
	private String use;
	private double expenditure;

	/**
	 * @param use
	 * @param expenditure
	 */
	public Disbursement(String code, String name, String telephone,
			double total, String use, double expenditure) {
		super(code, name, telephone, total);
		this.use = use;
		this.expenditure = expenditure;
	}

	public String getUse() {
		return use;
	}

	public void setUse(String use) {
		this.use = use;
	}

	public double getExpenditure() {
		return expenditure;
	}

	public void setExpenditure(double expenditure) {
		this.expenditure = expenditure;
	}

	/**
	 * 
	 */
	@Override
	public String toString() {
		return "o	------------------------" + "\n" + "o	code of the user:"
				+ getCode() + ";\n" + "o	name of the user:" + getName() + ";\n"
				+ "o	telephone of the user:" + getTelephone() + ";\n"
				+ "o	initialmoney of the user:" + getInitial() + ";\n"
				+ "o	use of the disbursement:" + use + ";\n"
				+ "o	expenditure of the disbursement:" + expenditure;
	}

}
