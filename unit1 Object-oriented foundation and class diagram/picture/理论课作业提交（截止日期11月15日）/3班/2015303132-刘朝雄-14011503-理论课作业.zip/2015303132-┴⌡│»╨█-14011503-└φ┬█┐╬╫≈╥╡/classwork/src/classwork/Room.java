package classwork;
import java.util.*;
/**
 * ������
 * @author LZX
 * @version 1.1.0
 */
public class Room {
	private String roomNum;
	private String classNum;
	
	/**
	 * @param rn �����
	 */
	public Room(String rn, String cn){
		this.roomNum = rn;
		this.classNum = rn;
	}
	
	/**
	 * @return the roomNum
	 */
	public String getRoomNum() {
		return roomNum;
	}

	/**
	 * @return the classNum
	 */
	public String getClassNum() {
		return classNum;
	}
	
	public String toString(){
		return "roonNum=" + roomNum + " ,classNum" + classNum+"\n";
	}

}
