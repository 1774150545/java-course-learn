package classwork;

/**
 * ����(��ʦ��ѧ���Ļ���)
 * @author LZX
 * @version 1.1.0
 */
public class People {
	private String name;
	private String gender;
	private int age;
	
	/**
	 * �����вι��캯��
	 * @param n ����
	 * @param g �Ա�
	 * @param a ����
	 */
	public People(String n, String g, int a){
		this.name = n;
		this.gender = g;
		this.age = a;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "name=" + name + ", gender=" + gender + ", age=" + age + ", ";
	}
	
	

}
