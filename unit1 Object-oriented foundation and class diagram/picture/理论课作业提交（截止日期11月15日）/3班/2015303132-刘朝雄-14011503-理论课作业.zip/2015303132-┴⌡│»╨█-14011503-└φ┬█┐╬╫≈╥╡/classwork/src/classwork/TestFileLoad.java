package classwork;
import java.io.*;

/**
 * ���Դ��ļ��ж�ȡ��Ϣ��������Ŀ¼�Ƿ�ɹ��Ĳ�����
 * @author LZX
 * @version 1.1.0
 */
public class TestFileLoad {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	
	public static void main(String[] args)
			throws FileNotFoundException, IOException{
	 FileLoad f = new FileLoad();
	 TestFileLoad test= new TestFileLoad();
	 int num = test.getChoice(); 
	 while (num != 0){
	 if(num == 1){
		 System.out.println("����ѧ��---------------------------------------------------------");
		 f.loadStudentCatalog("catalog.dat");
		 for(Student s : f.getStudentCatalog()){
			 System.out.print(s.toString());
		 }
	 }else if(num==2){
		 System.out.println("��������---------------------------------------------------------");
		 f.loadRoomCatalog("catalog.dat");
		 for(Room r : f.getRoomCatalog()){
			 System.out.print(r.toString());
		 }
	 }else if(num == 3){
		 System.out.println("������ʦ---------------------------------------------------------");
		 f.loadTeacherCatalog("catalog.dat");
		 for(Teacher t :f.getTeacherCatalog()){
			 System.out.print(t.toString());
		 }
	 }else if(num == 4){
		 System.out.println("������Ҫд����ļ���");
		 String filename = stdIn.readLine();
		 String str = "������ʦ��Ϣ"+"\n"+"--------------------------------------------------------------------------------"+"\n";
		 f.loadStudentCatalog("catalog.dat");
		 f.loadTeacherCatalog("catalog.dat");
		 f.loadRoomCatalog("catalog.dat");
		 for(Teacher t :f.getTeacherCatalog()){
			 str = str + t.toString();
		 }
		 str = str + "����������Ϣ"+"\n"+"--------------------------------------------------------------------------------"+"\n";
		 for(Room t :f.getRoomCatalog()){
			 str = str + t.toString();
		 }
		 str = str + "����ѧ����Ϣ"+"\n"+"--------------------------------------------------------------------------------"+"\n";
		 for(Student t :f.getStudentCatalog()){
			 str = str + t.toString();
		 }
		 PrintWriter p =new PrintWriter(new FileWriter(filename));
		 p.print(str);
		 p.close();
		 System.out.println("������Ϣд����±��У��뵽�����Ŀ¼����");
	 }
			num = test.getChoice();
	 }
	}


	/**
	 * ��ȡ����̨�����0-4������
	 * @return һ��0-4������
	 * @throws IOException
	 */
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" + "[1] Display student catalog\n" + "[2] Display room catalog\n"
						+ "[3] Display teacher catalog\n" 
						+ "[4] Write all imformation to a file\n" + "Enter a integer");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 4 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

}
