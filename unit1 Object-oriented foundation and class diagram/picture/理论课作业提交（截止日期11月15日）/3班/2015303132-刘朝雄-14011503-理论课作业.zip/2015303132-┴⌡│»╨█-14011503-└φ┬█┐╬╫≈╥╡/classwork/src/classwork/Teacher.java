package classwork;
import java.util.*;
/**
 * ��ʦ��̳�����
 * @author LZX
 * @version 1.1.0
 */
public class Teacher extends People implements Iterable<Room>{
	private int salary;
	private String workNum;
	private String classNum;
	private ArrayList<Room> rooms;
	
	/**
	 * ��ʦ���вι��캯��
	 * @param n ����
	 * @param g �Ա�
	 * @param a ����
	 * @param s ��н
	 * @param wn ����
	 * @param cn �༶��
	 */
	public Teacher(String n, String g, int a, int s, String wn, String cn){
		super(n,g,a);
		this.salary = s;
		this.workNum = wn;
		this.classNum = cn;
		rooms = new ArrayList<Room>();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Iterable#iterator()
	 */
	public Iterator<Room> iterator(){
		return this.rooms.iterator();
	}
	
	/** 
	 * ������������ʦ
	 * @param r Ҫ������������
	 */
	public void addRoom(Room r){
		if(!rooms.contains(r)){
			rooms.add(r);
		}else{
			return;
		}
	}

	/**
	 * @return the salary
	 */
	public int getSalary() {
		return salary;
	}

	/**
	 * @return the workNum
	 */
	public String getWorkNum() {
		return workNum;
	}

	/**
	 * @return the classNum
	 */
	public String getClassNum() {
		return classNum;
	}
	
	/* (non-Javadoc)
	 * @see classwork.People#toString()
	 */
	public String toString(){
		return super.toString() + "salary=" + salary 
				+ " ,workNum=" + workNum + ", classNum="+classNum+"\n";
	}


	
}
