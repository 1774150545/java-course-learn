package classwork;

/**
 * ѧ����̳�����
 * @author LZX
 * @version 1.1.0
 */
public class Student extends People{
	private String studyNum;
	private String roomNum;
	
	/**
	 * ѧ�����вι��캯��
	 * @param n ����
	 * @param g �Ա�
	 * @param a ����
	 * @param sn ѧ��
	 * @param rn �����
	 */
	public Student(String n, String g, int a, String sn , String rn){
		super(n,g,a);
		this.studyNum = sn;
		this.roomNum = rn;
	}

	/**
	 * @return the studyNum
	 */
	public String getStudyNum() {
		return studyNum;
	}

	/**
	 * @return the roomNum
	 */
	public String getRoomNum() {
		return roomNum;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
	 return super.toString() + " studyNum=" + studyNum + ", roomNum=" + roomNum
			 +"\n";
	}
	

}
