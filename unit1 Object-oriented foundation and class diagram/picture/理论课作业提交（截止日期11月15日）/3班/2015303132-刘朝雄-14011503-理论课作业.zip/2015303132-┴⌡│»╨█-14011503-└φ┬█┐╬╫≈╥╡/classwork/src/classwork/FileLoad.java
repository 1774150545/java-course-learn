package classwork;
import java.util.*;
import java.io.*;

/**
 * ���ļ���ȡ��Ϣ��������������ʦ������ѧ������������ļ���
 * @author LZX
 * @version 1.1.0
 */
public class FileLoad {
	private TeacherCatalog teacherCatalog;
	private StudentCatalog studentCatalog;
	private RoomCatalog roomCatalog;
	
	/**
	 * ���ļ��ж�ȡ��Ϣ����ѧ��Ŀ¼
	 * @param filename Ҫ��ȡ���ļ���
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void loadStudentCatalog(String filename) 
			throws FileNotFoundException, IOException{
		StudentCatalog sc = new StudentCatalog();
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		String line = reader.readLine();
		while(line != null){
			StringTokenizer t = new StringTokenizer(line,"_");
			String str1 = t.nextToken();
			if(str1.equals("student")){
				String str2 = t.nextToken();
				String str3 = t.nextToken();
				String str4 = t.nextToken();
				String str5 = t.nextToken();
				int str6 = Integer.parseInt(t.nextToken());
				String str7 = t.nextToken();
				sc.addStudent(new Student(str4, str5, str6, str7, str3));
			}
			line = reader.readLine();
		}	
		reader.close();
		this.studentCatalog = sc;
	}
	
	/**
	 * ���ļ��ж�ȡ��Ϣ��������Ŀ¼
	 * @param filename Ҫ��ȡ���ļ���
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void loadRoomCatalog(String filename) 
			throws FileNotFoundException, IOException{
		RoomCatalog rc = new RoomCatalog();
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		String line = reader.readLine();
		while(line != null){
			StringTokenizer t = new StringTokenizer(line,"_");
			String str1 = t.nextToken();
			if(str1.equals("student")){
				String str2 = t.nextToken();
				String str3 = t.nextToken();
				Room rm = new Room(str3,str2);
				rc.addRoom(rm);
			}
			line = reader.readLine();
		}	
		reader.close();
		this.roomCatalog = rc;
	}
	
	/**
	 * ���ļ��ж�ȡ��Ϣ������ʦĿ¼
	 * @param filename Ҫ��ȡ���ļ���
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void loadTeacherCatalog(String filename) 
			throws FileNotFoundException, IOException{
		TeacherCatalog tc = new TeacherCatalog();
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		String line = reader.readLine();
		while(line != null){
			StringTokenizer t = new StringTokenizer(line,"_");
			String str1 = t.nextToken();
			if(str1.equals("teacher")){
				String str2 = t.nextToken();
				String str3 = t.nextToken();
				String str4 = t.nextToken();
				int str5 = Integer.parseInt(t.nextToken());
				String str6 = t.nextToken();
				int str7 = Integer.parseInt(t.nextToken());
				tc.addTeacher(new Teacher(str3,str4,str5,str7,str6,str2));
			}
			line = reader.readLine();
		}	
		reader.close();
		this.teacherCatalog = tc;
	}

	/**
	 * @return the teacherCatalog
	 */
	public TeacherCatalog getTeacherCatalog() {
		return teacherCatalog;
	}

	/**
	 * @return the studentCatalog
	 */
	public StudentCatalog getStudentCatalog() {
		return studentCatalog;
	}

	/**
	 * @return the roomCatalog
	 */
	public RoomCatalog getRoomCatalog() {
		return roomCatalog;
	}		
}

