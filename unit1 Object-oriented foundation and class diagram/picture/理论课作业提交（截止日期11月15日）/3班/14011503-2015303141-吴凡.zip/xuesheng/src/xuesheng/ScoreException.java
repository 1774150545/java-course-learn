/**
 * 
 */
package xuesheng;

/**
 * @author apple1
 *
 */
public class ScoreException extends Exception {
    private static final long serialVersionUID = 1L;
 
    public ScoreException() {
        super();
    }
 
    public ScoreException(String arg0) {
        super(arg0);
    }
}