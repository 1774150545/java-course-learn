import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Set;

/**
 * The class is a ticket-saling system which offers service to someone who buy
 * ticket.
 * 
 * @author Michael Scofield
 * @version 1.1.0
 */
public class SaleTicketService {

	/**
	 * The method is used to sale a ticket by offered arguments.
	 * 
	 * @param passenger
	 *            {@link Passenger} object
	 * @param departure
	 *            where you leave
	 * @param destination
	 *            where you go
	 * @param choice
	 *            choice of input,if choice=1,it means someone decides to <br/>
	 *            buy a couchtte ticket,else if choice=2,it means a seat ticket.
	 * 
	 * @return a {@link Ticket} object
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public Ticket SaleaTicket(Passenger passenger, String departure, String destination, int choice)
			throws FileNotFoundException, IOException {

		String codeFileName = null;
		String fileName = null;
		if (choice == 1) {
			codeFileName = "CouchtteTicket_Code.txt";
			fileName = "CouchtteTicket.txt";
		} else {
			codeFileName = "SeatTicket_Code.txt";
			fileName = "SeatTicket.txt";
		}

		if (TicketFileManagement.getLeftTicketNumber(codeFileName) == 0)
			return null;

		MyProperties properties = new MyProperties();
		try {
			properties.load(new FileReader(codeFileName));
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		Set<String> codeSet = properties.stringPropertyNames();
		String ticketcode = null;
		for (String code : codeSet) {
			if (properties.getProperty(code).equals("true")) {
				ticketcode = code;
				break;
			}
		}

		double price = TicketFileManagement.getPrice(codeFileName);
		TicketFileManagement.setTicketNumber(codeFileName, -1, ticketcode);

		Ticket ticket = null;
		if (choice == 1) {
			ticket = new CouchtteTicket(ticketcode, ticketcode.substring(1), price, passenger, departure, destination);

		} else {
			ticket = new SeatTicket(ticketcode, ticketcode.substring(1), price, passenger, departure, destination);
		}

		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(fileName, true));
		bufferedWriter.write(ticketcode + "_" + ticketcode.substring(1) + "_" + price + "_" + departure + "_"
				+ destination + "_" + passenger.getName() + "_" + passenger.getAge() + "_" + passenger.getID());
		bufferedWriter.newLine();
		bufferedWriter.close();
		return ticket;
	}

}
