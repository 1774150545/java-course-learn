/**
 * The class models a ticket.
 * 
 * @author Michael Scofield
 * @version 1.1.0
 * 
 */
public class Ticket {

	private String code;
	private String number;
	private double price;
	private Passenger passenger;
	private String departure;
	private String destination;

	/**
	 * Constructs a <code>Ticket</code> object without detail message.
	 */
	protected Ticket() {
		super();
	}

	/**
	 * Constructs a <code>Ticket</code> object with following arguments.
	 * 
	 * @param code
	 *            code of ticket
	 * @param number
	 *            number of ticket
	 * @param price
	 *            price of ticket
	 * @param passenger
	 *            {@link Passenger}
	 * @param departure
	 *            where you leave
	 * @param destination
	 *            where you go
	 */
	public Ticket(String code, String number, double price, Passenger passenger, String departure, String destination) {
		super();
		this.code = code;
		this.number = number;
		this.price = price;
		this.passenger = passenger;
		this.departure = departure;
		this.destination = destination;
	}

	/**
	 * Return the code of ticket
	 * 
	 * @return the code of ticket
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Return the number of ticket.
	 * 
	 * @return the number of ticket.
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * Return the price of ticket.
	 * 
	 * @return the price of ticket.
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * Return the {@link Passenger} object.
	 * 
	 * @return the {@link Passenger} object.
	 */
	public Passenger getPassenger() {
		return passenger;
	}

	/**
	 * Return the place where passenger leave
	 * 
	 * @return the place where passenger leave
	 */
	public String getDeparture() {
		return departure;
	}

	/**
	 * the place where passenger go
	 * 
	 * @return the place where passenger go
	 */
	public String getDestination() {
		return destination;
	}

	/**
	 * Return the type of ticket.
	 * 
	 * @return the type of ticket
	 */
	public String getType() {
		return null;
	}

}
