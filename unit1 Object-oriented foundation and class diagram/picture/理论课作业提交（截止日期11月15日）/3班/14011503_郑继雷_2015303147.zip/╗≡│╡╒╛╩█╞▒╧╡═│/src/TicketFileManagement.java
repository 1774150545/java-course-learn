import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

/**
 * The class is a system of managing ticket files.
 * 
 * @author Michael Scofield
 * @version 1.1.0
 */
public class TicketFileManagement {

	/**
	 * Get the number of left ticket by a file.
	 * 
	 * @param fileName
	 *            name of file
	 * @return
	 */
	public static int getLeftTicketNumber(String codeFileName) {
		Properties properties = new Properties();
		try {
			properties.load(new FileReader(codeFileName));
		} catch (IOException e) {
			System.out.println("Can't find the file named " + codeFileName);
		}
		int left = 100;
		try {
			left = Integer.parseInt(properties.getProperty("left"));
		} catch (NumberFormatException n) {
			System.out.println("��ʽת������");
			System.exit(0);
		}
		return left;
	}

	/**
	 * Get the number of ticket which had been sold.
	 * 
	 * @param fileName
	 * @return the number of ticket which had been sold.
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static int getSoldTicketNumber(String codeFileName) throws FileNotFoundException, IOException {

		Properties properties = new Properties();

		properties.load(new FileReader(codeFileName));

		int sold = 100;
		sold = Integer.parseInt(properties.getProperty("sold"));
		return sold;
	}

	/**
	 * Manage the number of left tickets and sold
	 * tickets.(������Ʊ������Ʊ�޸�ʣ��Ʊ��������Ʊ������)
	 * 
	 * @param fileName
	 *            name of file
	 * @param num
	 *            if num=1,it means that backed a ticket,else if num=-1 means
	 *            sold a ticket.
	 * @param code
	 *            the code of backed or sold ticket
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void setTicketNumber(String codeFileName, int num, String code)
			throws FileNotFoundException, IOException {

		MyProperties properties = new MyProperties();
		properties.load(new FileReader(codeFileName));

		int left = Integer.parseInt(properties.getProperty("left"));
		int right = Integer.parseInt(properties.getProperty("sold"));
		int sum = left + right;
		properties.setProperty("left", Integer.toString(left + num));

		properties.setProperty("sold", Integer.toString(sum - left - num));
		if (num == 1) {
			properties.setProperty(code, "true");
		} else {
			properties.setProperty(code, "false");
		}
		FileWriter writer = new FileWriter(codeFileName);
		properties.store(writer, null);

	}

	/**
	 * Get the price of a ticket.
	 * 
	 * @param codeFileName
	 *            name of file
	 * @return the price of ticket
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static double getPrice(String codeFileName) throws FileNotFoundException, IOException {

		Properties properties = new Properties();
		properties.load(new FileReader(codeFileName));
		double price = Double.parseDouble(properties.getProperty("price"));
		return price;
	}
}
