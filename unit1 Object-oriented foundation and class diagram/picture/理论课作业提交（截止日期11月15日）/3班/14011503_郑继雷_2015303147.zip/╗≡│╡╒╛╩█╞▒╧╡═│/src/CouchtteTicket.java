/**
 * The class models a couchtteticket(����) . It extends {@link Ticket} .
 * 
 * @author Michael Scofield
 * @version 1.1.0
 *
 */
public class CouchtteTicket extends Ticket {

	/**
	 * Constructs a <code>CouchtteTicket<code> object without detail message.
	 */
	public CouchtteTicket() {
		super();

	}

	/**
	 * Constructs a <code>CouchtteTicket</code> object with following arguments.
	 * 
	 * @param code
	 *            ticket code (��Ʊ���)
	 * @param number
	 *            ticket number (��Ʊ���̺�)
	 * @param price
	 *            ticket price
	 * @param passenger
	 *            {@link passenger} object
	 * @param departure
	 *            where you leave
	 * @param destination
	 *            where you go
	 */
	public CouchtteTicket(String code, String number, double price, Passenger passenger, String departure,
			String destination) {
		super(code, number, price, passenger, departure, destination);

	}

	/**
	 * Get the type of the ticket.
	 */
	public String getType() {
		return "����";
	}

}
