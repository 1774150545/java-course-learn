import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The class is a system which is used to back tickets.
 * 
 * @author Michael Scofield
 * @version 1.1.0
 * @see TicketFileManagement
 */
public class RefundTicketService {

	/**
	 * The method is used to refund a ticket.
	 * 
	 * @param ticketCode
	 *            code of ticket
	 * @param name
	 *            name of passenger
	 * @param ID
	 *            id of passenger
	 * @param choice
	 *            choice of input
	 * @return if refund successfully,return true,else return false
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	@SuppressWarnings({ "unused", "resource" })
	public boolean refundTicket(String ticketCode, String name, String ID, int choice)
			throws FileNotFoundException, IOException {

		String codeFileName = null;
		String fileName = null;

		if (choice == 1) {
			codeFileName = "CouchtteTicket_Code.txt";
			fileName = "CouchtteTicket.txt";
		}

		else {
			codeFileName = "SeatTicket_Code.txt";
			fileName = "SeatTicket.txt";
		}

		MyProperties properties = new MyProperties();
		properties.load(new FileReader(codeFileName));
		String pro = properties.getProperty(ticketCode);
		if (pro == null) {
			System.out.println("\nδ�ҵ���Ӧ��Ʊ��Ϣ.");
			return false;
		}

		if (pro.equals("true")) {
			System.out.println("\n��Ʊδ����");
			return false;
		} else if (pro == null) {
			System.out.println("\nδ�ҵ���Ӧ��Ʊ��Ϣ.");
			return false;
		}

		ArrayList<String> listMessage = new ArrayList<String>();
		BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));

		String line = null;
		String target = null;
		while ((line = bufferedReader.readLine()) != null) {
			if (!line.startsWith(ticketCode)) {
				listMessage.add(line);
			} else {
				target = line;
			}
		}
		if (target == null)
			return false;
		String[] ticketContent = target.split("_");
		if (!ticketContent[5].equals(name) || !(ticketContent[7].equals(ID))) {
			System.out.println("δ�ҵ���Ӧ��Ʊ��Ϣ.");
			bufferedReader.close();
			return false;
		}

		else {

			System.out.println("************");
			System.out.println("���˳�Ʊ��Ϣ:");
			System.out
					.println("��Ʊ���: " + ticketContent[0] + "\n��λ��: " + ticketContent[1] + "\n�۸�: " + ticketContent[2]);
			System.out.println("���: " + ticketContent[3] + " �յ�: " + ticketContent[4]);
			System.out.println("����: " + ticketContent[5] + "\n����: " + ticketContent[6] + "\n����֤��: " + ticketContent[7]);
			System.out.println("************");
		}

		System.out.println("ȷ����Ʊ? Y/N ( ��ʾ: ȷ����Ʊ����Y,ȡ����Ʊ����N) ");

		while (true) {
			Scanner sc = new Scanner(System.in);
			String in = sc.nextLine();
			if (in.equals("N")) {
				bufferedReader.close();

				return false;
			} else if (in.equals("Y")) {
				TicketFileManagement.setTicketNumber(codeFileName, 1, ticketCode);
				PrintWriter printWriter = new PrintWriter(fileName);
				for (String str : listMessage) {
					printWriter.println(str);
				}
				printWriter.close();
				bufferedReader.close();
				return true;
			} else {
				System.out.println("������������,����������: (Y/N)");
				continue;
			}
		}

	}
}
