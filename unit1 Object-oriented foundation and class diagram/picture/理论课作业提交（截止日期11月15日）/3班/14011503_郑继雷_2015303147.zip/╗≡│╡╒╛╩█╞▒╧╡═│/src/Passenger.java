/**
 * The class models a passenger.
 * 
 * @author Michael Scofield
 * @version 1.1.0
 */
public class Passenger {

	private String name;
	private int age;
	private String ID;

	/**
	 * Constructs a <code>Passenger</code> object without detail message.
	 */
	public Passenger() {
		super();

	}

	/**
	 * Constructs a <code>Passenger</code> object with following arguments.
	 * 
	 * @param name
	 *            name of passenger
	 * @param age
	 *            age of passenger
	 * @param iD
	 *            id of passenger
	 */
	public Passenger(String name, int age, String iD) {
		super();
		this.name = name;
		this.age = age;
		ID = iD;
	}

	/**
	 * Retun the name of <code>Passenger</code> object.
	 * 
	 * @return name of <code>Passenger</code> object.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Return the age of <code>Passenger</code> object.
	 * 
	 * @return age of <code>Passenger</code> object.
	 */
	public int getAge() {
		return age;
	}

	/**
	 * Return the id of <code>Passenger</code> object.
	 * 
	 * @return id of <code>Passenger</code> object.
	 */
	public String getID() {
		return ID;
	}

}
