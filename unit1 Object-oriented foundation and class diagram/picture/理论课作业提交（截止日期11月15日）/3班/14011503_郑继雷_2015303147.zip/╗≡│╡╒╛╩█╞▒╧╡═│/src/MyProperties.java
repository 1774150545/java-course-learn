
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.Properties;
import java.util.Set;
import java.util.Collections;

/**
 * The class extends <code>Properties</code> and override some methods of it.
 * 
 * @author Michael Scofield
 * @version 1.1.0
 */
public class MyProperties extends Properties {

	private static final long serialVersionUID = 1L;

	private final LinkedHashSet<Object> keys = new LinkedHashSet<Object>();

	@Override
	public synchronized Object put(Object key, Object value) {

		keys.add(key);
		return super.put(key, value);
	}
	
	@Override
	public Set<String> stringPropertyNames() {

		Set<String> set = new LinkedHashSet<String>();
		for (Object obj : keys) {
			set.add((String) obj);
		}
		return set;
	}

	@Override
	public Set<Object> keySet() {

		return this.keys;
	}

	public Enumeration<Object> keys() {
		return Collections.<Object>enumeration(keys);
	}

}
