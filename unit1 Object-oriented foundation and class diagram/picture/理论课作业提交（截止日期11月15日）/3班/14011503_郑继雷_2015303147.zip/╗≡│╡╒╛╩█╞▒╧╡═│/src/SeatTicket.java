/**
 * The class models a seat ticket.It extends {@link Ticket}.
 * 
 * @author Michael Scofield
 * @version 1.1.0
 */
public class SeatTicket extends Ticket {

	/**
	 * Constructs a <code>SeatTicket</code> object without detail message.
	 */
	public SeatTicket() {
		super();
	}

	/**
	 * Constructs a <code>SeatTicket</code> object with following arguments.
	 * 
	 * @param code
	 *            code of ticket
	 * @param number
	 *            number of ticket
	 * @param price
	 *            price of ticket
	 * @param passenger
	 *            {@link Passenger} object
	 * @param departure
	 *            where you leave
	 * @param destination
	 *            where you go
	 */
	public SeatTicket(String code, String number, double price, Passenger passenger, String departure,
			String destination) {
		super(code, number, price, passenger, departure, destination);

	}

	/**
	 * Return type of the ticket.
	 */
	public String getType() {
		return "Ӳ��";
	}

}
