package schoolbank;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class CatalogLoader {

	public Catalog loadCatalog(String filename) throws FileNotFoundException, IOException, DataFormatException {
		Catalog catalog = new Catalog();
		BufferedReader in = new BufferedReader(new FileReader(filename));
		String temp = in.readLine();
		while (temp != null) {
			StringTokenizer tokenizer=new StringTokenizer(temp, "_");
			if (tokenizer.countTokens()==4)
				catalog.addPerson((Person)readBenke(temp));
			else catalog.addPerson((Person)readShuoShi(temp));
			temp = in.readLine();

		}
		in.close();

		return catalog;

	}
	private ShuoShi readShuoShi(String line) throws DataFormatException {
		StringTokenizer tokenizer = new StringTokenizer(line, "_");
		if (tokenizer.countTokens() != 5)
			throw new DataFormatException();
		String id = tokenizer.nextToken();
		String name = tokenizer.nextToken();
		Double qiankuan=Double.parseDouble(tokenizer.nextToken());

		Double money = Double.parseDouble(tokenizer.nextToken());
		Double score = Double.parseDouble(tokenizer.nextToken());

		return new ShuoShi(id, name, qiankuan,money,score);
	}
	private Benke readBenke(String line) throws DataFormatException {
		StringTokenizer tokenizer = new StringTokenizer(line, "_");
		if (tokenizer.countTokens() != 4)
			throw new DataFormatException();
		String id = tokenizer.nextToken();
		String name = tokenizer.nextToken();
		Double qiankuan=Double.parseDouble(tokenizer.nextToken());

		Double money = Double.parseDouble(tokenizer.nextToken());
		
		return new Benke(id, name, qiankuan,money);
	}

}
