package schoolbank;

public interface Sale {
	void saleMoney(String id, double amount,Catalog catalog);

	
}
