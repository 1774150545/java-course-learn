package schoolbank;
public class Person {
	private String ID;
	private String name;
public double money;
public double qiankuan;
	public Person(String iD, String name,double qiankuan,double money) {
	this.ID=iD;
	this.name=name;
	this.qiankuan=qiankuan;
	this.money=money;
}

	
	public String getId() {
		// TODO Auto-generated method stub
		return ID;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	public double getQiankuan() {
		// TODO Auto-generated method stub
		return qiankuan;
	}

	public double getMoney() {
		// TODO Auto-generated method stub
		return money;
	}
public String toString(){
	return ID+" "+name+" "+qiankuan+" "+money;
}
}
