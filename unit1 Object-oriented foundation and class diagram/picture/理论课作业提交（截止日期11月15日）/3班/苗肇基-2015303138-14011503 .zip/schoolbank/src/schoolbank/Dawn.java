package schoolbank;

public interface Dawn {

	void dawnMoney(String id, double amount, Catalog catalog);
}
