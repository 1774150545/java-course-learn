package schoolbank;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class BankSystem {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private Catalog catalog;
	private Dawn dawn;
	private Sale sale;
	/**
	 * Loads catalog data from a file and starts the application.
	 * <p>
	 * The name of the file is specified in the command arguments.
	 * </p>
	 * 
	 * @param args
	 *            String arguments.
	 * @throws IOException
	 *             if there are errors in the input.
	 */
	public static void main(String[] args) throws IOException {

		Catalog catalog = null;

		if (args.length != 1) {
			stdErr.println("Usage: java BankSystem filename" + args.length);
		} else {
			try {
				catalog = (new CatalogLoader()).loadCatalog(args[0]);
			} catch (FileNotFoundException fnfe) {
				stdErr.println("The file does not exist");

				System.exit(1);

			} catch (DataFormatException dfe) {
				stdErr.println("The file contains malformed data: " + dfe.getMessage());

				System.exit(1);
			}

			BankSystem application = new BankSystem(catalog);

			application.run();
		}
	}
	/**
	 * Constructs a <code>GourmetCoffee</code> object. Initializes the catalog
	 * data with the value specified in the parameter.
	 * 
	 * @param initialCatalog
	 *            a product catalog
	 */
	private BankSystem(Catalog initialCatalog) {

		this.catalog = initialCatalog;
	}
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0]  Quit\n" + "[1]  Display Catalog\n" + "[2]  ��Ǯ\n"
						+ "[3]  ȡǮ\n" + "[4]  ��Ǯ\n"
						+ "[5]  �������ݿ�\n" + "[6]  ��Ǯ\n"
						+ "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 6 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}
	private String displayCatalog() {
      String temp="";
		int size = this.catalog.getNumberOfPerson();

		if (size == 0) {
			stdErr.println("The catalog is empty");
		} else {
			for (Person person : this.catalog) {
				
				temp+=person.getId()+"_"+person.getName()+"_"+person.getMoney()+"_"+person.getQiankuan()+System.lineSeparator();
			}
		}return temp;
	}
	private void update(String filename, String content) throws IOException {
		try {
			File file = new File(filename);
			if (!file.exists()) {
				FileWriter out = new FileWriter(file);
				out.write(content);
				out.close();
			} else
				throw new IOException("The new file already exists!");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	private String readFilename() throws IOException {

		stdErr.print("Filename> ");
		stdErr.flush();

		return stdIn.readLine();
	}
	/**
	 * Presents the user with a menu of options and executes the selected task.
	 */
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				System.out.println(displayCatalog());
			} else if (choice == 2) {
				String id;
				stdErr.println("������ID");
				id=stdIn.readLine();
			
				if(id.length()==7){
				this.sale = BenkeSale.getSingletonInstance();
				}else{
					this.sale = ShuoShiSale.getSingletonInstance();
				}
				double amount=getAmount();
				sale.saleMoney(id,amount,catalog);
				stdOut.println("�ɹ�");
				
			} else if (choice == 3) {
				String id;
				id=stdIn.readLine();
				if(id.length()==5){
					this.dawn = BenkeDawn.getSingletonInstance();
					}else{
						this.dawn = ShuoShiDawn.getSingletonInstance();
					}
					double amount=getAmount();
					dawn.dawnMoney(id,amount,catalog);
					stdOut.println("�ɹ�");
			} else if (choice == 4) {
				String id;
				id=stdIn.readLine();
				double amount=getAmount();
				huanQian(id,amount);
			} else if (choice == 5) {
				String filename=readFilename();
			update(filename,displayCatalog());
			} else if (choice == 6) {
				stdErr.println("����ID");
				String id;
				id=stdIn.readLine();
				double amount=getAmount();
				desposit(id,amount);
			} 
			choice = getChoice();

		}
	}
	private void desposit(String id, double amount) throws IOException {
		Person person=getPerson(id);
		if(person==null){
			
				stdErr.println("�˻������ڣ�Ĭ�ϴ����˻�,�������û���Ϣ");
				StringTokenizer tokenizer=new StringTokenizer(stdIn.readLine(),"_");
				if(tokenizer.countTokens()==3) {
					person=new Benke(id,tokenizer.nextToken(),Double.valueOf(tokenizer.nextToken()),Double.valueOf(tokenizer.nextToken()));
				}else{
					person=new ShuoShi(id,tokenizer.nextToken(),Double.valueOf(tokenizer.nextToken()),Double.valueOf(tokenizer.nextToken()),Double.valueOf(tokenizer.nextToken()));	
				}catalog.addPerson(person);
					
			
		}
		else person.money+=amount;
		
	}
	private void huanQian(String id, double amount) throws IOException {
		Person person=getPerson(id);
		person.qiankuan-=amount;
		
	}
	private Person getPerson(String id) throws IOException {
		Person temp=null;
		for(Person person:catalog){
			if(person.getId().equals(id)) {
				temp=person;break;
			}
		}return temp;
	}
	private double getAmount() throws NumberFormatException, IOException {
		stdErr.println("��������");
		return Double.valueOf(stdIn.readLine()) ;
		
	}

}
