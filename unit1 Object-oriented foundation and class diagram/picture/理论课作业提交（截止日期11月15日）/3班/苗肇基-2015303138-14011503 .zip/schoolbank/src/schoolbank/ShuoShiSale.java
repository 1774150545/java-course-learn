package schoolbank;

public class ShuoShiSale implements Sale{
private static ShuoShiSale singletonInstance;
private ShuoShiSale(){
}
public static ShuoShiSale getSingletonInstance(){
	if(singletonInstance==null){
		ShuoShiSale.singletonInstance=new ShuoShiSale();
	}
		return singletonInstance;
}
	
	public void saleMoney(String id, double amount,Catalog catalog) {
		Person temp=null;
		
		for(Person person:catalog){
			if(person.getId().equals(id)) {
				temp=person;break;
			}
		}
		if(temp==null) System.out.println("�����ڵĿͻ�");
		else temp.qiankuan+=amount+((ShuoShi)temp).getScore();
		
	}
	
		
	

}
