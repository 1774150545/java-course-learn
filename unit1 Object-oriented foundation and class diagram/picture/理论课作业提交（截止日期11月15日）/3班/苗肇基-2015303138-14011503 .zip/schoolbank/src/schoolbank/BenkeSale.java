package schoolbank;

public class BenkeSale implements Sale {
	private static BenkeSale singletonInstance;
	private BenkeSale(){
	}
	public static BenkeSale getSingletonInstance(){
		if(singletonInstance==null){
			BenkeSale.singletonInstance=new BenkeSale();
		}
			return singletonInstance;
	}
		
		public void saleMoney(String id, double amount,Catalog catalog) {
			Person temp=null;
			for(Person person:catalog){
				if(person.getId().equals(id)) {
					temp=person;break;
				}
			}
			if(temp==null) System.out.println("�����ڵĿͻ�");
			else temp.qiankuan+=amount;
			
		}
	
		
}
