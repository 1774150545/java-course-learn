package schoolbank;

public class BenkeDawn implements Dawn{
	private static BenkeDawn singletonInstance;
	private BenkeDawn(){
	}
	public static BenkeDawn getSingletonInstance(){
		if(singletonInstance==null){
			BenkeDawn.singletonInstance=new BenkeDawn();
		}
			return singletonInstance;
	}
		
	
	public void dawnMoney(String id, double amount,Catalog catalog) {
		Person temp=null;
		for(Person person:catalog){
			if(person.getId().equals(id)) {
				temp=person;break;
			}
		}
		if(temp==null) System.out.println("�����ڵĿͻ�");
		else temp.money-=(amount-temp.money*0.02);
		
	}

}
