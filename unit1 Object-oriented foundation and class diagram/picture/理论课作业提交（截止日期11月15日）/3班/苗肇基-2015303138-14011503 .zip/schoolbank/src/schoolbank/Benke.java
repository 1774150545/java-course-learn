package schoolbank;

public class Benke extends Person {
	
public Benke(String ID,String name,double qiankuan,double money){
	super(ID,name,qiankuan,money);
}
public String toString(){
	return super.toString();
}
}
