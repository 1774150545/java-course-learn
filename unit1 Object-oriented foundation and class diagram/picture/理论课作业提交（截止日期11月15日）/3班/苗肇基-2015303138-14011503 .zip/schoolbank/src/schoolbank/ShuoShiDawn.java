package schoolbank;

public class ShuoShiDawn implements Dawn{
	private static ShuoShiDawn singletonInstance;
	private ShuoShiDawn(){
	}
	public static ShuoShiDawn getSingletonInstance(){
		if(singletonInstance==null){
			ShuoShiDawn.singletonInstance=new ShuoShiDawn();
		}
			return singletonInstance;
	}
		
	
	public void dawnMoney(String id, double amount,Catalog catalog) {
		Person temp=null;
		for(Person person:catalog){
			if(person.getId().equals(id)) {
				temp=person;break;
			}
		}
		if(temp==null) System.out.println("�����ڵĿͻ�");
		else temp.money-=(amount-temp.money*0.01);
	}
}
