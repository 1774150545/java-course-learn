package schoolbank;

public class ShuoShi extends Person {
	
public double getScore(){
	return this.score;
}
private double score;
public ShuoShi(String ID,String name,double qiankuan,double money,double score){
	super(ID,name,qiankuan,money);
	this.score=score;
}
}
