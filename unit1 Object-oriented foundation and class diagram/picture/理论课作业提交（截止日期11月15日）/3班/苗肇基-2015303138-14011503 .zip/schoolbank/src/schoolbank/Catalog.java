package schoolbank;
import java.util.ArrayList;
import java.util.Iterator;
public class Catalog implements Iterable<Person>{
private ArrayList<Person> person;
public Catalog(){
	person=new ArrayList<Person>();
}
	public int getNumberOfPerson() {
		// TODO Auto-generated method stub
		return person.size();
	}

	@Override
	public Iterator<Person> iterator() {
	
		return person.iterator();
	}
	public void addPerson(Person temp){
		person.add(temp);
	}

}
