package checkDormSystem;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;
/**
 * CheckDormSystem��
 * @author �⺣��
 * @see Dorm
 * @see CheckDormSystem
 * @see DormListm
 * @see FormatInformation
 * @see LoadDormMembers
 * @see Member
 * @see People
 * @version 1.0
 *
 */
public class CheckDormSystem {
	private static BufferedReader stdIn = new BufferedReader(
			new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);

	static ArrayList<Dorm> dl;

	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {

		CheckDormSystem cds = new CheckDormSystem();

		try {
			dl = new LoadDormMembers().FileLoader(new File(
					"DormsInformation.txt"));
		} catch (FileNotFoundException fnfe) {
			stdErr.println("The file does not exist");
			System.exit(1);
		}

		cds.run();

	}

	/**
	 * Displays a menu of options and verifies the user's choice.
	 * 
	 * @return an integer in the range [0,7]
	 */
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0]  Quit\n" + "[1]  display all dormlist\n"
						+ "[2]  add checkList to dorm\n"
						+ "[3]  find dorm by code\n"
						+ "[4]  remove dorm by code\n"
						+ "[5]  Save dormlist (txt)\n");
				stdErr.print("choice>");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 5 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	/**
	 * Presents the user with a menu of options and executes the selected task.
	 */
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				displayAll();
			} else if (choice == 2) {
				addCheckList();
			} else if (choice == 3) {
				findDormByCode(readCode());
			} else if (choice == 4) {
				removeDorm(readCode());
			} else {
				writeDormInformation();
			}
			choice = getChoice();
		}
	}

	/**
	 * ��������Ϣ��д��TXT�ļ���
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void writeDormInformation() throws FileNotFoundException,
			IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = new PrintWriter(readFilename());
		pw.write(new FormatInformation().displayAll());
		pw.flush();
		stdOut.println("д�ļ��ɹ���");
		pw.close();
	}

	/**
	 * ͨ�����ҺŲ�ѯ��Ϣ
	 * @param readCode
	 */
	private void findDormByCode(String readCode) {
		// TODO Auto-generated method stub
		boolean flag = false;
		for (Dorm dorm : dl) {
			if (dorm.getCode().equals(readCode)) {
				stdOut.println(new FormatInformation().displayByCode(readCode));
				flag = true;
				return;
			}
		}
		if (flag == false) {
			stdOut.println("��������������򲻴���");
		}
	}

	/**
	 * ���Ӳ�����Ϣ
	 * @throws IOException
	 */
	private void addCheckList() throws IOException {
		// TODO Auto-generated method stub
		stdErr.println("Please input like(\"��d148_2016-11-05_93.1\")>");
		String line = readCode();
		StringTokenizer st = new StringTokenizer(line, "_");
		if (st.countTokens() != 3) {
			stdErr.println("������ĸ�ʽ����!");
			return;
		}
		String code = st.nextToken();

		boolean flag = false;
		Check check = new Check(st.nextToken(), Double.parseDouble(st
				.nextToken()));
		for (Dorm dorm : dl) {

			if (code.equals(dorm.getCode())) {
				dorm.addCheckList(check);
				flag = true;
				stdOut.println("���ӳɹ���");
			}
		}
		if (flag == false) {
			stdErr.println("�����ڸ������������Ϣ����");
		}
	}

	/**
	 * ��ʾ������Ϣ
	 */
	private void displayAll() {
		// TODO Auto-generated method stub
		stdOut.println(new FormatInformation().displayAll());

	}

	/**
	 * ͨ�����Һ�ɾ��������Ϣ
	 * @param readCode
	 */
	private void removeDorm(String readCode) {
		// TODO Auto-generated method stub
		ArrayList<Dorm> list = new ArrayList<Dorm>();
		boolean flag = false;
		for (Dorm dorm : dl) {

			if (dorm.getCode().equals(readCode)) {
				list.add(dorm);
				flag = true;
			}
		}
		// ����ArrayList�ڱ�����ʱ���ܽ��иı伯�ϴ�С�Ĳ���
		if (flag == true) {
			dl.removeAll(list);
			stdOut.println("ɾ���ɹ���");
		}
		if (flag == false) {
			stdErr.println("�����ڸ��������������������");
		}
	}

	/**
	 * Prompts the user for a filename (the name of the file that will store the
	 * sales information) and returns the user's response.
	 * 
	 * @return name of a file
	 */
	private String readCode() throws IOException {

		stdErr.print("code> ");
		stdErr.flush();

		return stdIn.readLine();
	}

	/**
	 * Prompts the user for a filename (the name of the file that will store the
	 * sales information) and returns the user's response.
	 * 
	 * @return name of a file
	 */
	private String readFilename() throws IOException {

		stdErr.print("Filename> ");
		stdErr.flush();

		return stdIn.readLine();
	}

}
