package checkDormSystem;
/**
 * Check��
 * @author �⺣��
 * @see Dorm
 * @version 1.0
 *
 */
public class Check {
	private String Date;
	private double Score;
	
	/**
	 * �вι���
	 * @param date
	 * @param score
	 */
	public Check(String date, double score) {
		super();
		Date = date;
		Score = score;
	}
	
	/**
	 * �޲ι���
	 */
	public Check() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * ��ȡ��������
	 * @return String
	 */
	public String getDate() {
		return Date;
	}
	/**
	 * ��ȡ���յĳɼ�
	 * @return double
	 */
	public double getScore() {
		return Score;
	}
}
