package com.bank.unionpay;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Zhujiemian {
    
    public void zhujiemian()
    {
    System.out.println("���������ն�ϵͳ ");
    System.out.println();
    System.out.println("****************************");
    System.out.println();
    List<String> li=new ArrayList<String>();
    li.add("����");
    li.add("��ѯ");
    li.add("���");
    li.add("ȡ��");
    li.add("�˳�");
    for(int i=0;i<5;i++)
    {
        
        System.out.println(i+"-----"+li.get(i));
        
    }

    System.out.println();
    System.out.println("****************************");
    System.out.println();
    
    System.out.println("��ѡ����Ҫִ�еĹ��ܣ� ");
    }

}