package com.bank.abc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bank.unionpay.Yinhang;

public class Yinhanglei {
    
    //����������
    private Yinhang yinhang=Yinhang.ABC;
    
    private String name;
    
    public List<String> list=new ArrayList<>();
    
    public Map<String, Cuxuka> map=new HashMap<>();

    //˽�л����췽��
    private Yinhanglei() {
        super();
    
    }
    
    private static Yinhanglei bank=new Yinhanglei();
    
    public static Yinhanglei getYinhangLei()
    {
        return bank;
    }
    
}