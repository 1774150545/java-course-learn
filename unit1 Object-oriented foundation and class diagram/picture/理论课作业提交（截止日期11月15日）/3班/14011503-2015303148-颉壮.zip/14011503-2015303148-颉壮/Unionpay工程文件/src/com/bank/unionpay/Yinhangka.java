/**
 * 
 */
package com.bank.unionpay;

/**
 * @author zhuang
 *
 */
public interface Yinhangka {

	 public void cun();
	    
	 public void qu();
	    
	 public void getyu();
	 
}
