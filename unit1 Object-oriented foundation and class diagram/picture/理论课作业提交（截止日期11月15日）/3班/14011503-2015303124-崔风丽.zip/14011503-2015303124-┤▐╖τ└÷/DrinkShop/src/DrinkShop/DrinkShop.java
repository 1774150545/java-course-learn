package DrinkShop;

import java.io.*;

import java.util.ArrayList;

/**
 * �����ʵ����һ����Ʒ���������
 * 
 * @author fengfelc
 * @version 1.0
 *
 */
public class DrinkShop {

	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);

	/**
	 * ά��һ��˽����ƷĿ¼
	 */
	private DrinkCatalog drinkList = new DrinkCatalog();

	/**
	 * ȱʡ���캯�� ¼���ʼ��ƷĿ¼
	 */
	private DrinkShop() {

		this.drinkList = this.loadDrinkCatalog();

	}

	/**
	 * /** Creates an empty drinkCatalog and then add drinks to it.
	 *
	 * 
	 * @return drinkCatalog
	 */
	private DrinkCatalog loadDrinkCatalog() {
		// TODO Auto-generated method stub
		drinkList = new DrinkCatalog();
		drinkList.addDrink(new Beverage("beverage001", "Lemon juice", "plain", 8, "big"));
		drinkList.addDrink(new Beverage("beverage002", "Orange juice", "plain", 8, "big"));
		drinkList.addDrink(new Beverage("beverage003", "Orange juice", "plain", 5, "small"));
		drinkList.addDrink(new Beverage("beverage004", "Orange juice", "plain", 5, "small"));
		drinkList.addDrink(new MilkyTea("milkyTea001", "Coconut milk tea", "fruit", 9, "hot"));
		drinkList.addDrink(new MilkyTea("milkyTea002", "Pearl milk tea", "plain", 8.5, "hot"));
		drinkList.addDrink(new MilkyTea("milkyTea003", "Coconut milk tea", "plain", 9, "cold"));
		drinkList.addDrink(new MilkyTea("milkyTea004", "Pearl milk tea", "plain", 8.5, "cold"));
		return drinkList;
	}

	/**
	 * Loads data into the catalog and starts the application.
	 *
	 * @param args
	 *            String arguments. Not used.
	 * @throws IOException
	 *             if there are errors in the input.
	 */
	public static void main(String[] args) throws IOException {

		DrinkShop application = new DrinkShop();
		application.run();

	}

	/*
	 * Presents the user with a menu of options and executes the selected task.
	 */
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				displayDrinkCatalog();
			} else if (choice == 2) {
				addDrink();
			} else if (choice == 3) {
				removeDrink();
			} else if (choice == 4) {
				displayAllCosts();
			}
			choice = getChoice();
		}
	}

	/*
	 * Displays a menu of options and verifies the user's choice.
	 *
	 * @return an integer in the range [0,4]
	 */
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" 
				+ "[1] Display drink catalog\n" 
				+ "[2] Add a drink\n"
				+ "[3] Remove a drink\n"
				+ "[4] Display all costs\n"
				+ "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 4 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	/**
	 * choice 1 չʾ��ǰ��ƷĿ¼
	 */
	public void displayDrinkCatalog() {
		if (this.drinkList == null) {
			stdErr.println("the drink catalog is empty!");
			return;
		}

		stdOut.println(this.drinkList.toString());
	}

	/**
	 * ����һ����Ʒ����ƷĿ¼
	 * 
	 * @throws IOException,
	 *             NumberFormatException
	 */
	public void addDrink() throws IOException, NumberFormatException {

		stdOut.println("Next,add a drink :\n");

		int type;
		try {
			do {
				stdOut.println(
						"Please enter the  type you want to add\n" + "choice 1:beverage\n" + "choice 2:milkyTea");
				type = Integer.parseInt(stdIn.readLine());
				if (type == 1 || type == 2) {
					break;
				}

			} while (true);
			Drink drink = new Drink();
			stdOut.println("please enter Id>");
			String id = stdIn.readLine();

			stdOut.println("please enter name>");
			String name = stdIn.readLine();

			stdOut.println("please enter taste>");
			String taste = stdIn.readLine();

			stdOut.println("please enter cost>");
			double cost = Double.parseDouble(stdIn.readLine());

			stdOut.println("please enter size or type>");
			String string = stdIn.readLine();
			if (type == 1) {

				drink = new Beverage(id, name, taste, cost, string);

			}

			if (type == 2) {

				drink = new MilkyTea(id, name, taste, cost, string);

			}

			if (this.drinkList.addDrink(drink)) {
				stdOut.println("added sucessfully!");

			} else {
				stdErr.println("added filed!");
			}
		} catch (IOException ioe) {
			// TODO: handle exception
			stdErr.println(ioe.getMessage());
		}

	}

	/**
	 * ɾ��һ����Ʒ
	 * @throws IOException
	 */
	public void removeDrink() throws IOException {

		if (this.drinkList == null) {
			stdErr.println("the drink catalog is empty!");
			return;
		}
		stdOut.println("next,remove a drink\n" + "enter the id you want to removed>");
		String id = stdIn.readLine();
		if (this.drinkList.removeDrink(id)) {
			stdOut.println("remove successfully!");
		}

	}

	/**
	 * ��ʾ��ǰ������Ʒ���ܼ۸�
	 */
	public void displayAllCosts() {

		double allCost = 0;

		if (this.drinkList == null) {
			stdErr.println("the drink catalog is empty!");
			stdOut.println("all costs :" + allCost);
			return;
		}
		stdOut.flush();
		stdOut.println("all costs : " + this.drinkList.getAllCosts());
	}

}
