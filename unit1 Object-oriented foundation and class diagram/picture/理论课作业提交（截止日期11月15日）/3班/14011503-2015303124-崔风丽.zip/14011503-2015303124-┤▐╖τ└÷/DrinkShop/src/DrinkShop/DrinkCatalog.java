package DrinkShop;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * �����ʵ����ƷĿ¼�Ķ���,ʵ����Drink������
 * 
 * @author fengfelc
 * @version 1.0
 *
 */
public class DrinkCatalog implements Iterable<Drink> {

	/**
	 * ˽��Drink����
	 */
	private ArrayList<Drink> drinks = new ArrayList<Drink>();

	/**
	 * ȱʡ���캯��
	 */
	public DrinkCatalog() {

	}

	/**
	 * ���ι��캯��
	 * 
	 * @param initiDrinks
	 *            ������ƷĿ¼
	 */
	public DrinkCatalog(ArrayList<Drink> initiDrinks) {

		this.drinks = initiDrinks;

	}

	/**
	 * ��ȡ��ƷĿ¼
	 * 
	 * @return drinks
	 */
	public ArrayList<Drink> getDrinks() {
		return drinks;
	}

	/**
	 * ����һ����Ʒ����ƷĿ¼
	 * 
	 * @param drink
	 * @return true ������ӳɹ�������return false
	 */
	public boolean addDrink(Drink drink) {
		if (drink == null) {
			System.out.println("The drink does not exist!");
			return false;
		}

		if (this.getDrinks() == null) {
			this.drinks = new ArrayList<Drink>();
		}

		return this.drinks.add(drink);

	}

	/**
	 * 
	 * @param id
	 *            Ҫɾ����Ʒ��id
	 * @return true ���ɾ���ɹ�����֮return false
	 */
	public boolean removeDrink(String id) {

		if (this.drinks == null) {
			System.out.println("The drinkCatalog is empty!");
			return false;
		}

		for (Drink item : this.getDrinks()) {

			if (item.getId().equals(id)) {
				return this.drinks.remove(item);
			}
		}
		return false;
	}
	
	/**
	 * ��ȡ��ƷĿ¼����Ʒ����Ŀ
	 * 
	 * @return ��ƷĿ¼����Ʒ����Ŀ
	 */
	public int getNumberOfDrinks() {

		if (this.drinks == null) {
			System.out.println("The drinkCatalog is empty!");
			this.drinks = new ArrayList<Drink>();
			return 0;
		}

		return this.getDrinks().size();

	}

	public double getAllCosts()
	{
		if (this.getDrinks() == null) {
			this.drinks = new ArrayList<Drink>();
			System.out.println("The drinkCatalog is empty!");
			return  0;
		}
		double allCosts = 0;
		for(Drink item:this.getDrinks())
		{
			allCosts+=item.getCost();
		}
		return allCosts;
	}
	
	/**
	 * ʵ��Drink�������ӿ�
	 * 
	 * @return this.getDrinks().iterator()
	 */
	public Iterator<Drink> iterator() {
		return this.getDrinks().iterator();
	}

	/**
	 * toString����
	 */
	public String toString() {
		
		if (this.getDrinks() == null) {
			this.drinks = new ArrayList<Drink>();
			System.out .println("the drink catalog is empty!");
			return null;
		}
		
		String string=new String();
		for(Drink item :this.getDrinks())
		{
			string +=item.toString()+"\n";
		}
		return string;
	}

}
