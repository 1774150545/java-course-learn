package information;

public class InputFormatError extends Exception{

	public InputFormatError() {
		super();
	}

	public InputFormatError(String arg0) {
		super(arg0);
	}
	
}
