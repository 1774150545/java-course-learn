package information;

public class FixedStar extends Aster{
	private int tempreture;

	public FixedStar(String name, int radius, String texture, double revolutionPeriod, double rotationPeriod,int tempreture) {
		super(name, radius, texture, revolutionPeriod, rotationPeriod);
		this.tempreture=tempreture;
	}

	public int getTempreture() {
		return tempreture;
	}

	@Override
	public String toString() {
		return "FixedStar---- " + super.toString() + "tempreture="+tempreture ;
	} 
	
	
}
