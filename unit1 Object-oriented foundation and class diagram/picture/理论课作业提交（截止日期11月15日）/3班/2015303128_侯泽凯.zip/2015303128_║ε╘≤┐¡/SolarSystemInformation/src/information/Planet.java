package information;

public class Planet extends Aster{
	private int orbitalRadius;

	public Planet(String name, int radius, String texture, double revolutionPeriod, double rotationPeriod,int orbitalRadius) {
		super(name, radius, texture, revolutionPeriod, rotationPeriod);
		this.orbitalRadius=orbitalRadius;
	}

	public int getOrbitalRadius() {
		return orbitalRadius;
	}
	
	@Override
	public String toString() {
		return "Planet---- " + super.toString() +" "+ orbitalRadius;
	} 
	
}
