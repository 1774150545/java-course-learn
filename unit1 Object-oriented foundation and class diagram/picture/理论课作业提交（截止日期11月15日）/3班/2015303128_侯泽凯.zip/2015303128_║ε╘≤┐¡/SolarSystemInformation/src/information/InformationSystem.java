package information;

import java.util.*;
import java.io.*;

public class InformationSystem {
	
	private static BufferedReader  stdIn =
			new  BufferedReader(new  InputStreamReader(System.in));
	private static PrintWriter  stdOut =
			new  PrintWriter(System.out, true);
	private static PrintWriter  stdErr =
			new  PrintWriter(System.err, true);

	private ArrayList<Aster>asterIndex;
	
	private static InformationSystem system;
	
	public InformationSystem(){
		asterIndex=new ArrayList<Aster>();
	}
	
	public Aster getAster(String name){
		for(Aster cur:asterIndex){
			if(cur.getName()==name)
				return cur;
		}
		return null;
	}
	
	public int getchoice() throws IOException{
		int  input;

		do  {
			try  {

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 9 >= input)  {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException  nfe)  {
				stdErr.println(nfe);
			}
		}  while (true);
		return  input;
	}
	
	
	
	public static void main(String[] args) throws IOException{
		
		system=new InformationSystem();
		
		System.out.println("[0] Quit");
		System.out.println("[1] find an aster by name");
		System.out.println("[2] show all asters in System");
		System.out.println("[3] add an aster");
		System.out.println("[4] remove an aster by name");
		
		int choice=system.getchoice();
		
		while(choice!=0){
			
			if(choice==1){
				system.showSingleAster();
			}else if(choice==2){
				system.showAllAster();
			}else if(choice==3){
				system.addAster();
			}else if(choice ==4){
				system.removeAster();
			}
			
			System.out.println("[0] Quit");
			System.out.println("[1] find an aster by name");
			System.out.println("[2] show all asters in System");
			System.out.println("[3] add an aster");
			System.out.println("[4] remove an aster by name");
			choice=system.getchoice();
		}
	}
	
	public void showSingleAster() throws IOException{
		System.out.println("name:");
		
		String name=stdIn.readLine();
		
		Aster findAster=system.getAster(name);
		if(findAster!=null){
			findAster.toString();
		}else{
			System.out.println("This aster doesn't exist in cateloge.");
		}
	}
	
	public void showAllAster(){
		
		if(asterIndex.size()==0){
			stdOut.println("Index is empty");
			stdOut.println();
			return;
		}
			
		for(Aster cur:asterIndex){
			stdOut.println(cur.toString());
			stdOut.println();
		}
	}

	public void addAster()throws IOException{
		stdOut.println("please choise what kind of aster");
		stdOut.println("[1] fixed star");
		stdOut.println("[2] planet");
		stdOut.println("[3] asteroid");
		stdOut.println("[4] comet");
		stdOut.println("");
		stdOut.println("Format:");
		stdOut.println("fixed star:name_radius_texture_revolutionPeriod_rotationPeriod_tempture");
		stdOut.println("planet    :name_radius_texture_revolutionPeriod_rotationPeriod_orbitalRadius");
		stdOut.println("asteroid  :name_radius_texture_revolutionPeriod_rotationPeriod_orbitalRadius");
		stdOut.println("comet     :name_radius_texture_revolutionPeriod_rotationPeriod_DistanceNearSun_DisappearYear");
		
		int choice=getchoice();
		
		String message=stdIn.readLine();
		
		StringTokenizer st=new StringTokenizer(message,"_");
		
		int judge=0;
		
		try{
			do{
				if(choice==1){
					if(st.countTokens()!=6){
						throw new InputFormatError();
					}
					else {
						judge=1;
						asterIndex.add(new FixedStar(st.nextToken(),
								Integer.parseInt(st.nextToken()),
								st.nextToken(),
								Double.parseDouble(st.nextToken()),
								Double.parseDouble(st.nextToken()),
								Integer.parseInt(st.nextToken())));
					}
				}else if(choice==2){
					if(st.countTokens()!=6){
						throw new InputFormatError();
					}
					else {
						judge=1;
						asterIndex.add(new Planet(st.nextToken(),
								Integer.parseInt(st.nextToken()),
								st.nextToken(),
								Double.parseDouble(st.nextToken()),
								Double.parseDouble(st.nextToken()),
								Integer.parseInt(st.nextToken())));
					}
				}else if(choice==3){
					if(st.countTokens()!=6){
						throw new InputFormatError();
					}
					else {
						judge=1;
						asterIndex.add(new Asteroid(st.nextToken(),
								Integer.parseInt(st.nextToken()),
								st.nextToken(),
								Double.parseDouble(st.nextToken()),
								Double.parseDouble(st.nextToken()),
								Integer.parseInt(st.nextToken())));
					}
				}else if(choice==4){
					if(st.countTokens()!=7){
						throw new InputFormatError();
					}
					else {
						judge=1;
						asterIndex.add(new Comet(st.nextToken(),
								Integer.parseInt(st.nextToken()),
								st.nextToken(),
								Double.parseDouble(st.nextToken()),
								Double.parseDouble(st.nextToken()),
								Integer.parseInt(st.nextToken()),
								Integer.parseInt(st.nextToken())));
					}
				}
			}while(judge==0);
		}
		catch(InputFormatError ife){
			stdOut.println("Please input in correct format");
		}

	}
	
	public void removeAster()throws IOException{
		stdOut.println("please input the name of aster");
		
		String name=stdIn.readLine();
		
		for(Aster cur:asterIndex){
			if(cur.getName()==name){
				asterIndex.remove(cur);
				stdOut.println("remove success");
				return;
			}
		}
		stdOut.println("this aster didn't exist");
	}
	
}
