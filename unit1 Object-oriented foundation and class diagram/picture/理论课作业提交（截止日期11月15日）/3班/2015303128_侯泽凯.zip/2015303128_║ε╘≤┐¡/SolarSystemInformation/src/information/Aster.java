package information;

public class Aster {
	
	private String name;
	private int radius;
	private String texture;
	private double revolutionPeriod,rotationPeriod;
	
	public Aster(String name, int radius, String texture, double revolutionPeriod, double rotationPeriod) {
		this.name = name;
		this.radius = radius;
		this.texture = texture;
		this.revolutionPeriod = revolutionPeriod;
		this.rotationPeriod = rotationPeriod;
	}
	public String getName() {
		return name;
	}
	public int getRadius() {
		return radius;
	}
	public String getTexture() {
		return texture;
	}
	public double getRevolutionPeriod() {
		return revolutionPeriod;
	}
	public double getRotationPeriod() {
		return rotationPeriod;
	}
	@Override
	public String toString() {
		return "Aster [" + name + "]:"+"\n"+ "radius=" + radius +"\n"+ "texture=" + texture +"\n"
				+"revolutionPeriod="+ revolutionPeriod +"\n"
				+"rotationPeriod=" + rotationPeriod +"\n";
	}
	
	public boolean equalsTo(Aster temp){
		if(this.name==temp.name)
			return true;
		else
			return false;
	}
}
