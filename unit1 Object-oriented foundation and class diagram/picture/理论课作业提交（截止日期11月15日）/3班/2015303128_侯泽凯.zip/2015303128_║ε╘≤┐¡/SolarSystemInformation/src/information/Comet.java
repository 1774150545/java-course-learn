package information;

public class Comet extends Aster{
	private int distanceNearSun;
	private int disappearYear;
	
	public Comet(String name, int radius, String texture, double revolutionPeriod, double rotationPeriod,int distanceNearSun,int disappearYear) {
		super(name, radius, texture, revolutionPeriod, rotationPeriod);
		this.distanceNearSun=distanceNearSun;
		this.disappearYear=disappearYear;
	}

	public int getDistanceNearSun() {
		return distanceNearSun;
	}

	public int getDisappearYear() {
		return disappearYear;
	}
	
	@Override
	public String toString() {
		return "Comet---- " + super.toString() +" "+ distanceNearSun+" "+disappearYear;
	} 
}
