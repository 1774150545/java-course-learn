/**
 * 
 * @author CHM
 *
 */
public class DressSize extends Size {
	
	private double waist;
	
	/**
	 * @param style ����
	 * @param type ����
	 * @param legth �³�
	 * @param waist ��Χ
	 */
	public DressSize(String type,String length,double waist){
		super(type,length);
		this.waist=waist;
	}
	
	/**
	 * 
	 * @return  the waist ��Χ
	 */
	public double getWaist(){
		return waist;
	}
	/**
	 * 
	 * @param waist ������Χ
	 */
	public void setWaist(double waist) {
		this.waist = waist;
	}
	
	/**
	 * 
	 * @overwrite toString
	 */
	public String toString(){
		return "DressSize["+super.toString()+", waist="+this.waist +"]";
	}
}
