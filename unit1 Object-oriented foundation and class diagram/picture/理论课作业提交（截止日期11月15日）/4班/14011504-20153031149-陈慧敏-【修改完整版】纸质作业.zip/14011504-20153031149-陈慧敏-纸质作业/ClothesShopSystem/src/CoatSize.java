/**
 * 
 * @author CHM
 *
 */
public class CoatSize extends Size {

	private double shoulder;
	private double chest;
	private double sleeve;

	/**
	 * 
	 * @param length
	 *            �³�
	 * @param shoulder
	 *            ���
	 * @param chest
	 *            ��Χ
	 * @param type
	 *            ����
	 *@param  sleeve
	 *            ����
	 */
	public CoatSize(String type,String length, double shoulder, double chest,double sleeve) {
		super(type,length);
		this.shoulder = shoulder;
		this.chest = chest;
		this.sleeve=sleeve;

	}
/**
 * 
 * @return the shoulder ���
 */
	public double getShoulder() {
		return shoulder;
	}

	
	/**
	 * 
	 * @return chest ��Χ
	 */
	public double getChest() {
		return chest;
	}
	
	public double getSleeve(){
		return sleeve;
	}
	
	/**
	 * @Override toString 
	 */
	public String toString() {
		return "CoatSize ["+super.toString()+"shoulder=" + shoulder + ", chest=" + chest + ", sleeve=" + sleeve + "]";
	}
	
	

	
	
}
