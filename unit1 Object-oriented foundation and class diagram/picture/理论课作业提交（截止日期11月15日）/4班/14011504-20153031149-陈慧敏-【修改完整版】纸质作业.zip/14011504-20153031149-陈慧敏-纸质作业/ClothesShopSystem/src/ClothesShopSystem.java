import java.io.*;
import java.util.ArrayList;

/**
 * This class implements a Clothes Shop System.
 * @author CHM
 *
 */
public class ClothesShopSystem {

	private static BufferedReader stdIn = new BufferedReader ( new InputStreamReader (System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	
	private ClothesCatalog clothescatalog=new ClothesCatalog();


/**
 * Loads data into the catalog and starts the application.
 *
 * @param args
 *            String arguments. Not used.
 * @throws IOException
 *             if there are errors in the input.
 */
public static void main(String[] args) throws IOException{
	ClothesShopSystem application = new ClothesShopSystem();
	application.run();
	
	}

/**
 * @param initialCatalog
 *            a clothes catalog
 */

private ClothesShopSystem(){
	this.clothescatalog= loadClothesCatalog();
	}

private ClothesCatalog loadClothesCatalog(){
	
	ClothesCatalog clothescatalog = new ClothesCatalog();
	
	Feature feature1= new Feature("Askirt","summer","linen","sweet");
	Feature feature2= new Feature("loncoat","spring","wool","comfort");
	Feature feature3= new Feature("skinny","autumn","cotton","slim");
	Feature feature4= new Feature("stright","spring","cotton","comfort");
	Feature feature5= new Feature("thick","winter","wool","sweet");
	
	Size size1= new DressSize("S","36",68);
	Size size2= new DressSize("M","38",70);
	Size size3= new DressSize("L","40",73);
	
	Size size4=new CoatSize("S","98",36,97,57);
	Size size5=new CoatSize("M","100",38,100,59);
	Size size6=new CoatSize("L","102",40,104,61);
	
	Size size7=new PantSize("S","89",68,48);
	Size size8=new PantSize("M","92",70,52);
	Size size9=new PantSize("L","95",73,56);

	Size size10=new PantSize("S","89",68,53);
	Size size11=new PantSize("F","92",70,56);

	Size size12=new CoatSize("S","98",36,97,57);
	Size size13=new CoatSize("M","100",38,100,59);
	Size size14=new CoatSize("L","102",40,104,61);
	
	ArrayList<Size> sizes1=new ArrayList<Size>();
	ArrayList<Size> sizes2=new ArrayList<Size>();
	ArrayList<Size> sizes3=new ArrayList<Size>();
	ArrayList<Size> sizes4=new ArrayList<Size>();
	ArrayList<Size> sizes5=new ArrayList<Size>();
	
	sizes1.add(size1);
	sizes1.add(size2);
	sizes1.add(size3);
	
	sizes2.add(size4);
	sizes2.add(size5);
	sizes2.add(size6);
	
	sizes3.add(size7);
	sizes3.add(size8);
	sizes3.add(size9);
	
	sizes4.add(size10);
	sizes4.add(size11);
	
	sizes5.add(size12);
	sizes5.add(size13);
	sizes5.add(size14);
	
	
	Cloth cloth1=new Cloth("D001",66.6,"black",100,feature1,sizes1);
	Cloth cloth2=new Cloth("C001",233.3,"black",100,feature2,sizes2);
	Cloth cloth3=new Cloth("P002",90,"black",100,feature3,sizes3);
	Cloth cloth4=new Cloth("P001",123,"blue",100,feature4,sizes4);
	Cloth cloth5=new Cloth("C002",888,"gray",100,feature5,sizes5);
	
	ClothesCatalog clothList=new ClothesCatalog();
	clothList.addCloth(cloth1);
	clothList.addCloth(cloth2);
	clothList.addCloth(cloth3);
	clothList.addCloth(cloth4);
	clothList.addCloth(cloth5);
	return clothList;
	}

private void run() throws IOException {

	int choice = getChoice();

	while (choice != 0) {
		if (choice == 1) {
			displayClothesCatalog();
		} else if (choice == 2) {
			displayNumberOfClothes();
		} else if (choice == 3) {
			removeCloth();
		} else if (choice == 4) {
			buyACloth();
		}
		choice = getChoice();
	}
}


private int getChoice() throws IOException {

	int input;

	do {
		try {
			stdErr.println();
			stdErr.print("[0] Quit\n" + "[1] Display clothes catalog\n" 
					+ "[2] Display a number of clothes with a specific want\n" + "[3] Remove cloth\n"
					+ "[4] Buy a cloth\n"
					 + "choice> ");
			stdErr.flush();

			input = Integer.parseInt(stdIn.readLine());

			stdErr.println();

			if (0 <= input && 9 >= input) {
				break;
			} else {
				stdErr.println("Invalid choice:  " + input);
			}
		} catch (NumberFormatException nfe) {
			stdErr.println(nfe);
		}
	} while (true);

	return input;
}

	
/**
 * Displays the cloths catalog.
 */
public void displayClothesCatalog() {             

	int size = this.clothescatalog.getClothList().size();

	if (size == 0) {
		stdErr.println("The catalog is empty");
	} else {
		for (Cloth product : this.clothescatalog.getClothList()) {
			stdOut.println(product.toString());
		}
	}
}

/**
 * @param want��String
 * ͨ����������ɸѡչʾ�·�
 * @throws IOException
 */

public void displayNumberOfClothes()throws IOException{          
	stdErr.print("what kind of clothes do you want> ");
	stdErr.flush();
	String want=stdIn.readLine();
	for (Cloth product : this.clothescatalog.getClothList()) {
		if( product.find(want)){
			System.out.println(product.toString());
		}
	}
	
	
}
/**
 * ɾ���·�
 * @throws IOException
 */

public void removeCloth()throws IOException{                    
	
	Cloth product = readCloth();
	
	if (product != null) {
		for (int i = 0; i < clothescatalog.getClothList().size(); i++) {
			Cloth temp = clothescatalog.getClothList().get(i);
			if (temp.getCode().equals(product.getCode())) {
				this.clothescatalog.getClothList().remove(i);
				System.out.println("delete successfully!");
			}
		}
	}
	
	
}

/**
 * ����ͨ��code������
 * @param code
 * @param number
 * @throws IOException
 */

public void buyACloth()throws IOException{                        
	
	stdErr.print("Cloth code> ");
	stdErr.flush();
	String code=stdIn.readLine();
	
	stdErr.print("Number here> ");
	stdErr.flush();
	int num=Integer.parseInt(stdIn.readLine());
	
	clothescatalog.buy(code, num);
	
	
	
}

/**
 * 
 * @return Cloth
 * @throws IOException
 */

private Cloth readCloth() throws IOException {

	stdErr.print("Cloth code> ");
	stdErr.flush();

	Cloth product = this.clothescatalog.findClothByCode(stdIn.readLine());
	if (product != null) {
		return product;
	} else {
		stdErr.println("There are no clothes with that code");
		return null;
	}
}



}