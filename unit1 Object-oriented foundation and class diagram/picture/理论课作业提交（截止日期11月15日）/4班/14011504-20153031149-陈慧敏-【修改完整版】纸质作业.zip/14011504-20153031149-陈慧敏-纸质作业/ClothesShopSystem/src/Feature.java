/**
 * 
 * @author CHM
 *
 */
public class Feature {
	private String outline;
	private String season;
	private String madeBy;
	private String style;
	
	/**
	 * 
	 * @param outline ����
	 * @param season ����
	 * @param madeBy ����
	 * @param style ���
	 */
	public Feature(String outline,String season,
			String madeBy,String style){
		this.outline=outline;
		this.season=season;
		this.madeBy=madeBy;
		this.style=style;
	}

	/**
	 * 
	 * @return season
	 */
	public String getSeason() {
		return season;
	}

	/**
	 * 
	 * @return outline
	 */
	public String getOutline() {
		return outline;
	}


	/**
	 * 
	 * @return madeBy
	 */
	public String getMadeBy() {
		return madeBy;
	}

	

	/**
	 * 
	 * @return style
	 */
	public String getStyle() {
		return style;
	}

	@Override
	public String toString() {
		return "Feature [outline=" + outline + ", season=" + season + ", madeBy=" + madeBy + ", style=" + style + "]";
	}

	
 
	
	
}
