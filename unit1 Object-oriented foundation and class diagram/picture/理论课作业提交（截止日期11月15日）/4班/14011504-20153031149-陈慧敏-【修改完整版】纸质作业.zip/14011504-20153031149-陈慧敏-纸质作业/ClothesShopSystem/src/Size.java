/**
 * 
 * @author CHM
 *
 */
public class Size {
	
	private String type;
	private String length;
	 
	public Size (String type, String length){
		this.type=type;
		this.length=length;
	}

	/**
	 * 
	 * @return type
	 */
	public String getType() {
		return type;
	}

	/**
	 * 
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * 
	 * @return length
	 */
	public String getLength() {
		return length;
	}

	/**
	 * 
	 * @param length
	 */
	public void setLength(String length) {
		this.length = length;
	}


	public String toString() {
		return "Size [type=" + type + ", length=" + length + "]";
	}

	
}
