import java.util.ArrayList;

/**
 * 
 * @author CHM
 *
 */
public class Cloth {
	
	private String code;
	
	private double price;
	
	private String color;
	
	private int number;

	private Feature feature;
	
	private ArrayList<Size> sizes;
	
	/**
	 * 
	 * @param code �ͺ�
	 * @param price �۸�
	 * @param color ��ɫ
	 * @param number ���
	 * @param feature ����
	 * @param sizes ����
	 */
	public Cloth (String code,double price,String color,int number,
			Feature feature,ArrayList<Size> sizes){
		this.code=code;
		this.price=price;
		this.color=color;
		this.number=number;
		this.feature=feature;
		this.sizes=sizes;
		
	}

	/**
	 * 
	 * @return code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * 
	 * @return price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * 
	 * @return color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * 
	 * @return number
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * 
	 * @param number
	 */
	public void setNumber(int number) {
		this.number = number;
	}

	/**
	 * 
	 * @return feature
	 */
	public Feature getFeature() {
		return feature;
	}

	/**
	 * 
	 * @return sizes
	 */
	public ArrayList<Size> getSizes() {
		return sizes;
	}

	@Override
	public String toString() {
		
				
		return "Cloth [code=" + code + ", price=" + price + ", color=" + color + ", number=" 
	+ number + ", "+feature.toString() + "," + sizes.toString() + "]";
		}
	

	/**
	 * 
	 * @param code
	 * @return boolean
	 */
	public boolean equals(String code){
		if(this.code.equals(code))
			return true;
		else
			return false;	
		
	}
	
	/**
	 * 
	 * @param want
	 * @return boolean
	 */
	public boolean find (String want){
		if(this.feature.getOutline().equals(want)||
				this.feature.getSeason().equals(want)||
				this.feature.getMadeBy().equals(want)||
				this.feature.getStyle().equals(want))
			return true;
		else 
			return false;
	}
	

 
}
