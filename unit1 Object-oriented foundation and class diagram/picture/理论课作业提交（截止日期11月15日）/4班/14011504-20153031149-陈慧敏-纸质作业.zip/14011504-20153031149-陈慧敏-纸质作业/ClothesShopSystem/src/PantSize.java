/**
 * 
 * @author CHM
 *
 */
public class PantSize extends Size{
	
	private double  waist;
	private double  legAround;
	
	/**
	 * 
	 * @param type ����
	 * @param length �³�
	 * @param waist ��Χ
	 * @param legAround ��Χ
	 *
	 */
	public PantSize(String type,String length,double waist,double legAround){
		super(type,length);
		this.waist=waist;
		this.legAround=legAround;
		
	}
	/**
	 * 
	 * @return waist
	 */
	public double getWaist() {
		return waist;
	}
	/**
	 * 
	 * @param waist
	 */
	public void setWaist(double waist) {
		this.waist = waist;
	}
	/**
	 * 
	 * @return legAround
	 */
	public double getLegAround() {
		return legAround;
	}
	/**
	 * 
	 * @param legAround
	 */
	public void setLegAround(double legAround) {
		this.legAround = legAround;
	}
	
	/**
	 * @Override toString 
	 */
	public String toString(){
		return "PantSize ["+super.toString()+"waist=" + this.waist + ", legAround=" + this.legAround + "]";
	}
	

}
