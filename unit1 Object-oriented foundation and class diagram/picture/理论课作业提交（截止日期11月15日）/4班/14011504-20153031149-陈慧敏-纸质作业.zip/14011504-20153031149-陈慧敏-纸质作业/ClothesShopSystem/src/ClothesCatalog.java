import java.util.ArrayList;

/**
 * 
 * @author CHM
 *
 */
public class ClothesCatalog {
	
	private ArrayList<Cloth> clothesList=new ArrayList<Cloth>();
	
	/**
	 * 
	 * @param cloth
	 * @return boolean
	 */
	public boolean addCloth(Cloth cloth){
		if (clothesList.add(cloth))
			return true;
		else
			return false;
	}
	
	/**
	 * 
	 * @param code
	 * @return Cloth
	 */
	public Cloth findClothByCode(String code){
		for(int i=0;i<clothesList.size();i++){
			Cloth temp=clothesList.get(i);
			 if(temp.getCode().equals(code))
				 return temp;
		}
		return null;	
	}
	
	/**
	 * 
	 * @param want ��Ҫ���·�����
	 * @return Cloth 
	 */
	public Cloth findClothByFeature (String want){
		for(int i=0;i<clothesList.size();i++){
			Cloth temp=clothesList.get(i);
			 if(temp.find(want))
				 System.out.println(temp.toString());
		}
		return null;	
	}
	
	/**
	 * 
	 * @param code �ͺ�
	 * @param num  ����
	 */
	public void buy(String code,int num){
		for(int i=0;i<clothesList.size();i++){
			Cloth temp=clothesList.get(i);
			if(temp.getCode().equals(code)){
				if(temp.getNumber()<num){
					System.out.println("no enough clothes");
				}
				int n=temp.getNumber()-num;
				temp.setNumber(n);
				System.out.println("already bought"+code);
			}
			 
		}
		System.out.println("no such cloth");
		return;	
		
	}
}
