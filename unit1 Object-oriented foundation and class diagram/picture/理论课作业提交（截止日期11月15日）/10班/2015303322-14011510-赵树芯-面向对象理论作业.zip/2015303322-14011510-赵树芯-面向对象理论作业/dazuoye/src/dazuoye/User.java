/**
 * 
 */
package dazuoye;

/**
 * @author lenovo
 *
 */
public class User {
	/* the id of the user */
	private String id;
	/* the name of the user. */
	private String name;
	/* the gender of the user. */
	private String gender;
	/* the email of the user. */
	private String email;
	/* the telephone of the user. */
	private String telephone;
	/* the orderitem of the user. */
	private OrderItem orderitem;

	/**
	 * Constructs a <code>Product</code> object.
	 * 
	 * @param id
	 *            the id of the user.
	 * @param name
	 *            the name of the user.
	 * @param gender
	 *            the gender of the user.
	 * @param email
	 *            the email of the user.
	 * @param telephone
	 *            the telephone of the user.
	 * @param orderitem
	 *            the orderitem of the user.
	 * 
	 */
	public User(String id, String name, String gender, String email, String telephone, OrderItem orderitem) {
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.email = email;
		this.telephone = telephone;
		this.orderitem = orderitem;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * @param telephone
	 *            the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * @return the orderitem
	 */
	public OrderItem getOrderitem() {
		return orderitem;
	}

	/**
	 * @param orderitem
	 *            the orderitem to set
	 */
	public void setOrderitem(OrderItem orderitem) {
		this.orderitem = orderitem;
	}

}
