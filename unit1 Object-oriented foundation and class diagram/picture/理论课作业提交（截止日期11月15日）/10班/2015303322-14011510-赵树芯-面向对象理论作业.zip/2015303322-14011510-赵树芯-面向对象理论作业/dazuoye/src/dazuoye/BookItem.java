/**
 * 
 */
package dazuoye;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * This class models an item in an book. It contains the following information:
 * The class BookItem maintains a list of book items.
 * 
 * @author zhaoshuxin
 * @version 1.8.0
 * 
 */
public class BookItem implements Iterable<Book> {
	private ArrayList<Book> books;

	/**
	 *    
	 */
	public BookItem() {
		this.books = new ArrayList<Book>();
	}

	/**
	 * Adds the specified book item to the collection books.
	 * 
	 * @param book
	 *            this is a book
	 * @return true or false
	 */
	public boolean addBook(Book book) {
		this.books.add(book);
		return true;
	}

	/**
	 * Find the specified book with title from the collection books.
	 * 
	 * @param title
	 *            the title of a book
	 * @return a book
	 */
	public Book findBook(String title) {
		for (Book b : books) {
			if (b.getTitle().equals(title)) {
				return b;
			}
		}
		return null;
	}

	/**
	 * Find the specified book with code and depature from the collection books.
	 * 
	 * @param code
	 *            the code of a book
	 * @param depature
	 *            the depature of a book
	 * @return a book
	 */
	public Book findBook(String code, String depature) {
		for (Book b : books) {
			if (b.getCode().equals(code) && b.getDepature().equals(depature)) {
				return b;
			}
		}
		return null;
	}

	/**
	 * Returns the {link Book} object in this books.
	 * 
	 * @return the {link Book} object in this books.
	 */
	public ArrayList<Book> getBookList() {

		return books;
	}

	/**
	 * return the number of the books
	 * 
	 * @return the number of the books
	 */
	public int getNumberOfbook() {
		int k = 0;
		for (@SuppressWarnings("unused")
		Book b : books) {
			k = k + 1;
		}
		return k;
	}

	/**
	 * Returns an iterator over the instances in the collection books.
	 * 
	 * @return{@link Iterator}of{@link Book}
	 */
	public Iterator<Book> iterator() {
		return books.iterator();
	}
}
