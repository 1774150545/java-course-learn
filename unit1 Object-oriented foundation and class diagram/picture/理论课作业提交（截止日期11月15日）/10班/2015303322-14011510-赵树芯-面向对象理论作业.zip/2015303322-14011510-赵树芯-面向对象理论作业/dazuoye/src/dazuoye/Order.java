/**
 * 
 */
package dazuoye;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * The class Order maintains a list of order items.
 * 
 * @author zhaoshuxin
 * 
 * @version 1.8.0
 */
public class Order implements Iterable<Book> {
	/* id of the order */
	private String id;
	/* An ArrayList collection that contains books. */
	private ArrayList<Book> books = new ArrayList<>();

	/**
	 * Constructs a <code>Order</code> object.
	 * 
	 * @param code
	 *            the code of the order
	 * @param title
	 *            the title of the order
	 * @param depature
	 *            the sepature of the order
	 * 
	 */
	public Order(String code, String title, String depature) {

	}

	/**
	 * Adds the specified book item to the collection books.
	 *@param book
	 *   this is a book
	 */
	public void addBook(Book book) {
		books.add(book);
	}

	/**
	 * Returns the book of this Book.
	 * 
	 * @return the book of this Book.
	 * @param code
	 * the code of a book
	 */

	public Book getBook(String code) {
		for (Book b : books) {
			if (b.getCode().equals(code)) {
				return b;
			}
		}
		return null;
	}

	/**
	 * Returns the id of this Order.
	 * 
	 * @return the id of this Order.
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * Returns the price of this order.
	 * 
	 * @return the price of this order.
	 */
	public double getValue() {
		double sum = 0;
		for (Book b : books) {
			sum = sum + b.getPrice();
		}
		return sum;
	}

	/**
	 * Returns the string representation of this order. The string returned has
	 * the following format:
	 * 
	 * @return the string representation of this order.
	 */
	public String toString() {
		return "Order [id=" + id + "  books=" + books + ", getValue()=" + getValue() + "]";
	}

	/**
	 * Returns an iterator over the instances in the collection items.
	 * 
	 * @return{@link Iterator}of{@link Book}
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Iterator iterator() {
		return books.iterator();
	}

}
