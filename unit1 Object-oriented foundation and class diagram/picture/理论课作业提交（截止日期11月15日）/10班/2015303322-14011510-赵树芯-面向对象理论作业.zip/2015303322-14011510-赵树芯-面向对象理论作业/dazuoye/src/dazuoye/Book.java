/**
 * 
 */
package dazuoye;

/**
 * The class Book maintains a list of the books that have been completed.
 * 
 * @author zhaoshuxin
 *
 * @version 1.8.0
 */
public class Book {
	private String code;
	private String title;
	private String depature;
	private double price;

	/**
	 * @param code
	 *    the code of the book
	 * @param title
	 *    the title of the book
	 * @param depature
	 *    the depature of the book
	 * @param price
	 *      the price of the book
	 */
	public Book(String code, String title, String depature, double price) {
		super();
		this.code = code;
		this.title = title;
		this.depature = depature;
		this.price = price;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @return the depature
	 */
	public String getDepature() {
		return depature;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "code=" + getCode() + "  title=" + getTitle() + "  depature=" + getDepature() + "  price=" + getPrice();
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @param depature
	 *            the depature to set
	 */
	public void setDepature(String depature) {
		this.depature = depature;
	}

	/**
	 * @param price
	 *            the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

}
