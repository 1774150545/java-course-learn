/**
 * 
 */
package dazuoye;

/**
 * This class models a Vipuser. It extends {@link User}and implements the interface Calculation
 * 
 * @author zhaoshuxin
 * @version 1.8.0
 *
 */
public class Vipuser extends User implements Calculation {
	/**
	 * A public constructor makes it possible for any other class to create an
	 * instance of class Vipuser.
	 * @param id
	 *      the id of the user
	 * @param name
	 *       the name of the user.
	 * @param gender
	 * 		 the gender of the user.
	 * @param email
	 * 		the email of the user.
	 * @param telephone
	 *      the telephone of the user
	 * @param orderitem
	 *      the orderitem of the user.
	 * 
	 */
	public Vipuser(String id, String name, String gender, String email, String telephone, OrderItem orderitem) {
		super(id, name, gender, email, telephone, orderitem);

	}

	/**
	 * returns the totalPrice of this Vipuser.
	 * the calculation method is specialed.
	 * 
	 */
	@Override
	public double getCalculation() {
		double k = this.getOrderitem().getTotalPrice();
		k = k * 0.8;
		return k;
	}

	/**
	 * Returns the string representation of this Vipuser. The string returned
	 * has the following format:
	 * 
	 * @return the string representation of this Vipuser.
	 */
	@Override
	public String toString() {
		return "Vipuser [id=" + getId() + "  name=" + getName() + "  gender=" + getGender() + "  email=" + getEmail()
				+ "  getTelephone=" + getTelephone() + "]";
	}

}
