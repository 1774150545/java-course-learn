/**
 * 
 */
package dazuoye;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * This class models an item in an order. It contains the following information:
 * <ol>
 * <li>the order being purchased, a {@link OrderItem} reference</li>
 * <li>the totalPrice of the product in the order, an <code>int</code></li>
 * </ol>
 * 
 * @author zhaoshuxin
 * @version 1.8.0
 * @see OrderItem
 */
public class OrderItem implements Iterable<Order> {
	/*
	 * An ArrayList collection that contains references to instances of class
	 * 
	 * @OrderItem.
	 */
	private ArrayList<Order> orders;

	/**
	 * Creates the collection items, which is initially empty.
	 */
	public OrderItem() {
		orders = new ArrayList<>();
	}

	/**
	 * Adds the specified order item to the collection items.
	 * 
	 * @param order
	 *            this is a oder
	 * @return true or false
	 */
	public boolean addOrder(Order order) {
		this.orders.add(order);
		return true;
	}

	/**
	 * return the number of the orders
	 * 
	 * @return the number of the orders
	 */
	public int getNumberOfOder() {
		int k = 0;
		for (@SuppressWarnings("unused")
		Order b : orders) {
			k = k + 1;
		}
		return k;
	}

	/**
	 * Find the specified order with order from the collection orderitem.
	 * 
	 * @param order
	 *            this is a order
	 * @return a order
	 */
	public Order findOrder(Order order) {
		for (Order o : orders) {
			if (o.equals(order)) {
				return o;
			}
		}
		return null;
	}

	/**
	 * Find the specified order with id from the collection orderitem.
	 * 
	 * @param id
	 *            the id of a order
	 * @return a order
	 */
	public Order findOrder(String id) {
		for (Order o : orders) {
			if (o.getId().equals(id)) {
				return o;
			}
		}
		return null;
	}

	/**
	 * Returns the order of the order's TotalPrice.
	 * 
	 * @return the order of the order's TotalPrice.
	 */
	public double getTotalPrice() {
		double count = 0;
		for (Order o : orders) {
			count = count + o.getValue();
		}
		return count;
	}

	/**
	 * Returns an iterator over the instances in the collection orderitem.
	 * 
	 * @return{@link Iterator}of{@link OrderItem}
	 */
	@Override
	public Iterator<Order> iterator() {
		return this.orders.iterator();
	}

	/**
	 * Returns the {link OrderItem} object in this orders.
	 * 
	 * @return the {link OrderItem} object in this orders.
	 */
	public ArrayList<Order> getOrderList() {

		return orders;
	}

	/**
	 * Returns a string representation of this order item.
	 * 
	 * The string returned has the following format:
	 * 
	 * @return a string representation of this order.
	 */
	@Override
	public String toString() {
		return "OrderItem " + orders + "]";
	}

}
