/**
 * 
 */
package dazuoye;

/**
 * This interface declares the method that every "Calculation" class will
 * implement.
 * 
 * @author zhaoshuxin
 *
 * @version 1.8.0
 */
public interface Calculation {
	/**
	 * Produces a method to calculation the cost.
	 *  
	 * @return double totalcost
	 */
	public double getCalculation();

}
