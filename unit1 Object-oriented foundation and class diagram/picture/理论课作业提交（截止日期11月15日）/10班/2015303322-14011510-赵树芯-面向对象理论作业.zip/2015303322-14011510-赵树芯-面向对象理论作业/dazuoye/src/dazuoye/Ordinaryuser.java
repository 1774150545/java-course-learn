/**
 * 
 */
package dazuoye;


/**
 * This class models a Ordinaryuser. It extends {@link User}and implements the interface Calculation
 * 
 * @author zhaoshuxin
 * @version 1.8.0
 *
 */
public class Ordinaryuser extends User implements Calculation {
	/**
	 * A public constructor makes it possible for any other class to create an
	 * instance of class Ordinaryuser.
	 * @param id
	 *      the id of the user
	 * @param name
	 *       the name of the user.
	 * @param gender
	 * 		 the gender of the user.
	 * @param email
	 * 		the email of the user.
	 * @param telephone
	 *      the telephone of the user
	 * @param orderitem
	 *      the orderitem of the user.
	 */
	public Ordinaryuser(String id, String name, String gender, String email, String telephone,OrderItem orderitem) {
		super(id, name, gender, email, telephone,orderitem);
		
	}

	/**
	 * Returns the totalPrice of this Ordinaryuser.
	 * @return the totalPrice of this Ordinaryuser.
	 * the calculation method is specialed.
	 * 
	 */
	@Override
	public double getCalculation() {
		double k=this.getOrderitem().getTotalPrice();
		k=k*0.9;
		return k;
	}
	/**
	 * Returns the string representation of this Ordinaryuser. The string returned
	 * has the following format:
	 * 
	 * @return the string representation of this ordinaryuser.
	 */
	@Override
	public String toString() {
		return "Ordinaryuser [id=" +getId() + "  name=" + getName()+ "  gender=" + getGender()
				+ "  email=" + getEmail() + "  Telephone=" + getTelephone()+ "]";
	}

}
