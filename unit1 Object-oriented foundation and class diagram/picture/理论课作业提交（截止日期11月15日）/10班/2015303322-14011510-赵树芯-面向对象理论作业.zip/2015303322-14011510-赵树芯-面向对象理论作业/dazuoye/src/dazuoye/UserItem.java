/**
 * 
 */
package dazuoye;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * This class models an item in an user. It contains the following information:
 * <ol>
 * <li>the user being purchased, a {@link UserItem} reference</li>
 * <li>the {link UserItem} object in this orders</li>
 * </ol>
 * 
 * @author zhaoshuxin
 * @version 1.8.0
 * @see UserItem
 */
public class UserItem implements Iterable<User> {
	/*
	 * An ArrayList collection that contains references to instances of class
	 * 
	 * @UserItem.
	 */
	private ArrayList<User> users;

	/**
	 * Creates the collection items, which is initially empty.
	 */
	public UserItem() {
		this.users = new ArrayList<>();
	}

	/**
	 * return the number of the users
	 * 
	 * @return the number of the users
	 */
	public int getNumberOfUser() {
		int k = 0;
		for (@SuppressWarnings("unused")
		User b : users) {
			k = k + 1;
		}
		return k;
	}

	/**
	 * Adds the specified user item to the collection items.
	 * 
	 * @param user
	 *            Return the boolean
	 * @return true or false
	 * 
	 */
	public boolean addUser(User user) {
		this.users.add(user);
		return true;
	}

	/**
	 * Find the specified user with name from the collection orderitem. return
	 * the user
	 * 
	 * @return the user
	 * @param name
	 *            the name of user
	 */
	public User findUserByname(String name) {
		for (User u : users) {
			if (u.getName().equals(name)) {
				return u;
			}
		}
		return null;
	}

	/**
	 * Find the specified user with id and gender from the collection orderitem.
	 * Return the user.
	 * 
	 * @return the user.
	 * @param gender
	 *            the gender of user
	 * @param id
	 *            the id of user
	 */
	public User findUser(String id, String gender) {
		for (User u : users) {
			if (u.getId().equals(id) && u.getGender().equals(gender)) {
				return u;
			}
		}
		return null;
	}

	/**
	 * Returns the {link UserItem} object in this users.
	 * 
	 * @return the {link UserItem} object in this users.
	 */
	public ArrayList<User> getUserList() {

		return users;
	}

	/**
	 * Returns a string representation of this user item.
	 * 
	 * The string returned has the following format:
	 * 
	 * @return a string representation of this user.
	 */
	@Override
	public Iterator<User> iterator() {
		return users.iterator();
	}
}
