/**
 * 
 */
package dazuoye;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.io.*;

/**
 * This class implements a background management system.
 * 
 * @author zhaoshuxin
 * @version 1.8.0
 * 
 */
public class BackgroundManagementSystem {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private UserItem useritem = new UserItem();
	private BookItem bookitem;

	/**
	 * @param args
	 */
	/**
	 * Loads data into the item and starts the application.
	 *
	 * @param args
	 *            String arguments. Not used.
	 * @throws IOException
	 *             if there are errors in the input.
	 */
	public static void main(String[] args) throws IOException {

		BackgroundManagementSystem application = new BackgroundManagementSystem();
		application.run();

	}

	// ���к�����ʼ��
	public BackgroundManagementSystem() {
		this.bookitem = loadBookItem();
		this.useritem = loadUserItem();
	}

	/**
	 * Creates an empty Useritem and then add users to it.
	 *
	 * @return a UserItem
	 */
	private UserItem loadUserItem() {
		Order order1 = new Order("A001", "��������", "���");
		Order order2 = new Order("A009", "�����", "˾����");
		Order order3 = new Order("A007", "����Ϧʰ", "³Ѹ");
		Order order4 = new Order("A008", "�������Ʋ��ƶ�", "�Ҹ�˹");
		Order order5 = new Order("A003", "��¥��", "��ѩ��");
		Order order6 = new Order("A005", "��Хɽׯ", "������");

		order1.addBook(bookitem.findBook("��������"));
		order1.addBook(bookitem.findBook("�����"));

		order2.addBook(bookitem.findBook("����Ϧʰ"));
		order2.addBook(bookitem.findBook("��¥��"));
		order2.addBook(bookitem.findBook("��������"));

		order3.addBook(bookitem.findBook("��������"));

		order4.addBook(bookitem.findBook("��������"));
		order4.addBook(bookitem.findBook("�����"));
		order4.addBook(bookitem.findBook("����Ϧʰ"));

		order5.addBook(bookitem.findBook("����Ϧʰ"));
		order5.addBook(bookitem.findBook("��Хɽׯ"));

		order6.addBook(bookitem.findBook("��Хɽׯ"));
		order6.addBook(bookitem.findBook("�������Ʋ��ƶ�"));

		OrderItem orderitem1 = new OrderItem();
		orderitem1.addOrder(order1);

		OrderItem orderitem2 = new OrderItem();
		orderitem2.addOrder(order2);

		OrderItem orderitem3 = new OrderItem();
		orderitem3.addOrder(order3);

		OrderItem orderitem4 = new OrderItem();
		orderitem4.addOrder(order4);

		OrderItem orderitem5 = new OrderItem();
		orderitem5.addOrder(order5);

		OrderItem orderitem6 = new OrderItem();
		orderitem6.addOrder(order6);

		User user1 = new Ordinaryuser("001", "zhangyi", "nan", "123@qq.com", "2355", orderitem1);
		User user2 = new Vipuser("002", "zhanger", "nan", "553@qq.com", "122232", orderitem2);
		User user3 = new Vipuser("003", "zhangsan", "nv", "12883@qq.com", "23565255", orderitem3);
		User user4 = new Ordinaryuser("004", "zhangsi", "nan", "15523@qq.com", "2355465", orderitem4);
		User user5 = new Ordinaryuser("005", "zhangwu", "nan", "1235588@qq.com", "2355565", orderitem5);
		User user6 = new Vipuser("006", "zhangliu", "nv", "123599@qq.com", "23565554", orderitem6);

		useritem.addUser(user1);
		useritem.addUser(user2);
		useritem.addUser(user3);
		useritem.addUser(user4);
		useritem.addUser(user5);
		useritem.addUser(user6);

		return useritem;
	}

	/**
	 * Initializes the BookItem object.
	 */
	private BookItem loadBookItem() {
		Book book1 = new Book("A001", "��������", "���", 111.0);
		Book book2 = new Book("A002", "ͯ��", "�߶���", 76.0);
		Book book3 = new Book("A003", "��¥��", "��ѩ��", 53.0);
		Book book4 = new Book("A004", "����������", "��������", 230.0);
		Book book5 = new Book("A005", "��Хɽׯ", "������", 65.0);
		Book book6 = new Book("A006", "��������", "�޹���", 32.0);
		Book book7 = new Book("A007", "����Ϧʰ", "³Ѹ", 66.0);
		Book book8 = new Book("A008", "�������Ʋ��ƶ�", "�Ҹ�˹", 69.0);
		Book book9 = new Book("A009", "�����", "˾����", 25.0);
		bookitem = new BookItem();
		bookitem.addBook(book1);
		bookitem.addBook(book2);
		bookitem.addBook(book3);
		bookitem.addBook(book4);
		bookitem.addBook(book5);
		bookitem.addBook(book6);
		bookitem.addBook(book7);
		bookitem.addBook(book8);
		bookitem.addBook(book9);
		return bookitem;
	}

	/*
	 * Presents the user with a menu of options and executes the selected task.
	 */
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				getUserCost();
			} else if (choice == 2) {
				displayUserItem();
			} else if (choice == 3) {
				addBook();
			} else if (choice == 4) {
				displayBookItem();
			} else if (choice == 5) {
				addUser();
			} else if (choice == 6) {
				findBookByTitle();
			}
			choice = getChoice();
		}
	}

	/*
	 * Displays a menu of options and verifies the user's choice.
	 *
	 * @return an integer in the range [0,5]
	 */
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" + "[1] getUserCost\n" + "[2] display UserItem\n" + "[3] addBook\n"
						+ "[4] display BookItem\n" + "[5] addUser\n" + "[6] findBookByTitle(��������)\n" + "choice>");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 9 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	/**
	 * Displays the BookItem.
	 */
	public void displayBookItem() {

		int size = this.bookitem.getBookList().size();

		if (size == 0) {
			stdErr.println("The BookItem is empty");
		} else {
			for (Book book : this.bookitem.getBookList()) {
				stdOut.println(book.toString());
			}
		}
	}

	/**
	 * Displays the UserItem.
	 */
	public void displayUserItem() {
		int size = this.useritem.getUserList().size();
		if (size == 0) {
			stdErr.println("the UserItem is empty");
		} else {
			for (User user : this.useritem.getUserList()) {
				stdOut.println(user.toString());
			}
		}
	}

	/**
	 * 
	 * the book is added.
	 * 
	 * @throws IOException
	 *             if there are errors in the input.
	 */
	public void addBook() throws IOException {
		Book book = new Book(null, null, null, 0);
		Double price = 0.0d;
		stdErr.println("Now you can add the new one");
		stdErr.println("Please input code>");
		book.setCode(stdIn.readLine());
		stdErr.println("Please input title>");
		book.setTitle(stdIn.readLine());
		stdErr.println("Please input depature>");
		book.setDepature(stdIn.readLine());
		stdErr.println("Please input Price>");
		price = Double.valueOf(stdIn.readLine());
		book.setPrice(price);
		this.bookitem.addBook(book);
		System.out.println("Add book Successful!!");

	}

	/*
	 * get the specialed user's totalcost
	 *
	 */
	public void getUserCost() throws IOException {
		stdErr.println("Please input id(001-006)>");
		String id = null;
		id = stdIn.readLine();
		double k = 0;
		for (User user : useritem) {
			if (user.getId().equals(id)) {
				k = user.getOrderitem().getTotalPrice();
			}
		}
		System.out.println(k);

	}

	/**
	 * 
	 * the user is added.
	 * 
	 * @throws IOException
	 *             if there are errors in the input.
	 */
	public void addUser() throws IOException {
		User user = new User(null, null, null, null, null, null);
		stdErr.println("Now you can add the new user one");
		stdErr.println("Please input userid>");
		user.setId(stdIn.readLine());
		stdErr.println("Please input username>");
		user.setName(stdIn.readLine());
		stdErr.println("Please input usergender>");
		user.setGender(stdIn.readLine());
		stdErr.println("Please input useremail>");
		user.setEmail(stdIn.readLine());
		stdErr.println("Please input usertelephone>");
		user.setEmail(stdIn.readLine());
		this.useritem.addUser(user);
		System.out.println("Add user Successful!!");

	}

	/*
	 * get the book by the title
	 *
	 */
	public void findBookByTitle() throws IOException {
		stdErr.println("Please input title>");
		String title = null;
		title = stdIn.readLine();
		for (Book book : bookitem) {
			if (book.getTitle().equals(title)) {
				System.out.println(book);
			}
		}
	}
}
