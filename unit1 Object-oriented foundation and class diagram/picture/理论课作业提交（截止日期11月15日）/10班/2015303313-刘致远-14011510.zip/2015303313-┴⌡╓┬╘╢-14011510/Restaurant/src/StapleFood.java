
/**
 * StapleFood�࣬�̳�Food��
 * 
 * @author ����Զ
 *
 */
public class StapleFood extends Food {

	/**
	 * StapleFood�Ĺ��캯��
	 * 
	 * @param type
	 * @param code
	 * @param name
	 * @param price
	 */
	public StapleFood(String type, String code, String name, double price) {
		super(type, code, name, price);
		// TODO Auto-generated constructor stub
	}

}
