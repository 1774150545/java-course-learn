/**
 * 
 */
package theory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.util.StringTokenizer;

/**
 * @author ��һ��
 *@version0.0.1
 *Lovelive��Դ���������� 
 */
public class LoveliveResourcesSystem {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);

	private MusicCatalog musicCatalog;

	private Atlas atlas;

	/**
	 * @param args �����β�
	 * @throws IOException �Զ��׳���������쳣
	 * ������
	 */
	public static void main(String[] args) throws IOException {
		LoveliveResourcesSystem application = new LoveliveResourcesSystem();
		application.run();
	}
/**
 * ���캯��
 * 
 */
	private LoveliveResourcesSystem() {
		this.atlas = loadatlas();
		this.musicCatalog = loadmusic(this.atlas);

	}

	/**
	 * 
	 * 
	 * @return ��ʼ��ͼ����
	 */
	private Atlas loadatlas() {

		Atlas at = new Atlas();
		at.addPicture(new Picture("A1", "Guanfang"));
		at.addPicture(new Picture("A2", "Guanfang"));
		at.addPicture(new Picture("B1", "Guanfang"));
		at.addPicture(new Picture("B2", "Tongren"));
		at.addPicture(new Picture("B3", "Tongren"));
		at.addPicture(new Picture("C1", "Guanfang"));
		at.addPicture(new Picture("C2", "Guanfang"));

		return at;
	}

	/**
	 * 
	 * @param atlass ͼ��
	 * @return ��ʼ��ר����
	 */
	private MusicCatalog loadmusic(Atlas atlass) {
		MusicCatalog mcatalog = new MusicCatalog();
		mcatalog.addAlbum(new SoloAlbum("���Ȥ�Lovin�� you", atlass.getPicList().get(0), "11Y12M14D", "Minami Kotori",
				"�����ԥ��ƥ�֥롷�� �ͤ��LIVE ���Ȥ�LIFE��KOTORI Mix����������Ω`�����󥸣�KOTORI Mix����"));
		mcatalog.addAlbum(new SoloAlbum("������MIRACLE", atlass.getPicList().get(1), "14Y08M27D", "Hoshizora Rin",
				"��������MIRACLE����������MIRACLE��off vocal����"));
		mcatalog.addAlbum(new ChorusAlbum("Love marginal", atlass.getPicList().get(2), "11Y5M25D", "Printemps",
				"��Love marginal����sweet&sweet holiday����Love marginal(off vocal)����sweet&sweet holiday(off vocal)��"));
		mcatalog.addAlbum(new ChorusAlbum("�������줿���", atlass.getPicList().get(5), "14Y12M24D", "BiBi",
				"���������줿��С���Trouble Busters�����������줿���(off vocal)����Trouble Busters(off vocal)��"));
		mcatalog.addAlbum(new ChorusAlbum("΢�Ȥ���Mystery", atlass.getPicList().get(6), "13Y6M26D", "Lily White",
				"��΢�Ȥ���Mystery�������ߤΤ����ˣ�(off vocal)����΢�Ȥ���Mystery�������ߤΤ����ˣ�(off vocal)��"));
		return mcatalog;
	}

	/**
	 * ����̨��ʾ�Ĳ���ѡ�����
	 * 
	 * @throws IOException
	 */
	private void run() throws IOException {
		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				displayMusicCatalog();
			} else if (choice == 2) {
				displayAtlas();
			} else if (choice == 3) {
				addNewAlbum();
			} else if (choice == 4) {
				addNewPicture();
			} else if (choice == 5) {
				seeNumberOfAlbum();
			} else if (choice == 6) {
				seeNumberOfPicture();
			}
			
			choice = getChoice();
		}

	}
/**
 * @see ͼ�����ͼƬ����
 */
	private void seeNumberOfPicture() {
		System.out.println("the number of picture is : " + atlas.getPicList().size());

	}
/**
 * @see ר������
 */
	private void seeNumberOfAlbum() throws IOException {
		System.out.println("the number of albums is : " + musicCatalog.getAlist().size());

	}
/**
 *�����µ�ͼƬ
 * @throws IOException
 */
	private void addNewPicture() throws IOException {
		if (readPicture() == null) {
			System.out.println("Please put in another picture\n");
			addNewPicture();
		} else {
			atlas.addPicture(readPicture());
		}
	}
/**
 * ��ȡͼƬ��Ϣ
 * @return �������ӵ�ͼƬ��Ϣ
 * 
 * @throws IOException
 */
	private Picture readPicture() throws IOException {
		do {
			try {
				if (Pictureexist() != null) {
					stdErr.println("This Picture has exist");
					return null;
				}

				stdErr.print("Enter the information of newAlbum\n(Format:Pictureid_PicturePainter)> ");
				stdErr.flush();

				String str = stdIn.readLine();
				StringTokenizer tokenizer = new StringTokenizer(str, "_");
				String picid = tokenizer.nextToken();
				String picer = tokenizer.nextToken();

				if (tokenizer.hasMoreTokens()) {
					throw new NumberFormatException();
				}
				Picture pic = new Picture(picid, picer);
				stdErr.println("OK!");
				return pic;

			} catch (NumberFormatException nfe) {
				stdErr.println("Invalid number format!");
			}
		} while (true);

	}
/**
 * ������ר��
 * @throws IOException
 */
	private void addNewAlbum() throws IOException {
		if (readAlbum() == null) {
			System.out.println("Please put in another AlbumName \n");
			addNewAlbum();
		} else {
			musicCatalog.addAlbum(readAlbum());
		}
	}
/**
 * ����ͼƬʱ����ͼƬ�Ƿ����
 * @return ͼƬ��Ϣ
 * @throws IOException
 */
	private String Pictureexist() throws IOException {
		stdErr.print("PictureID> ");
		stdErr.flush();

		Picture album = this.atlas.findAlbumByName(stdIn.readLine());
		if (album != null) {
			return album.toString();
		} else {
			stdErr.println("There are no pictures with that name");

		}

		return null;

	}
/**
 * ������ר��ʱ����֤��ר���Ƿ����
 * @return �������ӵ�ר����Ϣ
 * @throws IOException
 */
	private String Albumexist() throws IOException {
		stdErr.print("AlbumName> ");
		stdErr.flush();

		Album album = this.musicCatalog.findAlbumByName(stdIn.readLine());
		if (album != null) {
			return album.toString();
		} else {
			stdErr.println("There are no albums with that name");

		}

		return null;

	}
/**
 * ��ȡ��ר����Ϣ
 * @return �������ӵ���ר��
 * @throws IOException
 */
	private Album readAlbum() throws IOException {
		do {
			try {
				if (Albumexist() != null) {
					stdErr.println("This album has exist");
					return null;
				}

				stdErr.print(
						"Enter the information of newAlbum\n(Format:name_Pictureid_PicturePainter_issuingDate_singer_songs)> ");
				stdErr.flush();

				String str = stdIn.readLine();
				StringTokenizer tokenizer = new StringTokenizer(str, "_");
				String name = tokenizer.nextToken();
				String picid = tokenizer.nextToken();
				String picer = tokenizer.nextToken();
				String issuingDate = tokenizer.nextToken();
				String singer = tokenizer.nextToken();
				String songs = tokenizer.nextToken();
				if (tokenizer.hasMoreTokens()) {
					throw new NumberFormatException();
				}
				if (singer.equals("Printemps") || singer.equals("BiBi") || singer.equals("Lily White")) {

					ChorusAlbum ch = new ChorusAlbum(name, (new Picture(picid, picer)), issuingDate, singer, songs);
					stdErr.println("OK!");
					return ch;
				} else {

					SoloAlbum so = new SoloAlbum(name, (new Picture(picid, picer)), issuingDate, singer, songs);

					stdErr.println("OK!");
					return so;
				}

			} catch (NumberFormatException nfe) {
				stdErr.println("Invalid number format!");
			}
		} while (true);

	}
/**
 * �����鿴ͼ������ͼƬ
 */
	private void displayAtlas() {
		int size = this.atlas.getPicList().size();

		if (size == 0) {
			stdErr.println("The atlas is empty");
		} else {
			for (Picture a : this.atlas.getPicList()) {
				stdOut.println(a.toString());
			}
		}

	}
/**
 * �����鿴����ר��
 */
	private void displayMusicCatalog() {

		int size = this.musicCatalog.getAlist().size();

		if (size == 0) {
			stdErr.println("The catalog is empty");
		} else {
			for (Album a : this.musicCatalog.getAlist()) {
				stdOut.println(a.toString());
			}
		}

	}
/**
 * �ӿ���̨��ȡ����ѡ��
 * @return ����ѡ��Ĳ������
 * @throws IOException
 */
	private int getChoice() throws IOException {
		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" + "[1] Display music catalog\n" + "[2] Display atlas\n"
						+ "[3] Add new album\n" + "[4] Add new picture\n" + "[5] Display number of album\n"
						+ "[6] Display number of picture\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 9 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;

	}

}
