/**
 * 
 */
package theory;

/**
 * @author ��һ��
 *@version 0.0.1
 *ͼƬ��
 */
public class Picture {
private String id;
private String painter;
/**
 * @param id ͼƬid
 * @param painter ͼƬ��ʦ
 */
public Picture(String id, String painter) {
	
	this.id = id;
	this.painter = painter;
}
/**
 * @return the id ���id
 */
public String getId() {
	return id;
}
/**
 * @return the painter ��û�ʦ
 */
public String getPainter() {
	return painter;
}
/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "Picture [id=" + id + ", painter=" + painter + "]";
}




}
