/**
 * 
 */
package theory;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author ��һ��
 * @version 0.0.1
 * ͼ����
 */
public class Atlas implements Iterable<Picture> {
	private ArrayList<Picture> picList = new ArrayList<Picture>();

	/**
	 * @param none
	 *            ���βι��캯��
	 * 
	 */

	public Atlas() {
	}

	/**
	 * @return the picList ����ͼƬ�б�
	 */
	public ArrayList<Picture> getPicList() {
		return picList;
	}

	@Override
	public Iterator<Picture> iterator() {

		return picList.iterator();
	}

	/**
	 * @param picture
	 *            ����ͼƬ
	 * 
	 */

	public void addPicture(Picture picture) {
		picList.add(picture);

	}

	/**
	 * 
	 * @param readLine
	 * @return ��id����ͼƬ
	 */

	public Picture findAlbumByName(String readLine) {
		for (int i = 0; i < picList.size(); i++) {
			if (readLine.equals(picList.get(i).getId())) {
				return picList.get(i);
			} else {
				continue;

			}
		}
		return null;

	}

}
