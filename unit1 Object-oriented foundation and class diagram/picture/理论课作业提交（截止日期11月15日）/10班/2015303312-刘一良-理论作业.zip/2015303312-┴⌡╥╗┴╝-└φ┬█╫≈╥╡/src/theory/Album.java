/**
 * 
 */
package theory;


/**
 * @author ��һ��
 *@version 0.0.1
 *ר����
 */
public class Album {
private String name;
private Picture cover;
private String issuingDate;

/**
 * @param name ����
 * @param cover ����ͼ
 * @param issuingDate ��������
 */
public Album(String name, Picture cover, String issuingDate) {
	super();
	this.name = name;
	this.cover = cover;
	this.issuingDate = issuingDate;
}
/**
 * @return the name �������
 * 
 */
public String getName() {
	return name;
}
/**
 * @return the cover ��÷���
 */
public Picture getCover() {
	return cover;
}
/**
 * @return the issuingDate ��÷�������
 */
public String getIssuingDate() {
	return issuingDate;
}
/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return  "AlbumName : "+name + "\n"+ "CoverID :��"+getCover().getId() +"\nCover's painter : "+getCover().getPainter()+"\nIssuingDate : "+  issuingDate;
}
	
	

}
