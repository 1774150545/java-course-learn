
import java.util.*;
import java.io.*;

/**
 * @author AAA
 * @version 1.0
 */

public class FastFoodSystem {

	private static PrintWriter stdErr = new PrintWriter(System.err,true);
	
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	
	Eater eater = new Eater("Liming", "1008611", 100, 50, 800);
	
//	static String food = "A001_egg_pig_cat_fish";
	
	static String food ;
	
	double monyy = eater.getMoney();
	
	
	
	/**
	 * ���붩���û���ѡ��
	 * @throws IOException
	 */
	public static void input() throws IOException {
		food = stdIn.readLine();
	}
	
	
	
	StringTokenizer tokenizer = new StringTokenizer(food,"_");
	
	static ArrayList<Restaurant> resList = new ArrayList<Restaurant>();	
	
	/**
	 * ��ʼ����Ϣ
	 */
	public static void load() {
		
		Dishes dish1 = new Dishes("pig",10);
		
		Dishes dish2 = new Dishes("cat",20);
		
		Dishes dish3 = new Dishes("tiger",30);
		
		Dishes dish4 = new Dishes("fish",50);
		
		Dishes dish5 = new Dishes("egg",11);
		
		Dishes dish6 = new Dishes("222",12);
		
		resList.add(new Restaurant("A001","1008611",new Menu(new ArrayList<Dishes>(Arrays.asList(dish1,dish2))),1000,5));
		
		resList.add(new Restaurant("A002","110",new Menu(new ArrayList<Dishes>(Arrays.asList(dish3,dish4))),200,4));
		
		resList.add(new Restaurant("A003","120",new Menu(new ArrayList<Dishes>(Arrays.asList(dish5,dish6))),1220,3));
	
	}		
	
	/**
	 * չʾ������Ϣ
	 */
	public void displayRestaurant() {
		for(Restaurant res : resList) {
			System.out.println(res.toString() + "\n");
		}
	}
	
	/**
	 * չʾ�����û���Ϣ
	 */
	public void displayEater() {
		System.out.println(eater.toString());
	}
	
	/**
	 * @return �����û��������ѵ��ܽ��
	 */
	public double calTotal() {
		double cost = 0;
		
        String res1 = tokenizer.nextToken();
		
		for(Restaurant res : resList) {
			if(res.getName().equals(res1) == true) {
				while(tokenizer.hasMoreTokens()) {
				String cur = tokenizer.nextToken();
//				System.out.println(cur + "\n");
				for(Dishes d : res.getMenu().dishesList) {
					if(d.getName().equals(cur) == true) {
						cost += d.getPrice();
					}
				}
			  }
			}
		}
		
		return cost;
		
	}
	
	/**
	 * ��ʾ�����û����ͺ�����
	 */
	public void displayMondy() {
		System.out.println(eater.getMoney());
	}
	
	private void run() throws IOException  {

		int choice = getChoice();

		double r = calTotal();
		
		while (choice != 0)  {
			if (choice == 1)  {
				displayRestaurant();
			} else if (choice == 2)  {
				displayEater();
			} else if (choice == 3)  {
				System.out.println(r);
			} else if (choice == 4)  {
				
				System.out.println(monyy - r);
			} 	
			choice = getChoice();
		}
	}


	private int  getChoice() throws IOException  {

		int  input;

		do  {
			try  {
				stdErr.println();
				stdErr.print(
					  "[0] Quit\n"
					+ "[1] Display Restaurant\n"
					+ "[2] Display Eater\n"
					+ "[3] CalTotal \n"
					+ "[4] GetMoney\n"
					+ "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 4 >= input)  {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException  nfe)  {
				stdErr.println(nfe);
			}
		}  while (true);

		return  input;
	}

	
	/**
	 * �������
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		
		stdErr.println("�������ݳ�ʼ��ԭ�򣬲��Ե�������Խ��٣�Ϊ��֤�������ʾ���볢�Ը����� �� A001_egg_pig_cat_fish");
		
		input();
		
		load();
		FastFoodSystem fast = new FastFoodSystem();
		fast.run();
	}
	
}
