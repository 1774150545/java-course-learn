/**
 * 
 */
import java.util.*;
/**
 * @author AAA
 * @version 1.0
 */
public class Menu {

	ArrayList<Dishes> dishesList = new ArrayList<Dishes>();
	
	/**
	 * �вι��캯��
	 */
	public Menu(ArrayList<Dishes> disList1) {
		this.dishesList = disList1;
	}
	
	/**
	 * �޲ι��캯��
	 */
	public Menu() {
		
	}
	
	/**
	 * @return ����Ĳ˵�
	 */
	public ArrayList<Dishes> getDishesList() {
		return dishesList;
	}
	
	/**
	 * ��˵������Ӳ�Ʒ
	 */
	public boolean addDishes(Dishes dishes1) {
		return dishesList.add(dishes1);
	}
	
}
