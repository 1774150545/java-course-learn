/**
 * 
 */

/**
 * @author AAA
 * @version 1.0
 */
public class Dishes {

	private String taset;
	
	private double price;
	
	private String name;

	/**
	 * �вι��캯��
	 * @param name1 ����
	 * @param price1 �۸�
	 */
	public Dishes(String name1, double price1) {
		this.name = name1;
		this.price = price1;
	}
	
	
	/**
	 * @return the taset
	 */
	public String getTaset() {
		return taset;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	
}
