/**
 * 
 */

/**
 * @author AAA
 * @version 1.0
 */
public class Eater extends User{

	private double money;
	
	private double total;
	
	private int distance;

	/**
	 * �вι��캯��
	 * @param name1 ����
	 * @param phone1 �绰����
	 * @param money1 �˻����
	 * @param total1 �����ܶ�
	 * @param distance1 �Ͳ͵ľ���
	 */
	public Eater(String name1, String phone1, double money1, double total1, int distance1) {
		this.name = name1;
		this.phone = phone1;
		this.money = money1;;
		this.total = total1;
		this.distance = distance1;
	}
	
	/**
	 * @return the money
	 */
	public double getMoney() {
		return money;
	}

	/**
	 * @return the total
	 */
	public double getTotal() {
		return total;
	}

	/**
	 * @return the distance
	 */
	public int getDistance() {
		return distance;
	}
	
	/**
	 * @return �����û��ľ�����Ϣ
	 */
	public String toString() {
		return getName() + "_" + getPhone() + "_" + String.valueOf(getMoney()) + "_" + 
	String.valueOf(getTotal()) + "_" + String.valueOf(getDistance());
	}
	
}
