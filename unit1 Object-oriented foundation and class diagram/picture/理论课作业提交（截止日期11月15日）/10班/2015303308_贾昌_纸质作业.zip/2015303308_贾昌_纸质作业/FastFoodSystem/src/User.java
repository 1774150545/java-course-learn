/**
 * 
 */

/**
 * @author AAA
 * @version 1.0
 */
public class User {

	protected String name;
	
	protected String phone;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	
}
