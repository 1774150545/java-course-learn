package reserve;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

/**
 * ��Ӱϵͳ��
 * 
 * @author wangjiadong
 * 
 * @date ����ʱ�䣺2016��11��12�� ����10:23:43
 * @version 1.0
 * @see VIPCatalog
 * @see MovieCatalog
 * @see LoadMovie
 * @see LoadVIP
 * @see DataFormatException
 */
public class CinemaSystem {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);

	/* ��ӰĿ¼�� */
	private MovieCatalog movieCatalog;

	/* VIPĿ¼ */
	private VIPCatalog vipCatalog;

	/**
	 * ���ص�ӰĿ¼��VIPĿ¼
	 * 
	 * @param args
	 *            �ַ���
	 * @throws IOException
	 *             ��������쳣ʱ�׳�
	 */
	public static void main(String[] args) throws IOException {
		MovieCatalog movieCatalog = null;
		VIPCatalog vipCatalog = null;
		try {
			movieCatalog = LoadMovie.getMovieCatalog();
			vipCatalog = LoadVIP.getVIPCatalog();
		} catch (FileNotFoundException fnfe) {
			stdErr.println("The file does not exist");
			System.exit(1);

		} catch (DataFormatException dfe) {
			stdErr.println("The file contains malformed data: " + dfe.getMessage());
			System.exit(1);
		}
		CinemaSystem system = new CinemaSystem(movieCatalog, vipCatalog);
		system.run();
	}

	/**
	 * ��ӰԺϵͳ���캯��
	 * 
	 * @param initMovieCatalog
	 *            ��ӰĿ¼
	 * @param initVIPCatalog
	 *            VIPĿ¼
	 */
	public CinemaSystem(MovieCatalog initMovieCatalog, VIPCatalog initVIPCatalog) {
		this.movieCatalog = initMovieCatalog;
		this.vipCatalog = initVIPCatalog;
	}

	/**
	 * ���û�һ��ѡ��Ŀ¼����ִ����Ӧ������
	 * 
	 * @throws IOException
	 *             ��������쳣ʱ�׳�
	 */
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				displayMovieCatalog();
			} else if (choice == 2) {
				displayMovie();
			} else if (choice == 3) {
				addMovie();
			} else if (choice == 4) {
				removeMovie();
			} else if (choice == 5) {
				displayNumberOfMoive();
			} else if (choice == 6) {
				reserveMovie();
			} else if (choice == 7) {
				becomeVIP();
			} else if (choice == 8) {
				removeVIP();
			}

			choice = getChoice();
		}
	}

	/**
	 * չʾ���û��˵�
	 * 
	 * @return 0~8������
	 * @throws IOException
	 *             ��������쳣ʱ�׳�
	 */
	private int getChoice() throws IOException {

		int input;

		while (true) {
			try {
				stdErr.println();
				stdErr.println("[0]  Quit\n" + "[1]  Display Movie Catalog\n" + "[2]  Display Movie\n"
						+ "[3]  Add Moive\n" + "[4]  Remove Moive\n" + "[5]  Display Number Of Moives\n"
						+ "[6]  Reserve Moive\n" + "[7]  Become VIP\n" + "[8]  Remove VIP\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 8 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		}

		return input;
	}

	/**
	 * ��ʾ��ӰĿ¼
	 */
	public void displayMovieCatalog() {
		int size = this.movieCatalog.getNumberOfMovie();

		if (size == 0) {
			stdErr.println("The movie catalog is empty");
		} else {
			for (Movie movie : this.movieCatalog) {
				stdOut.println(movie.toString());
			}
		}
	}

	/**
	 * �����Ӱ�����ֲ���ʾ��Ӱ����Ϣ
	 * 
	 * @throws IOException
	 *             ��������쳣ʱ�׳�
	 */
	public void displayMovie() throws IOException {
		stdErr.println("Please enter the name of the movie>");
		boolean isExist = false;
		;
		String name = stdIn.readLine();
		for (Movie movie : this.movieCatalog) {
			if (movie.getName().equals(name)) {
				stdOut.println(movie.toString());
				isExist = true;
			}
		}
		if (isExist == false) {
			stdErr.println("No such movie\n");
		}
	}

	/**
	 * �����µĵ�Ӱ
	 */
	public void addMovie() {
		Movie movie = null;

		while (true) {
			stdErr.println(
					"Please input a movie with the following format>\nName_Price_BeginTime_EndTime_Grade_Type_Position\n");
			try {
				StringTokenizer st = new StringTokenizer(stdIn.readLine(), "_");
				if (st.countTokens() == 7) {
					String name = st.nextToken();
					double price = Double.parseDouble(st.nextToken());
					String beginTime = st.nextToken();
					String endTime = st.nextToken();
					double grade = Double.parseDouble(st.nextToken());
					String type = st.nextToken();
					MovieHall movieHall = new MovieHall(st.nextToken());
					movie = new Movie(name, price, beginTime, endTime, grade, type, movieHall);
					for (int i = 0; i < this.movieCatalog.getNumberOfMovie(); i++) {
						if (this.movieCatalog.getMovie(i).equals(movie)) {
							movie = null;
							break;
						}
					}
					break;
				}
			} catch (IOException ioe) {
				stdErr.println(ioe.getMessage());
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe.getMessage());
			}
		}

		if (movie != null) {
			this.movieCatalog.addMovie(movie);
			stdErr.println("Add successfully");
		} else {
			stdErr.println("This movie already exists");
		}
	}

	/**
	 * ɾ��ָ����Ӱ
	 */
	public void removeMovie() {
		stdErr.println("Please enter the name of the movie>");
		try {
			String name = stdIn.readLine();
			if (movieCatalog.removeMoive(name)) {
				stdErr.println("Remove movie successfully");
			} else {
				stdErr.println("Can't find the movie");
			}
		} catch (IOException ioe) {
			stdErr.println(ioe.getMessage());
		}
	}

	/**
	 * ��ʾ��Ӱ�����͵�Ӱ������Ϣ
	 */
	public void displayNumberOfMoive() {
		stdOut.println("Number of movies: " + this.movieCatalog.getNumberOfMovie());
		for (int i = 0; i < this.movieCatalog.getNumberOfMovie(); i++) {
			stdOut.println(this.movieCatalog.getMovie(i).getName());
		}
	}

	/**
	 * Ԥ����Ӱ��ȷ����Ʊ���Ƿ�ΪVIP������ѡ����λ���������Ԥ������
	 * 
	 * @throws IOException
	 *             ��������쳣ʱ�׳�
	 */
	public void reserveMovie() throws IOException {
		boolean isVIP;
		stdErr.println("Please enter wheather you are VIP\n"
				+ "If you are VIP,please enter your phone number,if you are not VIP,please enter FALSE");
		while (true) {
			try {
				String str = stdIn.readLine();
				if (str.equals("FALSE")) {
					isVIP = false;
					break;
				} else {
					if (VIPCatalog.isVIP(str)) {
						isVIP = true;
						break;
					} else {
						stdErr.println(
								"Can't find the phone number\nPlease enter the phone umber again or enter FALSE\n");
					}
				}
			} catch (IOException ioe) {
				stdErr.println(ioe.getMessage());
			}
		}
		reserveMovie(isVIP);
	}

	/**
	 * ѡ����λ���������Ԥ����Ӱ����
	 * 
	 * @param isVIP
	 *            �Ƿ���VIP
	 * @throws IOException
	 *             ��������쳣ʱ�׳�
	 */
	private void reserveMovie(boolean isVIP) throws IOException {
		if (isVIP) {
			stdErr.println("You are our VIP");
		} else {
			stdErr.println("You are not our VIP");
		}
		Movie movie = null;
		this.displayNumberOfMoive();
		while (true) {
			stdErr.println("Please enter the name of the movie>");
			String name = stdIn.readLine();
			for (Movie choice : this.movieCatalog) {
				if (choice.getName().equals(name)) {
					movie = choice;
					break;
				}
			}
			if (movie != null) {
				break;
			}
			stdErr.println("This movie don't exist");
		}
		int cnt = 0;
		while (true) {
			try {
				stdErr.println("Please enter the number of ticket");
				cnt = Integer.parseInt(stdIn.readLine());
				if (cnt < this.movieCatalog.getNumberOfMovie()) {
					break;
				} else {
					stdErr.println("NO such more empty seats");
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe.getMessage());
			}
		}
		movie.displayEmptySeats();
		String seat[] = null;
		while (true) {
			stdErr.println("Please choice the seat with the following format\n"
					+ "Seat1_Seat2_Seat3_...\nFor example,A0_A1_A3");
			StringTokenizer st = new StringTokenizer(stdIn.readLine(), "_");
			stdOut.println(st.countTokens());
			seat = new String[st.countTokens()];
			MovieHall movieHall = movie.getMovieHall();
			if (st.countTokens() == cnt) {
				int i = 0;
				while (st.hasMoreTokens()) {
					String str = st.nextToken();
					if (!movieHall.availableSeat(new Seat(str))) {
						seat = null;
						break;
					} else {
						seat[i] = str;
						i++;
					}
				}
			} else {
				seat = null;
			}
			if (seat != null) {
				for (int i = 0; i < seat.length; i++) {
					for (int j = 0; j < seat.length; j++) {
						if (i != j) {
							if (seat[i].equals(seat[j])) {
								seat = null;
								break;
							}
						}
					}
				}
			}

			if (seat != null) {
				for (int i = 0; i < seat.length; i++) {
					Seat newSeat;
					if (seat[i].length() > 4) {
						newSeat = new LoversSeats((seat[i]));
					} else {
						newSeat = new CommonSeat((seat[i]));
					}
					movieHall.setSeatFull(newSeat);
					movie.addTicket(newSeat, isVIP, movie);
				}
				stdErr.println("Reserve successfully");
				break;
			} else {
				stdErr.println("Reserve failed!");
			}
		}
	}

	/**
	 * ����VIP
	 * 
	 * @throws IOException
	 *             ��������쳣ʱ�׳�
	 */
	public void becomeVIP() throws IOException {
		while (true) {
			stdErr.println("Please enter your name and phone number whit the following format\nname_phone nuber");
			StringTokenizer st = new StringTokenizer(stdIn.readLine(), "_");
			if (st.countTokens() == 2) {
				if (this.vipCatalog.addVIP(new VIP(st.nextToken(), st.nextToken()))) {
					stdErr.println("You have become our VIP");
				} else {
					stdErr.println("Yoe are already our VIP");
				}

				break;
			} else {
				stdErr.println("Format error");
			}
		}
	}

	/**
	 * �Ƴ�ָ����VIP
	 * 
	 * @throws IOException
	 *             ��������쳣ʱ�׳�
	 */
	public void removeVIP() throws IOException {
		stdErr.println("Please enter the phone number of VIP");
		String phoneNumber = stdIn.readLine();
		if (this.vipCatalog.removeVIP(phoneNumber)) {
			stdErr.println("Remove successfully");
		} else {
			stdErr.println("NO such phone number");
		}
	}

}
