/**
 * 
 */
package ���ۿ�;

/**
 * @author Acer
 *
 */
public class RockMusic extends Song {
private String band;

/**
 * @param name
 * @param iD
 * @param singer
 * @param yeat
 * @param album
 * @param type
 * @param band
 */
public RockMusic(String name, String iD, Singer singer, int yeat, Album album, String type, String band) {
	super(name, iD, singer, yeat, album, type);
	this.band = band;
}

/**
 * @return the band
 */
public String getBand() {
	return band;
}

/**
 * @param band the band to set
 */
public void setBand(String band) {
	this.band = band;
}

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "[ "+super.toString()  + band + " ]";
}

}
