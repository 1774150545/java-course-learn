/**
 * 
 */
package ���ۿ�;

/**
 * @author Acer
 *
 */
public class FolkMusic extends Song {
private String county;

/**
 * @param name
 * @param iD
 * @param singer
 * @param yeat
 * @param album
 * @param type
 * @param county
 */
public FolkMusic(String name, String iD, Singer singer, int yeat, Album album, String type, String county) {
	super(name, iD, singer, yeat, album, type);
	this.county = county;
}


/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return super.toString()+ county + " ]";
}


/**
 * @return the county
 */
public String getCounty() {
	return county;
}


/**
 * @param county the county to set
 */
public void setCounty(String county) {
	this.county = county;
}

}
