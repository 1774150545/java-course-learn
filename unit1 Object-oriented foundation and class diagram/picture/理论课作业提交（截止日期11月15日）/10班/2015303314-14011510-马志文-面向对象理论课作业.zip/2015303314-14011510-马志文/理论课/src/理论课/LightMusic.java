/**
 * 
 */
package ���ۿ�;

/**
 * @author Acer
 *
 */
public class LightMusic extends Song {
private String instrument;

/**
 * @param name
 * @param iD
 * @param singer
 * @param yeat
 * @param album
 * @param type
 * @param instrument
 */
public LightMusic(String name, String iD, Singer singer, int yeat, Album album, String type, String instrument) {
	super(name, iD, singer, yeat, album, type);
	this.instrument = instrument;
}

/**
 * @return the instrument
 */
public String getInstrument() {
	return instrument;
}

/**
 * @param instrument the instrument to set
 */
public void setInstrument(String instrument) {
	this.instrument = instrument;
}

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "[ "+super.toString() + instrument + "]";
}

}
