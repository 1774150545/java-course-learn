/**
 * 
 */
package ���ۿ�;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/**
 * @author Acer
 *
 */
public class MusicSystem {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private ListOfSong listOfSong;
	private ListOfSinger listOfSinger;

	/**
	 * @param listOfSong
	 * @param listOfSinger
	 */
	private MusicSystem() {
		this.listOfSong = loadListOfSong();
		this.listOfSinger =loadListOfSinger();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException{
		MusicSystem application=new MusicSystem();
		application.run();

	}
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				displayMusicList();
			} else if (choice == 2) {
				displaySingerList();
			} else if (choice == 3) {
				addSong();
			} else if (choice == 4) {
				addSinger();
			} else if (choice == 5) {
				removeSong();
			} else if (choice == 6) {
				removeSinger();
			}
			else if (choice == 7) {
				searchSongBy();
			}
			choice = getChoice();
		}
	}
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" + "[1] Display music list\n" + "[2] Display singer list\n"
						+ "[3] Add song for the list of song\n" + "[4] Add singer for the list of singer\n"
						+ "[5] Remove song from the list of song\n"
						+ "[6] Remove singer from the list of singer\n" + "[7]search song\n"+"choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 9 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}
	public void displayMusicList(){
		int size=listOfSong.getListOfSong().size();
		if (size == 0) {
			stdErr.println("The list is empty");
		}
		else{
			for(Song song:this.listOfSong.getListOfSong()){
				stdOut.println("[ "+song.getName()+" -"+song.getSinger().getName()+" ]");
			}
		}
	}
	public void displaySingerList(){
		int size=listOfSinger.getListOfSinger().size();
		if (size == 0) {
			stdErr.println("The list is empty");
		}
		else{
			for(Singer singer:this.listOfSinger.getListOfSinger()){
				stdOut.println("[ "+singer.getName()+" ,"+singer.getCounty()+" ]");
			}
		}
	}
	public void addSong() throws IOException {

		Song tempSong = new Song(null, null, null, 0, null, null);
			stdErr.println("Please input name>");
			tempSong.setName(stdIn.readLine());
			stdErr.println("Please input ID>");
			tempSong.setID(stdIn.readLine());
			stdErr.println("Please input the name of singer>");
			setSingerOfSong(tempSong, stdIn.readLine());
			stdErr.println("Please input year>");
			tempSong.setYear(Integer.valueOf(stdIn.readLine()));
			stdErr.println("Please input the name of album");
			setSAlbumOfSong(tempSong.getSinger(),tempSong, stdIn.readLine());
			stdErr.println("Please input type");
			tempSong.setType(stdIn.readLine());
			this.listOfSong.addSong(tempSong);
			System.out.println("Add song Successful!!");
		
		}
	public Singer addSinger() throws IOException {

		Singer tempSinger = new Singer(null, null, null);
			stdErr.println("Please input name>");
			tempSinger.setName(stdIn.readLine());
			stdErr.println("Please input ID>");
			tempSinger.setID(stdIn.readLine());
			stdErr.println("Please input country>");
			tempSinger.setCounty(stdIn.readLine());
			this.listOfSinger.addSinger(tempSinger);
			System.out.println("Add singer Successful!!");
		return tempSinger;
		}
	public void removeSong()throws IOException{
		stdErr.print("Input the name of song> ");
		stdErr.flush();
		this.listOfSong.removeSong(this.listOfSong.findSongByName(stdIn.readLine()));
	}
	public void removeSinger()throws IOException{
		stdErr.print("Input the name of singer> ");
		stdErr.flush();
		this.listOfSinger.removeSinger(this.listOfSinger.findSingerByName(stdIn.readLine()));
	}
	public int getChoioceofSearchSong()throws IOException{
		int	choice;
		do {
			try {
		stdErr.println();
		stdErr.print("[0] Quit\n" + "[1] search song by name\n" + "[2] search song by ID\n" + 
	"[3] search song by year\n" + "[4] search song by type\n"+"choice>" );
		stdErr.flush();

	choice = Integer.parseInt(stdIn.readLine());

	if (0 <= choice &&  4>= choice) {
		break;
	} else {
		stdErr.println("Invalid choice:  " + choice);
	}
} catch (NumberFormatException nfe) {
	stdErr.println(nfe);
}
			}while(true); 
		return choice;
		}
	public void searchSongBy()throws IOException{
		int choice=getChoioceofSearchSong();
		while (choice != 0) {
			if (choice == 1) {
				stdOut.println("Input the name of song >");
				if(listOfSong.findSongByName(stdIn.readLine()).equals(null))
				{
					stdOut.println("there isn't a song with the name:"+stdIn.readLine());
				}
				else{stdOut.println(this.listOfSong.findSongByName(stdIn.readLine()).toString());}
			} else if (choice == 2) {
				stdOut.print("Input the ID of song >");
				if(listOfSong.findSongByID(stdIn.readLine()).equals(null))
				{
					stdOut.println("there isn't a song with the ID:"+stdIn.readLine());
				}
				else{stdOut.println(this.listOfSong.findSongByID(stdIn.readLine()).toString());
				}
			
			}  else if (choice == 3) {
				stdOut.print("Input the year of song >");
				listOfSong.SearchSongByYear(Integer.valueOf(stdIn.readLine()));
			}  else if (choice == 4) {
				stdOut.print("Input the type of song >");
				String input=stdIn.readLine();
				listOfSong.SearchSongByType(input);
				}
			choice = getChoioceofSearchSong();
	}
	}
	private ListOfSong loadListOfSong() {

		ListOfSong list = new ListOfSong();
		Singer singer1=new Singer("Bob Dylan", "B1", "America");
		Singer singer2=new Singer("Tommy Emanuel", "B2", "Australia");
		Album album2=new Album("Only","C1", singer2, 2001);
        Album album1=new Album("Desire", "C1", singer1, 1976);
        FolkMusic song1 = new FolkMusic("Hurricane", "A1",singer1,1976,album1,"folk","Ameica");
        LightMusic song2=new LightMusic("Drive time", "A2", singer2, 2001, album2, "light music", "guitar");
		list.addSong(song1);
		list.addSong(song2);
		return list;
	}
	private ListOfSinger loadListOfSinger() {
		ListOfSinger list = new ListOfSinger();
        Singer singer1=new Singer("Bob Dylan", "B1", "America");
		Singer singer2=new Singer("Tommy Emanuel", "B2", "Australia");
		list.addSinger(singer1);
		list.addSinger(singer2);
		return list;
	}
	
public void setSingerOfSong(Song tempSong,String name)throws IOException{
 int i=0;
	for(Singer singer:this.listOfSinger.getListOfSinger()){
		if(singer.getName().equals(name)){
			tempSong.setSinger(singer);
			i=1;
		}
		
	}
	if(i==0){
			stdErr.println("The singer is not exist!Please add the singer->");
			Singer tempSinger=addSinger();
			tempSong.setSinger(tempSinger);
		
	}
}
public void setSAlbumOfSong(Singer singer,Song tempSong,String name)throws IOException{
	 int i=0;
		for(Album album:singer.getAlbumList()){
			if(album.getName().equals(name)){
				tempSong.setAlbum(album);
				i=1;
			}
			
		}
		if(i==0){
				stdErr.println("The album is not exist!Please add the album->");
				Album tempAlbum=new Album(null, null, null, 0);
				stdErr.println("Please input the name of Album>");
				tempAlbum.setName(stdIn.readLine());
				stdErr.println("Please input the ID of Album>");
                tempAlbum.setID(stdIn.readLine());
				tempAlbum.setSinger(singer);
				stdErr.println("Please input the publishYear of Album>");
                tempAlbum.setPublishYear(Integer.valueOf(stdIn.readLine()));
			
		}
	}
}
