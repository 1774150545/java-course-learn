/**
 * 
 */
package ���ۿ�;

import java.util.ArrayList;

/**
 * @author Acer
 *
 */
public class Singer {
	private String name;
	private String ID;
	private String county;
	private ArrayList<Album> albumList;
	/**
	 * @param name
	 * @param iD
	 * @param county
	 * @param albumList
	 */
	public Singer(String name, String iD, String county) {
		super();
		this.name = name;
		ID = iD;
		this.county = county;
		this.albumList = new ArrayList<Album>();
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	/**
	 * @return the county
	 */
	public String getCounty() {
		return county;
	}
	/**
	 * @param county the county to set
	 */
	public void setCounty(String county) {
		this.county = county;
	}
	/**
	 * @return the albumList
	 */
	public ArrayList<Album> getAlbumList() {
		return albumList;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return  name + ", " + ID + ", " + county ;
	}
	/**
	 * @param album
	 */
	public void addAlbum(Album album){
		albumList.add(album);
	}
	

}
