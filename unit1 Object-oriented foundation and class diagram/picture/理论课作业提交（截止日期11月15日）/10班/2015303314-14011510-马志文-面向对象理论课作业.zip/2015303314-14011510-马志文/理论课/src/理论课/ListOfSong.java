package ���ۿ�;

import java.util.ArrayList;

public class ListOfSong {
	private ArrayList<Song> listOfSong;

	/**
	 * @param listOfSong
	 */
	public ListOfSong() {
		this.listOfSong = new ArrayList<Song>();
	}

	/**
	 * @param song
	 */
	public void addSong(Song song) {
		listOfSong.add(song);
	}

	/**
	 * @param song
	 */
	public void removeSong(Song song) {
		listOfSong.remove(song);
	}

	/**
	 * @param ID
	 * @return
	 */
	public Song findSongByID(String ID) {
		Song song = null;
		for (Song src : listOfSong) {
			if (src.getID().equals(ID)) {
				song = src;
			}
		}
		return song;
	}

	/**
	 * @param name
	 * @return
	 */
	public Song findSongByName(String name) {
		Song song = null;
		for (Song src : listOfSong) {
			if (src.getName().equals(name)) {
				song = src;
			}
		}
		return song;
	}

	/**
	 * @param year
	 */
	public void SearchSongByYear(int year) {
		for (Song src : listOfSong) {
			if (src.getYear() == year) {
				System.out.println(src.getName() + "," + src.getSinger().getName());
			}
		}
	}
	/**
	 * @return
	 */
	public ArrayList<Song> getListOfSong(){
		return listOfSong;
	}

	public void SearchSongByType(String type) {
		for (Song src : listOfSong) {
			if (src.getType().equals(type)) {
				System.out.println(src.getName() + "," + src.getSinger().getName());
			}
		}
		
	}
}
