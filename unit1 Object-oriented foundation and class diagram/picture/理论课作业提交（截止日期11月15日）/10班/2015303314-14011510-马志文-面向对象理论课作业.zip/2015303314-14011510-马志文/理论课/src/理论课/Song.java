/**
 * 
 */
package ���ۿ�;

/**
 * @author Acer
 *
 */
public class Song {
	private String name;
	private String ID;
	private Singer singer ;
	private int year;
	private Album album;
	private String type;
	/**
	 * @param name
	 * @param iD
	 * @param singer
	 * @param year
	 * @param album
	 * @param type
	 */
	public Song(String name, String iD, Singer singer, int yeat, Album album, String type) {
		super();
		this.name = name;
		ID = iD;
		this.singer = singer;
		this.year = yeat;
		this.album = album;
		this.type = type;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	/**
	 * @return the singer
	 */
	public Singer getSinger() {
		return singer;
	}
	/**
	 * @param singer the singer to set
	 */
	public void setSinger(Singer singer) {
		this.singer = singer;
	}
	/**
	 * @return the yeat
	 */
	public int getYear() {
		return year;
	}
	/**
	 * @param yeat the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * @return the album
	 */
	public Album getAlbum() {
		return album;
	}
	/**
	 * @param album the album to set
	 */
	public void setAlbum(Album album) {
		this.album = album;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[" + name + ", " + ID + ", " + singer + ", " + year + ", " + album
				+ ", " + type+", ";
	}


}
