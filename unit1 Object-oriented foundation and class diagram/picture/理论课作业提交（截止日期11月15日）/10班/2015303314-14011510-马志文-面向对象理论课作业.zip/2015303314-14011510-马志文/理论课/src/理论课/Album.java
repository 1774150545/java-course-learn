/**
 * 
 */
package ���ۿ�;

import java.util.ArrayList;

/**
 * @author Acer
 *
 */
public class Album {
	private String name;
	private String ID;
	private Singer singer;
	private int publishYear;
	private ArrayList<Song> songList;
	/**
	 * @param name
	 * @param iD
	 * @param singer
	 * @param publishYear
	 * @param songList
	 */
	public Album(String name, String iD, Singer singer, int publishYear) {
		this.name = name;
		ID = iD;
		this.singer = singer;
		this.publishYear = publishYear;
		this.songList = new ArrayList<Song>();
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the iD
	 */
	public String getID() {
		return ID;
	}
	/**
	 * @param iD the iD to set
	 */
	public void setID(String iD) {
		ID = iD;
	}
	/**
	 * @return the singer
	 */
	public Singer getSinger() {
		return singer;
	}
	/**
	 * @param singer the singer to set
	 */
	public void setSinger(Singer singer) {
		this.singer = singer;
	}
	/**
	 * @return the publishYear
	 */
	public int getPublishYear() {
		return publishYear;
	}
	/**
	 * @param publishYear the publishYear to set
	 */
	public void setPublishYear(int publishYear) {
		this.publishYear = publishYear;
	}
	/**
	 * @return the songList
	 */
	public ArrayList<Song> getSongList() {
		return songList;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return name;
	}


}
