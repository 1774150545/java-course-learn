/**
 * 
 */
package ���ۿ�;

import java.util.ArrayList;

/**
 * @author Acer
 *
 */
public class ListOfSinger {
	private ArrayList<Singer> listOfSinger;

	/**
	 * @param listOfSinger
	 */
	public ListOfSinger() {
		this.listOfSinger = new ArrayList<Singer>();
	}

	/**
	 * @param ID
	 * @return
	 */
	public Singer findSingerByID(String ID) {
		Singer singer = null;
		for (Singer src : listOfSinger) {
			if (src.getID().equals(ID)) {
				singer = src;
			}
		}
		return singer;
	}

	/**
	 * @param Name
	 * @return
	 */
	public Singer findSingerByName(String Name) {
		Singer singer = null;
		for (Singer src : listOfSinger) {
			if (src.getName().equals(Name)) {
				singer = src;
			}
		}
		return singer;
	}

	/**
	 * @param county
	 */
	public void searchSingerByCounty(String county) {
		for (Singer singer : listOfSinger) {
			if (singer.getCounty().equals(county)) {
				System.out.println(singer.getName());
			}
		}
	}
	/**
	 * @return
	 */
	public ArrayList<Singer> getListOfSinger(){
		return listOfSinger;
	}

	public void addSinger(Singer singer) {
		listOfSinger.add(singer);
	}

	/**
	 * @param singer
	 */
	public void removeSinger(Singer singer) {
		listOfSinger.remove(singer);
		
	}
}
