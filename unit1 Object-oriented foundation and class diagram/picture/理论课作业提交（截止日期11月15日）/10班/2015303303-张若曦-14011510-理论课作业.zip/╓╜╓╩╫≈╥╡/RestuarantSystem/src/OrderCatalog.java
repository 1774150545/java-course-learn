import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author ������
 *
 */
public class OrderCatalog implements Iterable<Order> {

	private ArrayList<Order> orders;

	/**
	 * @param orders
	 */
	public OrderCatalog() {
		
		this.orders = new ArrayList<Order>();
	}
	
	/**
	 * Adds a {@link Order} object to this catalog.
	 *
	 * @param Ticket  the {@link Order} object.
	 */
	public void addOrder(Order order) {
		
		this.orders.add(order);
	}

	/**
	 * Removes a {@link Order} object from this collection
	 * and sets the {@link Order} object as available.
	 *
	 * @param ticket  the {@link Order} object.
	 */
	public void removeTicket(Order order) {
		
		this.orders.remove(order);
	}

	/**
	 * Returns an iterator over the tickets in this catalog.
	 *
	 * return  an {@link Iterator} of {@link Order}
	 */
	public Iterator<Order> iterator() {
		
		return this.orders.iterator();
	}

	/**
	 * @return the orders
	 */
	public Order getOrder(String code) {
		
		for (Order order : this.orders) {
			if (order.getCode().equals(code)) {
				
				return order;
			}
		}
		
		return null;
	}

	/**
	 * Returns the number of tickets in the catalog.
	 *
	 * @return the number of {@link Ticket} objects in this catalog.
	 */
	public int getNumberOfOrders() {
		
		return this.orders.size();
	}
}
