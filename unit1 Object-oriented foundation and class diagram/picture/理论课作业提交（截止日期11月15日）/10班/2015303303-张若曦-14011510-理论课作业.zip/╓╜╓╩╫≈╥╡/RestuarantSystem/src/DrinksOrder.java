/**
 * @author ������
 *
 */
public class DrinksOrder extends Order {
	private String supplier;
	
	private boolean available;

	/**
	 * @param supplier
	 * @param available
	 */
	public DrinksOrder(String initialName, String initialCode, String initialQuantity, String initialPrize,String initialSupplier) {
		super(initialName, initialCode, initialQuantity, initialPrize);
		
		this.supplier = initialSupplier;
		this.available = true;
	}

	/**
	 * @return the supplier
	 */
	public String getSupplier() {
		return supplier;
	}

	/**
	 * @return the available
	 */
	public boolean isAvailable() {
		
		return this.available;
	}

	/**
	 * @param available the available to set
	 */
	public void setAvailable(boolean value) {
		
		this.available = value;
	}
	
	/**
	 * @return the string representation of this drinks order
	 */
	public String tostring() {
		
		return super.tostring() + "_" + getSupplier() + "_" + isAvailable();
	}
}