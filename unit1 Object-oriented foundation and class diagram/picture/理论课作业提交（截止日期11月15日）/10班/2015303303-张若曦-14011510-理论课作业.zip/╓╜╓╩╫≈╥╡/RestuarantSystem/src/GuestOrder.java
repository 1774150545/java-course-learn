import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author 张若曦
 *
 */
public class GuestOrder implements Iterator<Order> {

	private ArrayList<Order> orders;

	/**
	 * @param tickets
	 */
	public GuestOrder() {
		
		this.orders = new ArrayList<Order>();
	}
	
	/**
	 * Adds a {@link Order} object to this collection and
	 * sets the {@link Order} object as not available.
	 *
	 * @param order  the {@link Order} object.
	 */
	public void addOrder(Order order) {
		
		this.orders.add(order);
	}
	
	/**
	 * Removes a {@link Order} object from this collection
	 * and sets the {@link Order} object as available.
	 *
	 * @param order  the {@link Order} object.
	 */
	public void removeOrder(Order order) {
		
		this.orders.remove(order);
	}
	
	/**
	 * Returns an iterator over the guest order in this collection.
	 *
	 * return  an {@link Iterator} of {@link Order}
	 */
	public Iterator<Order> iterator() {
		
		return this.orders.iterator();
	}

	/**
	 * @return the orders
	 */
	public Order getOrder(String code) {
		
		for (Order order : this.orders) {
			if (order.getCode().equals(code)) {
				
				return order;
			}
		}
		
		return null;
	}

	/**
	 * Returns the number of guest order.
	 *
	 * @return  the number of guest order.
	 */
	public int getNumberOfOrders() {
		
		return this.orders.size();
	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Order next() {
		// TODO Auto-generated method stub
		return null;
	}
}

