import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author ������
 *
 */
public class GuestCatalog implements Iterable<Guest> {

	private ArrayList<Guest> guests;

	/**
	 * @param guests
	 */
	public GuestCatalog() {
		
		this.guests = new ArrayList<Guest>();
	}
	
	/**
	 * Adds a {@link Guest} object to this collection.
	 *
	 * @param guest  the {@link Guest} object.
	 */
	public void addGuest(Guest guest) {
		
		this.guests.add(guest);
	}
	
	/**
	 * Returns an iterator over the guests in this database.
	 *
	 * return  an {@link Iterator} of {@link Guest}
	 */
	public Iterator<Guest> iterator() {
		
		return this.guests.iterator();
	}

	/**
	 * @return the guests
	 */
	public Guest getGuest(String code) {
		
		for (Guest guest : this.guests) {
			if (guest.getCode().equals(code)) {
				
				return guest;
			}
		}
		
		return null;
	}

	/**
	 * Returns the number of {@link Guest} objects in this collection.
	 *
	 * @return  the number of {@link Guest} objects in this collection.
	 */
	public int getNumberOfGuests() {
		
		return this.guests.size();
	}
}
