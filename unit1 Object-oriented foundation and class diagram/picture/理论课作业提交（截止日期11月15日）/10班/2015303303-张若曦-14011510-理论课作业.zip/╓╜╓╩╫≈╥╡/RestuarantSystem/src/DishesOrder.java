/**
 * @author 张若曦
 *
 */
public class DishesOrder extends Order {
	
	private String chief;
	
	/**
	 * @param chief
	 */
	
	public DishesOrder(String initialName, String initialCode, String initialQuantity, String initialPrize,String initialChief) {
		super(initialName, initialCode, initialQuantity, initialPrize);
		// TODO Auto-generated constructor stub
		
		this.chief = initialChief;

	}

	/**
	 * @return the airline
	 */
	public String getChief() {
		
		return this.chief;
	}

	/**
	 * @return the string representation of this drinks order
	 */
	public String tostring() {
		
		return super.tostring() + "_" + getChief();
	}
}
