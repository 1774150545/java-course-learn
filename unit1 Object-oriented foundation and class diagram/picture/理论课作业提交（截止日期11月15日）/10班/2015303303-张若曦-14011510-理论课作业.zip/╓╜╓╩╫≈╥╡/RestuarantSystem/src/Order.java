/**
 * @author 张若曦
 *
 */
public class Order {
	
	private String name;

	private String code;
	
	private String quantity;
	
	private String prize;

	/**
	 * @param name
	 * @param code
	 * @param quantity
	 * @param prize
	 */
	public Order(String initialName, String initialCode, String initialQuantity, 
			String initialPrize) {
		
		this.code = initialCode;
		this.name = initialName;
		this.quantity = initialQuantity;
		this.prize = initialPrize;

	}

	/**
	 * @return the code
	 */
	public String getCode() {
		
		return this.code;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}

	/**
	 * @return the prize
	 */
	public String getPrize() {
		return prize;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	/**
	 * @param prize the prize to set
	 */
	public void setPrize(String prize) {
		this.prize = prize;
	}

	/**
	 * Returns <code>true</code> if the code of this ticket is
	 * equal to the code of the argument
	 *
	 * @param object  object with which this ticket is compared.
	 * @return  <code>true</code> if the code of this ticket is
	 *          equal to the code of the argument; <code>false</code>
	 *          otherwise.
	 */
	public boolean equals(Object object) {
		
		return object instanceof Order
				&& getCode().equals(((Order) object).getCode());
	}

	/**
	 * Returns the string representation of this ticket.
	 *
	 * @return  the string representation of this ticket.
	 */
	public String tostring() {
		
		return getName() + "_" + getCode() + "_" + getQuantity() + "_" 
				+ getPrize();
	}
}
