/**
 * @author ������
 *
 */
public class Guest {

	private String code;
	
	private String name;
	
	private String seat;
	
	private GuestOrder guestOrder;

	/**
	 * @param name
	 * @param code
	 * @param seat
	 * @param guestOrder
	 */
	public Guest(String initialCode, String initialName, String initialSeat ) {
		
		this.code = initialCode;
		this.name = initialName;
		this.seat = initialSeat;
		this.guestOrder = new GuestOrder();
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		
		return this.code;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		
		return this.name;
	}

	/**
	 * @return the seat
	 */
	public String getSeat() {
		return seat;
	}

	/**
	 * @return the touristOrder
	 */
	public GuestOrder getGuestOrder() {
		
		return this.guestOrder;
	}

	/**
	 * Returns <code>true</code> if the code of this guest is
	 * equal to the id of the argument.
	 *
	 * @param object  object with which this guest is compared.
	 * @return  <code>true</code> if the code of this guest is
	 *          equal to the id of the argument; <code>false</code>
	 *          otherwise.
	 */
	public boolean equals(Object object) {
		
		return object instanceof Guest
				&& getCode().equals(((Guest) object).getCode());
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return getName() + "_" + getCode() + "_" + getSeat() + "_" ;
	}


}
