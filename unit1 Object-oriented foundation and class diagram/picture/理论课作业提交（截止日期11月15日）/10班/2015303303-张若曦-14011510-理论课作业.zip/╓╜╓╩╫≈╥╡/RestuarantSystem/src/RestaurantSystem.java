/**
 * 
 */

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.text.html.HTMLDocument.Iterator;

/**
 * @author ������
 *
 */
public class RestaurantSystem {

	private static BufferedReader  stdIn =
			new  BufferedReader(new  InputStreamReader(System.in));
	private static PrintWriter  stdOut = new  PrintWriter(System.out, true);
	private static PrintWriter  stdErr = new  PrintWriter(System.err, true);
	
	private OrderCatalog  orderCatalog;
	private GuestCatalog  guestCatalog;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {
		
		OrderCatalog orderCatalog  = load();
		
		RestaurantSystem app = new  RestaurantSystem(orderCatalog, load(orderCatalog));
		
		app.run();

	}
	
	private static OrderCatalog load() {
		
		OrderCatalog orderCatalog = new OrderCatalog();
		
		orderCatalog.addOrder(new DrinksOrder("ơ��", "1", "2", "8",
				"�Ƴ�"));
		orderCatalog.addOrder(new DrinksOrder("�׾�", "2", "1", "50",
				"�Ƴ�"));
		orderCatalog.addOrder(new DrinksOrder("��֭", "3", "3", "15",
				"��Դ"));
		orderCatalog.addOrder(new DrinksOrder("����", "4", "1", "5",
				"��ţ"));
		orderCatalog.addOrder(new DishesOrder("�׷�", "5", "4", "4",
				"�ų�ʦ"));
		orderCatalog.addOrder(new DishesOrder("����", "6", "2", "10",
				"�ų�ʦ"));
		orderCatalog.addOrder(new DishesOrder("��ͷ", "7", "3", "3",
				"����ʦ"));
		orderCatalog.addOrder(new DishesOrder("���ͱ�", "8", "1", "4",
				"����ʦ"));
		orderCatalog.addOrder(new DishesOrder("ϡ��", "9", "4", "4",
				"����ʦ"));
		
		return orderCatalog;
	}
	
	private static GuestCatalog load(OrderCatalog orderCatalog) {
		
		GuestCatalog guestCatalog = new GuestCatalog();
		
		Guest guest = new Guest("С��", "01", "5��λ");
		
		guest.getGuestOrder().addOrder(orderCatalog.getOrder("ơ��"));
		guest.getGuestOrder().addOrder(orderCatalog.getOrder("�׷�"));
		guest.getGuestOrder().addOrder(orderCatalog.getOrder("����"));
		guest.getGuestOrder().addOrder(orderCatalog.getOrder("ϡ��"));
		guestCatalog.addGuest(guest);
		
		guest = new Guest("С��", "02", "3��λ");
		guestCatalog.addGuest(guest);
		
		guest = new Guest("С��", "03", "4��λ");
		guest.getGuestOrder().addOrder(orderCatalog.getOrder("HU7138"));
		guestCatalog.addGuest(guest);
		
		guest = new Guest("С��", "04", "8��λ");
		guest.getGuestOrder().addOrder(orderCatalog.getOrder("G6521"));
		guest.getGuestOrder().addOrder(orderCatalog.getOrder("G6522"));
		guestCatalog.addGuest(guest);
		
		return guestCatalog;
	}

	private RestaurantSystem(OrderCatalog initialOrderCatalog,
            GuestCatalog initialGuestCatalog) {
		this.orderCatalog = initialOrderCatalog;
		this.guestCatalog = initialGuestCatalog;
	}
	
	private void run() throws IOException {
		
		int choice = getChoice();
		
		while (choice !=0) {
			
			if (choice ==1) {
				displayGuestCatalog();
			}else if (choice == 2) {
				displayOrder();
			}else if (choice == 3) {
				addOrder();
			}else if (choice == 4) {
				displayGuest();
			}
			choice = getChoice();
		}
	}
	
	private int getChoice() throws IOException {
		
		int input;
		
		do {
			try {
				stdErr.println();
				stdErr.print("[0]  Quit\n"
						     + "[1]  Display guest database\n"
						     + "[2]  Display order with a specific code\n"
						     + "[3]  Add order for orderCatalog\n"
						     + "[4]  Display guest with a specific code\n"
						     + "choice> ");
				stdErr.flush();
				
				input = Integer.parseInt(stdIn.readLine());
				
				stdErr.println();
				
				if (0 <= input && 4 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice: " + input);
				}
			} catch (NumberFormatException  nfe) {
				stdErr.println(nfe);
			}
		} while (true);
		
		return input;
	}
	
	private void displayGuestCatalog() {
		
		if (this.guestCatalog.getNumberOfGuests() == 0) {
			stdErr.println("The database of guests is empty");
		} else {
			for (Guest guest : this.guestCatalog) {
				stdOut.println(guest.getCode() + " " + guest.getName());
			}
		}
	}
	
	private void displayOrder() throws IOException {
		
		Order order = readOrder();
		
		if (order !=null) {
			stdOut.println("  Name: " + order.getName());
			stdOut.println("  Code: " + order.getCode());
			stdOut.println("  Quantity: " + order.getQuantity());
			stdOut.println("  Prize: " + order.getPrize());
			if (order instanceof DrinksOrder) {
				
				DrinksOrder drinksOrder = (DrinksOrder) order;
				
				stdOut.println("  Supplier: " + drinksOrder.getSupplier());
				stdOut.println("  Selling: " + (drinksOrder.isAvailable() ? "Available" : "Not available"));
			} else if (order instanceof DishesOrder) {
				
				DishesOrder dishesOrder = (DishesOrder) order;
				
				stdOut.println("  TypeOfTrain: " + dishesOrder.getChief());
			}
		} else {
			stdErr.println("There is no order with that code");
		}
	}
	
	private void displayGuest() throws IOException {
		
		Guest guest = readGuest();
		
		if (guest != null) {
			
			stdOut.println("  Name: " + guest.getName());
			stdOut.println("  Code: " + guest.getCode());
			stdOut.println("  Seat: " + guest.getSeat());
			
		} else {
			stdErr.println("There is no guest with that code");
		}
	}
	
	public void addOrder() throws IOException {
		
		Order order = readOrder();
		
		if (order == null) {
			Order tempOrder = new Order(null, null, null, null);
			String temp = "";
			stdErr.println("Now you can add the new one");
			stdErr.println("Please input name>");
			tempOrder.setName(stdIn.readLine());
			stdErr.println("Please input code>");
			tempOrder.setCode(stdIn.readLine());
			stdErr.println("Please input quantity>");
			tempOrder.setQuantity(stdIn.readLine());
			stdErr.println("Please input prize>");
			tempOrder.setPrize(stdIn.readLine());
			
			this.orderCatalog.addOrder(tempOrder);
			System.out.println("Add Order Successful!");
		} else {
			stdErr.println("The Order is already exist!");
		}
	}
	
	private Order readOrder() throws IOException {
		
		stdErr.print("Order code> ");
		stdErr.flush();
		
		return this.orderCatalog.getOrder(stdIn.readLine());
	}
	
	private Guest readGuest() throws IOException {
		
		stdErr.print("Guest code> ");
		stdErr.flush();
		
		return this.guestCatalog.getGuest(stdIn.readLine());
	}
}
