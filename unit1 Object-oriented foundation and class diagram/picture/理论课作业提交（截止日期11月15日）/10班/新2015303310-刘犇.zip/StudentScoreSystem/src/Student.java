public class Student {
	private String name;
	private int number;
	private ScoreList scores;  
	public static final int maxNumberOfCourses = 100;  
    
	
	Student(String nameIn, int numberIn) {
		name = nameIn;
		number = numberIn;
		scores = new ScoreList(maxNumberOfCourses);
	}
	
	public String getName() {
		return name;
	}
	
	public int getNumber() {
	    return number;
	}
	
	public void makeScore(Score scoreIn) {
		scores.add(scoreIn);   
	}
	
	public ScoreList getScores() {
		return scores;
	}
}
