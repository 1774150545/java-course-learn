public class ScoreList extends ObjectList {
	public ScoreList(int sizeIn) {  
	    super(sizeIn);
	}

	public Score getScore(int positionIn) {  
	    if (positionIn <1 || positionIn > getTotal())
			return null;
		else
			return (Score) getItem(positionIn);
	}
	
	public int calculateAverageScore() {
		int totalScore = 0;
		int averageScore = 0; 
		for (int i = 1; i <= getTotal();i++)  
			totalScore = totalScore + getScore(i).getMark();
		averageScore = (int)(totalScore / getTotal());
		return averageScore;
	}
}
