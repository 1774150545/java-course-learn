public class Score {
	private String course;
	private int mark;
	
	public Score(String courseIn, int markIn) {
		course = courseIn;
		mark = markIn;
	}
	
	public String getCourse() {
		return course;
	}
	
	public int getMark() {
		return mark;
	}
}
