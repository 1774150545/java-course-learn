public class RunTeam {
    public static void main(String[] args) {
	    new Team(32);
    } 
}
