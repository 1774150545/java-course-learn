import java.awt.*;
import java.awt.event.*;
import java.text.*;
import javax.swing.*;
import javax.swing.border.*;

public class Team extends JFrame implements ActionListener{
    private  int numbers;
    private  StudentList list;
    
	private  JTextField numberField =  new JTextField(4);
    private  JTextField nameField =  new JTextField(39);
    
	private  JButton addButton  = new JButton("����ѧ��");
    private  JButton displayButton =  new JButton("��ʾ����");
    private  JButton removeButton  = new JButton("ɾ��ѧ��");
    private  JButton quitButton   =new JButton("�˳�"); 
	
    private  JTextArea displayArea1  = new JTextArea(8,45);

    private  JTextField numberField2  = new JTextField(4);
    private  JTextField courseField  = new JTextField(7);
    private  JTextField markField =  new JTextField(8);
    private JButton scoreButton = new JButton("   ����ɼ�   ");
    private JButton listButton = new JButton("   �ɼ��б�   ");

	private  JTextArea displayArea2 =  new JTextArea(8,45);

    public Team(int numberIn){
		numbers =  numberIn;
		list  = new StudentList(numbers);    
		
		setLayout(new FlowLayout( ));
		setTitle("�༶�γ̳ɼ���");
		setLocation(400,100);
        setSize(550, 450);
		getContentPane().setBackground(Color.cyan);
		BevelBorder raisedBevel =  new BevelBorder(BevelBorder.RAISED);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		add(numberField);
		numberField.setBorder(new TitledBorder("���"));
		
		add(nameField);
		nameField.setBorder(new TitledBorder("����"));
		
		add(addButton);
		addButton.setBorder(raisedBevel);
        addButton.setBackground(Color.green);
		
		add(displayButton);
		displayButton.setBorder(raisedBevel);
		displayButton.setBackground(Color.green);
		
		add(removeButton);
		removeButton.setBorder(raisedBevel);
        removeButton.setBackground(Color.green);
		
		add(quitButton); 
		quitButton.setBorder(raisedBevel);
		quitButton.setBackground(Color.green); 
		
        displayArea1.setBorder(new TitledBorder(new LineBorder(Color.black),
	                  "ѧ��",TitledBorder.CENTER,TitledBorder.TOP));
		JScrollPane p1 =  new JScrollPane(displayArea1);
		add(p1);
		
		add(numberField2);
		numberField2.setBorder(new TitledBorder("���"));
		
		add(courseField);
		courseField.setBorder(new TitledBorder("�γ�"));
		
		add(markField);
		markField.setBorder(new TitledBorder("�ɼ�"));
		
		add(scoreButton);
		scoreButton.setBorder(raisedBevel);
		scoreButton.setBackground(Color.green);
		
		add(listButton);
		listButton.setBorder(raisedBevel);
		listButton.setBackground(Color.green);

		displayArea2.setBorder(new TitledBorder(new LineBorder(Color.black),
							   "�ɼ�",TitledBorder.CENTER,TitledBorder.TOP));
		JScrollPane p2 = new JScrollPane(displayArea2);
		add(p2);
		
		addButton.addActionListener(this);
		displayButton.addActionListener(this);
		removeButton.addActionListener(this);
        quitButton.addActionListener(this); 
		scoreButton.addActionListener(this);
		listButton.addActionListener(this);

		setVisible(true);
	} 

	public void actionPerformed(ActionEvent e) {
	    if(e.getSource() == addButton) {
	        String numberEntered = numberField.getText();
		    String nameEntered = nameField.getText();
		    if(numberEntered.length()== 0 || nameEntered.length()== 0)
		 	    displayArea1.setText ("���������ȱһ���ɣ�");
		    else if(Integer.parseInt(numberEntered)< 1 || Integer.parseInt(numberEntered) > numbers)
		  	    displayArea1.setText ("��ű������������������ֵΪ " + numbers);
		    else if(list.search(Integer.parseInt(numberEntered)) !=  null)
			    displayArea1.setText("��� " +  Integer.parseInt(numberEntered)  + " �Ѵ��ڣ�");
		    else {
			    Student s =  new Student(nameEntered,Integer.parseInt(numberEntered));
		  	    list.add(s);
	    	    numberField.setText("");
	    	    nameField.setText("");
	    	    displayArea1.setText("���Ϊ " 	+  numberEntered +  " ��ѧ���ѳɹ����ӣ�");
    	    } 
	    } 

	    if(e.getSource() == displayButton) {
    	    int i;
    	    if(list.isEmpty())
			    displayArea1.setText("û���κ�ѧ����Ϣ��");
    	    else {
			    displayArea1.setText("���" +  "\t" +  "����" +  "\n");
			    for(i = 1; i <=  list.getTotal(); i++ )
				    displayArea1.append(list.getStudent(i).getNumber() + "\t" + list.getStudent(i).getName() + "\n");  
	        }
        }

	    if(e.getSource()== removeButton) {
      	    String numberEntered =  numberField.getText();
    	    if(numberEntered.length()== 0)
			    displayArea1.setText("ɾ��ѧ����Ϣʱ�����������ţ�");
    	    else if(Integer.parseInt(numberEntered) < 1 || Integer.parseInt(numberEntered) > numbers)
			    displayArea1.setText("����ı�Ų����趨��Χ�ڣ�");
    	    else if(list.search(Integer.parseInt(numberEntered))== null)
			    displayArea1.setText("���Ϊ " +  numberEntered +  " ��ѧ�������ڣ�");
    	    else {
			  list.removeStudent(Integer.parseInt(numberEntered));
			  displayArea1.setText("���Ϊ " +  Integer.parseInt(numberEntered) + " ��ѧ���ѱ�ɾ����");
    	    } 
	    } 

        if(e.getSource() == quitButton) {
		    System.exit(0);
        }
		
	    if(e.getSource() == scoreButton) {
      	    String numberEntered = numberField2.getText();
    	    String courseEntered = courseField.getText();
    	    String markEntered = markField.getText();
    	    if(numberEntered.length()== 0 || courseEntered.length()== 0 || markEntered.length()== 0)
			    displayArea2.setText("����ͬʱ�����š��γ̡��ɼ���");
    	    else if(Integer.parseInt(numberEntered) < 1 || Integer.parseInt(numberEntered) > numbers)
			    displayArea2.setText("�����ѧ����Ų����趨��Χ�ڣ�");
    	    else if(list.search(Integer.parseInt(numberEntered)) == null)
			    displayArea2.setText("���Ϊ " +  numberEntered +  " ��ѧ�������ڣ�");
    	    else {
			    Score s = new Score(courseEntered, Integer.valueOf(markEntered).intValue());
			    list.search(Integer.parseInt(numberEntered)).makeScore(s);
    	    } 
	    } 

	    if(e.getSource() == listButton) {
    	    int i;
    	    String numberEntered =  numberField2.getText();
    	    if(numberEntered.length()== 0)
			    displayArea2.setText("��������ѧ����ţ�");
    	    else if(Integer.parseInt(numberEntered) < 1 || Integer.parseInt(numberEntered) > numbers)
			    displayArea2.setText("�����ѧ����Ų����趨��Χ�ڣ�");
    	    else if(list.search(Integer.parseInt(numberEntered)) == null)
			    displayArea2.setText("���Ϊ " + Integer.parseInt(numberEntered) + " ��ѧ�������ڣ�");
    	    else {
			    Student s =  list.search(Integer.parseInt(numberEntered));
			    ScoreList sl  = s.getScores();
			    if(s.getScores().getTotal() == 0)
				    displayArea2.setText("��ѧ��û�гɼ���");
			    else {  
				    displayArea2.setText("�γ�" +  "\t\t" +  "�ɼ�" +  "\n");
				    for(i =  1; i <=  sl.getTotal(); i++) 
					    displayArea2.append("" + sl.getScore(i).getCourse() +  "\t\t" + sl.getScore(i).getMark() + "\n");
				    displayArea2.append("\n" + "����Ŀǰ���пγ̵�ƽ���ɼ�Ϊ:   " + sl.calculateAverageScore());
				    courseField.setText("");
				    markField.setText("");
			    } 
		    } 
	    }
    }
}
