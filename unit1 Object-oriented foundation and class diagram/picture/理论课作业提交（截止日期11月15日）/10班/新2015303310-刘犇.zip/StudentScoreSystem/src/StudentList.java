public class StudentList extends ObjectList {
	public StudentList(int sizeIn) {
		super(sizeIn);
	}

	public Student getStudent(int positionIn) {
		if (positionIn<1 || positionIn>getTotal())
			return null;
		else
			return (Student) getItem(positionIn);
	}
	
	public Student search(int numberIn) {
		for(int i = 1;i <= getTotal();i++)
			if(getStudent(i).getNumber() == numberIn)
				return getStudent(i);
		return null; 
	}
	
	public boolean removeStudent(int numberIn) {
		for(int i = 1;i <= getTotal();i++)  
			if(getStudent(i).getNumber() == numberIn) {
				remove(i);
				return true;
			}
		return false; 
	}
}
