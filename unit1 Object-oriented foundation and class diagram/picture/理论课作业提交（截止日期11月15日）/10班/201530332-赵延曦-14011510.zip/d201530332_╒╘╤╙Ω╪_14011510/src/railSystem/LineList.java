package railSystem;

import java.util.ArrayList;

public class LineList {
	/**
	 * create an ArrayList whose name is lines
	 */
	private ArrayList<Line> lines = new ArrayList<Line>();

	/**
	 * add a line to the lines
	 * 
	 * @param line
	 */
	public void addLine(Line line) {
		lines.add(line);
	}

	/**
	 * remove a line in lines
	 * 
	 * @param line
	 */
	public void removeLine(Line line) {
		lines.remove(line);
	}

	/**
	 * find a line whose index is known
	 * 
	 * @param index
	 * @return Line
	 */
	public Line getLine(int index) {
		for (int i = 0; i < lines.size(); i++) {
			if (index == i) {
				return lines.get(i);
			}
		}
		return null;
	}

	/**
	 * find a line whose code is known
	 * 
	 * @param code
	 * @return Line
	 */
	public Line getLine(String code) {
		for (Line temp : lines) {
			if (code.equals(temp.getCode())) {
				return temp;
			}
		}
		return null;
	}

	/**
	 * get the size of the lines
	 * 
	 * @return the size of lines
	 */
	public int getNumberofLine() {
		return lines.size();
	}
}
