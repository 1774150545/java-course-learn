package railSystem;

public class Railway extends Line {
	private String code;
	private String firstTime;
	private String lateTime;
	private String totalTime;
	private StationList stationList;

	/**
	 * 
	 * @param code
	 * @param firstTime
	 * @param lateTime
	 * @param totalTime
	 * @param stationList
	 */
	public Railway(String code, String firstTime, String lateTime,
			String totalTime, StationList stationList) {
		this.code = code;
		this.firstTime = firstTime;
		this.lateTime = lateTime;
		this.totalTime = totalTime;
		this.stationList = stationList;
	}

	/**
	 * get a code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * get the firstTime
	 */
	public String getFirstTime() {
		return firstTime;
	}

	/**
	 * get the lateTime
	 */
	public String getLateTime() {
		return lateTime;
	}

	/**
	 * set the code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * set the fistTime
	 */
	public void setFirstTime(String firstTime) {
		this.firstTime = firstTime;
	}

	/**
	 * set the lateTime
	 */
	public void setLateTime(String lateTime) {
		this.lateTime = lateTime;
	}

	/**
	 * set the totalTime
	 */
	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}

	/**
	 * set the StationList
	 */
	public void setStationList(StationList stationList) {
		this.stationList = stationList;
	}

	/**
	 * get the totalTime
	 */
	public String getTotalTime() {
		return totalTime;
	}

	/**
	 * get the StationList
	 */
	public StationList getStationList() {
		return stationList;
	}

	/**
	 * toString method
	 */
	@Override
	public String toString() {
		return "Railway [code=" + code + ", firstTime=" + firstTime
				+ ", lateTime=" + lateTime + ", totalTime=" + totalTime
				+ ", stationList=" + stationList + "]";
	}

}
