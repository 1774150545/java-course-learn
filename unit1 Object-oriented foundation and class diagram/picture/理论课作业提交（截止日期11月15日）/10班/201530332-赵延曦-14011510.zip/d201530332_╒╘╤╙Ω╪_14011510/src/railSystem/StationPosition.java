package railSystem;

public class StationPosition {
	private String rode;// the road that the station locates
	private String street;// the street that the station locates

	/**
	 * create a stationPosition
	 * 
	 * @param rode
	 * @param street
	 */
	public StationPosition(String rode, String street) {
		this.rode = rode;
		this.street = street;
	}

	/**
	 * get the road
	 * 
	 * @return
	 */
	public String getRode() {
		return this.rode;
	}

	/**
	 * get the street
	 * 
	 * @return
	 */
	public String getStreet() {
		return this.street;
	}

	/**
	 * set a road
	 * 
	 * @param rode
	 */
	public void setRode(String rode) {
		this.rode = rode;
	}

	/**
	 * set a street
	 * 
	 * @param street
	 */
	public void setStreet(String street) {
		this.street = street;
	}

	/**
	 * toString method
	 */
	@Override
	public String toString() {
		return "StationPosition [rode=" + rode + ", street=" + street + "]";
	}

}
