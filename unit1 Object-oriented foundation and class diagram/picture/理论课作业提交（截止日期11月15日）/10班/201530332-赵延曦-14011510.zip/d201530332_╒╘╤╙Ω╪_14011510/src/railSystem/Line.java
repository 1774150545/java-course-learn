package railSystem;

public class Line {
	private String code;// code of a line
	private String firstTime;// firstTime of a line
	private String lateTime;// lateTime of a line
	private String totalTime;// totalTime of a line
	private StationList stationList;// stationList of a line

	/**
	 * set the code
	 * 
	 * @param code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * set the firstTime
	 * 
	 * @param firstTime
	 */
	public void setFirstTime(String firstTime) {
		this.firstTime = firstTime;
	}

	/**
	 * set the lateTime
	 * 
	 * @param lateTime
	 */
	public void setLateTime(String lateTime) {
		this.lateTime = lateTime;
	}

	/**
	 * set the totalTime
	 * 
	 * @param totalTime
	 */
	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}

	/**
	 * set the stationList
	 * 
	 * @param stationList
	 */
	public void setStationList(StationList stationList) {
		this.stationList = stationList;
	}

	/**
	 * get a code
	 * 
	 * @return a code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * get the firstTime
	 * 
	 * @return fistTime
	 */
	public String getFirstTime() {
		return firstTime;
	}

	/**
	 * get the lateTime
	 * 
	 * @return
	 */
	public String getLateTime() {
		return lateTime;
	}

	/**
	 * get the totalTime
	 * 
	 * @return
	 */
	public String getTotalTime() {
		return totalTime;
	}

	/**
	 * get the SstationList
	 * 
	 * @return
	 */
	public StationList getStationList() {
		return stationList;
	}

	/**
	 * toString method
	 */
	@Override
	public String toString() {
		return "Line [code=" + code + ", firstTime=" + firstTime
				+ ", lateTime=" + lateTime + ", totalTime=" + totalTime
				+ ", stationList=" + stationList + "]";
	}

}
