package railSystem;

public class Station {

	private String name;// name of a station
	private StationPosition statePosition;// position of a station
	private String lineCode;// the line which will stop at the this station
	private final static String NEW_LINE = System.getProperty("line.separator");

	/**
	 * create a Station
	 * 
	 * @param name
	 * @param statePosition
	 * @param code
	 */
	public Station(String name, StationPosition statePosition, String code) {
		super();
		this.name = name;
		this.statePosition = statePosition;
		this.lineCode = code;
	}

	/**
	 * return a name
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * set a name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * set position
	 * 
	 * @param statePosition
	 */
	public void setStatePosition(StationPosition statePosition) {
		this.statePosition = statePosition;
	}

	/**
	 * set line code
	 * 
	 * @param lineCode
	 */
	public void setLineCode(String lineCode) {
		this.lineCode = lineCode;
	}

	/**
	 * get a stationPosition
	 * 
	 * @return
	 */
	public StationPosition getStatePosition() {
		return statePosition;
	}

	/**
	 * toString method
	 */
	@Override
	public String toString() {
		return NEW_LINE + "Station [name=" + name + ", statePosition="
				+ statePosition.toString() + ", line=" + lineCode + "]";
	}

	/**
	 * get the line code
	 * 
	 * @return
	 */
	public String getLineCode() {
		return this.lineCode;
	}

}
