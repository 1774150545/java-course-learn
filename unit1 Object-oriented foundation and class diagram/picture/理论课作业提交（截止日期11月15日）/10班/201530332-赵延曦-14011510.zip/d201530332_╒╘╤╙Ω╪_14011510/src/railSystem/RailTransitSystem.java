package railSystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;


/**
 * @author 14011510_2015303323_������
 * 
 */
public class RailTransitSystem {
	private static BufferedReader stdIn = new BufferedReader(
			new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private CatalogStationList catalog;
	private LineList lineList;

	/**
	 * Loads data into the catalog and list and starts the application.
	 * 
	 * @param args
	 *            String arguments. Not used.
	 * @throws IOException
	 *             if there are errors in the input.
	 */
	public static void main(String[] agrs) throws IOException {
		RailTransitSystem app = new RailTransitSystem();
		app.run();
	}

	/**
	 * 
	 * @param initialCatalog
	 *            a stationList catalog
	 */
	public RailTransitSystem() {
		this.catalog = loadCatalogStationList();
		this.lineList = loadLineList(this.catalog);
	}

	/**
	 * Creates an empty catalog and then add products to it.
	 * 
	 * @return a stationList catalog
	 */
	private CatalogStationList loadCatalogStationList() {
		CatalogStationList catalog = new CatalogStationList();
		StationPosition pos1 = new StationPosition("Renmindajie", "Ziyoudalu");
		StationPosition pos2 = new StationPosition("Renmindajie", "Jiefangdalu");
		StationPosition pos3 = new StationPosition("Renmindajie",
				"Hepingdalulu");
		StationPosition pos4 = new StationPosition("Renmindajie",
				"Jilindaludalu");
		StationPosition pos5 = new StationPosition("Renmindajie", "Weiguanglu");
		StationPosition pos6 = new StationPosition("Renmindajie", "Guilinlu");
		StationPosition pos7 = new StationPosition("Renmindajie", "Weixinglu");
		StationPosition pos8 = new StationPosition("Renmindajie", "Feiyuelu");
		StationPosition pos9 = new StationPosition("Renmindajie", "Boshuolulu");
		StationPosition pos10 = new StationPosition("Xiantaidajie", "Ziyoudalu");
		StationPosition pos11 = new StationPosition("Xiantaidajie",
				"Jiefangdalu");
		StationPosition pos12 = new StationPosition("Xiantaidajie",
				"Hepingdalulu");
		StationPosition pos13 = new StationPosition("Xiantaidajie",
				"Jilindaludalu");
		StationPosition pos14 = new StationPosition("Xiantaidajie",
				"Weiguanglu");
		StationPosition pos15 = new StationPosition("Xiantaidajie", "Guilinlu");
		StationPosition pos16 = new StationPosition("Xiantaidajie", "Weixinglu");
		StationPosition pos17 = new StationPosition("Xiantaidajie", "Feiyuelu");
		StationPosition pos18 = new StationPosition("Xiantaidajie",
				"Boshuolulu");
		StationList stationlist1 = new StationList();
		StationList stationlist2 = new StationList();
		StationList stationlist3 = new StationList();
		stationlist1.addStation(new Station("S_A", pos1, "S001"));
		stationlist1.addStation(new Station("S_B", pos2, "S001"));
		stationlist1.addStation(new Station("S_C", pos3, "S001"));
		stationlist1.addStation(new Station("S_D", pos4, "S001"));
		stationlist1.addStation(new Station("S_E", pos5, "S001"));
		stationlist3.addStation(new Station("S_F", pos6, "S002"));
		stationlist3.addStation(new Station("S_G", pos7, "S002"));
		stationlist3.addStation(new Station("S_H", pos8, "S002"));
		stationlist3.addStation(new Station("S_I", pos9, "S002"));
		stationlist2.addStation(new Station("R_A", pos10, "R001"));
		stationlist2.addStation(new Station("R_B", pos11, "R001"));
		stationlist2.addStation(new Station("R_C", pos12, "R001"));
		stationlist2.addStation(new Station("R_D", pos13, "R001"));
		stationlist2.addStation(new Station("R_E", pos14, "R001"));
		stationlist2.addStation(new Station("R_F", pos15, "R001"));
		stationlist2.addStation(new Station("R_H", pos16, "R001"));
		stationlist2.addStation(new Station("R_I", pos17, "R001"));
		stationlist2.addStation(new Station("R_J", pos18, "R001"));
		catalog.addCatalogs(stationlist1);
		catalog.addCatalogs(stationlist2);
		catalog.addCatalogs(stationlist3);
		return catalog;
	}

	/**
	 * Initializes the LineList object.
	 */
	private LineList loadLineList(CatalogStationList catalog) {
		LineList List = new LineList();
		List.addLine(new Railway("R001", "6:00", "22:00", "70min", catalog
				.getSationList(1)));
		Subway subway1 = new Subway("S001", "5:30", "22:30", "45",
				catalog.getSationList(0), true);
		subway1.setAvailableOfWifi(true);
		Subway subway2 = new Subway("S002", "5:30", "22:30", "45",
				catalog.getSationList(2), false);
		subway2.setAvailableOfWifi(true);
		List.addLine(subway1);
		List.addLine(subway2);
		return List;
	}

	/**
	 * find a station
	 * 
	 * @throws IOException
	 */
	public void findastation() throws IOException {
		stdErr.println("Now you can find a station and input the name of station");
		if (false == this.catalog.findStation(stdIn.readLine())) {
			stdErr.println("there is no such station");
		}

	}

	/**
	 * display all station
	 */
	public void displayAllStation() {
		int index = 0;
		while (index < catalog.getNumberOfStationList()) {
			System.out.println(catalog.getSationList(index).toString());
			index++;
		}
	}

	/**
	 * display all line
	 */
	public void displayAllLine() {
		int index = 0;

		while (index < lineList.getNumberofLine()) {
			stdOut.println(lineList.getLine(index).toString());
			index++;
		}

	}

	/**
	 * find a line
	 * 
	 * @throws IOException
	 */
	public void findLine() throws IOException {
		stdErr.println("Now you can find a line and input line code");
		String code = stdIn.readLine();
		int i = 0;
		for (i = 0; i < lineList.getNumberofLine(); i++) {
			if (code.equals(lineList.getLine(i).getCode())) {
				stdOut.println(lineList.getLine(i).toString());
				i = 0;
				break;
			}
		}
		if (i != 0) {
			stdOut.println("there is no such line");
		}
	}

	/**
	 * Presents the user with a menu of options and executes the selected task.
	 * Displays a menu of options and verifies the user's choice.
	 */
	public void run() throws IOException {
		do {
			stdErr.println("[0] find station");
			stdErr.println("[1] find line");
			stdErr.println("[2] display all stationlist");
			stdErr.println("[3] display all stationlist");
			stdErr.println("[4] end the programme");
			stdErr.flush();
			String option = stdIn.readLine();
			if (option.equals("1")) {

				findLine();
			}
			if (option.equals("0")) {
				findastation();
			}
			if (option.equals("2")) {
				displayAllStation();
			}
			if (option.equals("3")) {
				displayAllLine();
			}
			if (option.equals("4")) {
				break;
			}

		} while (true);
		stdErr.println("the programme has been ended");
	}
}
