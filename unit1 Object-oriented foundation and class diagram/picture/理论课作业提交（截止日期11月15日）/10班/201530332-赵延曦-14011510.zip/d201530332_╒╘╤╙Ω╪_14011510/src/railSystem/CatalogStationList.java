package railSystem;

import java.util.ArrayList;

public class CatalogStationList {
	/**
	 * create an ArrayList whose name is catalogs
	 */
	private ArrayList<StationList> catalogs = new ArrayList<StationList>();

	/**
	 * add stationList to the catalogs
	 * 
	 * @param stationList
	 */
	public void addCatalogs(StationList stationList) {
		catalogs.add(stationList);
	}

	/**
	 * 
	 * @param index
	 * @return a StaitonList
	 */
	public StationList getSationList(int index) {
		return catalogs.get(index);
	}

	/**
	 * remove a stationList
	 * 
	 * @param list
	 */
	public void removeStationList(StationList list) {
		catalogs.remove(list);
	}

	/**
	 * 
	 * @return the size of catalogs
	 */
	public int getNumberOfStationList() {
		return catalogs.size();
	}

	/**
	 * find whether the station in the stationList
	 * 
	 * @param src
	 * @return the result
	 */
	public boolean findStation(String src) {
		for (int i = 0; i < catalogs.size(); i++) {
			for (int j = 0; j < catalogs.get(i).getNumberOfStations(); j++) {

				if (src.equals(catalogs.get(i).getStation(j).getName())) {

					StationList list = catalogs.get(i);
					System.out.println(list.getStation(j).toString());
					return true;
				}

			}
		}
		return false;
	}
}
