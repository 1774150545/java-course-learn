package railSystem;

public class Subway extends Line {
	private final static String NEW_LINE = System.getProperty("line.separator");
	private String code;
	private String firstTime;
	private String lateTime;
	private String totalTime;
	private StationList stationList;
	private boolean newCoachAvailablity;
	private boolean wifiAvailability;

	/**
	 * 
	 * @param code
	 * @param firstTime
	 * @param lateTime
	 * @param totalTime
	 * @param stationList
	 * @param coach
	 */
	public Subway(String code, String firstTime, String lateTime,
			String totalTime, StationList stationList, boolean coach) {
		this.code = code;
		this.firstTime = firstTime;
		this.lateTime = lateTime;
		this.totalTime = totalTime;
		this.stationList = stationList;
		this.newCoachAvailablity = coach;
	}

	/**
	 * set the code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * set the firstTime
	 */
	public void setFirstTime(String firstTime) {
		this.firstTime = firstTime;
	}

	/**
	 * set the lateTime
	 */
	public void setLateTime(String lateTime) {
		this.lateTime = lateTime;
	}

	/**
	 * set the totalTime
	 */
	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}

	/**
	 * set the StationList
	 */
	public void setStationList(StationList stationList) {
		this.stationList = stationList;
	}

	/**
	 * set the newCoachAvailablity
	 * 
	 * @param newCoachAvailablity
	 */
	public void setNewCoachAvailablity(boolean newCoachAvailablity) {
		this.newCoachAvailablity = newCoachAvailablity;
	}

	/**
	 * get the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * get the firstTime
	 */
	public String getFirstTime() {
		return firstTime;
	}

	/**
	 * get the lateTime
	 */
	public String getLateTime() {
		return lateTime;
	}

	/**
	 * get the totalTime
	 */
	public String getTotalTime() {
		return totalTime;
	}

	/**
	 * get the stationList
	 */
	public StationList getStationList() {
		return stationList;
	}

	/**
	 * is available of new coach
	 * 
	 * @param value
	 * @return
	 */
	public boolean isAvailableOfNewCoach(boolean value) {
		return this.newCoachAvailablity;
	}

	/**
	 * set WiFi service information
	 * 
	 * @param value
	 */
	public void setAvailableOfWifi(boolean value) {
		this.wifiAvailability = value;
	}

	/**
	 * toString method
	 */
	@Override
	public String toString() {
		return "Subway [code=" + code + ", firstTime=" + firstTime
				+ ", lateTime=" + lateTime + ", totalTime=" + totalTime
				+ NEW_LINE + "stationList=" + stationList + "," + NEW_LINE
				+ "newCoachAvailablity=" + newCoachAvailablity
				+ ", wifiAvailability=" + wifiAvailability + "]";
	}

}
