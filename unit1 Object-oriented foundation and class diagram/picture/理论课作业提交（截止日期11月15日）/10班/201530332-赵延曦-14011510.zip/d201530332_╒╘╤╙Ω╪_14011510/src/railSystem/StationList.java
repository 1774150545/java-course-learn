package railSystem;

import java.util.ArrayList;

public class StationList {
	/**
	 * create a ArrayList whose name is stations
	 */
	private ArrayList<Station> stations = new ArrayList<Station>();

	/**
	 * add a station in the stations
	 * 
	 * @param station
	 */
	public void addStation(Station station) {
		stations.add(station);
	}

	/**
	 * remove a station from stations
	 * 
	 * @param station
	 */
	public void removeStationOnline(Station station) {
		stations.remove(station);
	}

	/**
	 * get the size of stations
	 * 
	 * @return the size of stations
	 */
	public int getNumberOfStations() {
		return stations.size();
	}

	/**
	 * find a station whose index is known
	 * 
	 * @param index
	 * @return station
	 */
	public Station getStation(int index) {
		for (int i = 0; i < stations.size(); i++) {
			if (index == i) {
				return stations.get(i);
			}
		}
		return null;
	}

	/**
	 * find a station whose name is known
	 * 
	 * @param name
	 * @return station
	 */
	public Station getStation(String name) {
		for (Station temp : stations) {
			if (name.equals(temp.getName())) {
				return temp;
			}
		}
		return null;
	}

	@Override
	/**
	 * toStrig method
	 */
	public String toString() {
		return "StationList [stations=" + stations + "]";
	}

}
