
public class person {
private String name;
private int age;

String getname (){
	return name;
}
int getage (){
	return age;
}
}
