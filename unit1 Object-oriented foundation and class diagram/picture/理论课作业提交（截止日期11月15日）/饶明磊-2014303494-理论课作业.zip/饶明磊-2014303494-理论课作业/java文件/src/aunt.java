
public class aunt extends person{
	private String name;
	private int age;
	private String gender;

	String getname (){
		return name;
	}
	int getage (){
		return age;
	}
	String gender(){
		return gender;
	}
}
