/**
 * 
 */
/**
 * 含有所有marklang语法树的节点类
 * 
 * @author Liu233w
 *
 */
package liu233w.marklang.marklangnode;