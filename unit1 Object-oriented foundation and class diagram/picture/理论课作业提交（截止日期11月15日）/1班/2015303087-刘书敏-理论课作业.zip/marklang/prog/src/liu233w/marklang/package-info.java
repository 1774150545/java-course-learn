/**
 */
/**
 * marklang 是一门类似于 markdown 的标记语言。 包中提供了用于此语言的语法解析与代码转换工具 详情请参考每个类具体的注释
 * 
 * @author Liu233w
 *
 */
package liu233w.marklang;