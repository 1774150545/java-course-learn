package lilun;

public class KeCheng {
	private String name;
	private String code;

	private LaoShi renkelaoshi;
	private ShangKeJiaoShi jiaoshi;

	public KeCheng(String code, String name, LaoShi laoshi, ShangKeJiaoShi jiaoshi) {
		this.name = name;
		this.code = code;

		this.renkelaoshi = laoshi;
		this.jiaoshi = jiaoshi;
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

	public LaoShi getRenkelaoshi() {
		return renkelaoshi;
	}

	public ShangKeJiaoShi getJiaoshi() {
		return jiaoshi;
	}

	public String toString() {
		return "KeCheng [name=" + name + ", code=" + code + ", renkelaoshi=" + renkelaoshi.toString()
				+ jiaoshi.toString() + "]";
	}

	public boolean equals(KeCheng kecheng) {
		if (kecheng.getCode().equals(code))
			return true;
		else
			return false;
	}

}
