package lilun;

public class ShangKeJiaoShi extends JiaoShi {
	private int rongliang;
	private boolean zhuangtai;

	public ShangKeJiaoShi(String code, int rongliang, boolean zhuangtai) {
		super(code);
		this.rongliang = rongliang;
		this.zhuangtai = zhuangtai;

	}

	public int getRongliang() {
		return rongliang;
	}

	public boolean isZhuangtai() {
		return zhuangtai;
	}

	public String toString() {
		return "ShangKeJiaoShi [" + "code=" + this.getCode() + ", rongliang=" + rongliang + ", zhuangtai=" + zhuangtai
				+ "]";
	}

}
