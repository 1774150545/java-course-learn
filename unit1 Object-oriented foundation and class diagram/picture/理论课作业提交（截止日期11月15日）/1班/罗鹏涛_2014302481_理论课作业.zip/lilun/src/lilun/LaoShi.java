package lilun;

import java.util.*;

public class LaoShi {
	private String name;
	private String code;
	private String sex;
	private String level;
	private double salary;
	private ArrayList<KeCheng> kecheng = new ArrayList<KeCheng>();

	public LaoShi(String code, String name, String sex, String level, double salary) {
		this.code = code;
		this.name = name;
		this.sex = sex;
		this.level = level;
		this.salary = salary;
	}

	public boolean addKeCheng(KeCheng kecheng) {
		if (this.kecheng.add(kecheng))
			return true;
		else
			return false;
	}

	public boolean removeKeCheng(KeCheng kecheng) {
		if (this.kecheng.remove(kecheng)) {
			return true;
		} else
			return false;
	}

	public int getNumOfKeCheng() {
		return this.kecheng.size();
	}

	public KeCheng getKeCheng(String code) {
		int size = this.kecheng.size();
		for (int i = 0; i < size; i++) {
			if (this.kecheng.get(i).getCode().equals(code))
				return this.kecheng.get(i);
		}
		return null;
	}

	public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getSex() {
		return sex;
	}

	public String getLevel() {
		return level;
	}

	public double getSalary() {
		return salary;
	}

	public String toString() {
		return "LaoShi [name=" + name + ", sex=" + sex + ", level=" + level + ", salary=" + salary + "]";
	}

	public boolean equals(LaoShi laoshi) {
		if (laoshi.getCode().equals(code))
			return true;
		else
			return false;
	}
}
