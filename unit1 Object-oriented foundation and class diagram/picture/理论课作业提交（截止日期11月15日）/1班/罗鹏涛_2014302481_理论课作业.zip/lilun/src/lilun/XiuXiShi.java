package lilun;

public class XiuXiShi extends JiaoShi {
	private boolean zhuangtai;

	public XiuXiShi(String code, boolean zhaungtai) {
		super(code);
		this.zhuangtai = zhaungtai;
	}

	public String toString() {
		return "XiuXiShi [Code=" + getCode() + ", zhuangtai=" + zhuangtai + "]";
	}

}
