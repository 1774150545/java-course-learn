package lilun;

import java.util.*;

public class KeChengLieBiao {
	private ArrayList<KeCheng> kechengs = new ArrayList<KeCheng>();

	public boolean addKeCheng(KeCheng kecheng) {
		if (kechengs.add(kecheng))
			return true;
		else
			return false;
	}

	public boolean removeKeCheng(KeCheng kecheng) {
		if (kechengs.remove(kecheng))
			return true;
		else
			return false;
	}

	public int getNumOfKengCheng() {
		return kechengs.size();
	}

	public KeCheng getKeCheng(String code) {
		int size = kechengs.size();
		for (int i = 0; i < size; i++) {
			if (kechengs.get(i).getCode().equals(code))
				return kechengs.get(i);
		}
		return null;
	}

	public KeCheng getKengCheng(int i) {
		return kechengs.get(i);
	}
}
