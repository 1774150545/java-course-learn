package lilun;

import java.util.*;

public class LaoShiLieBiao {
	private ArrayList<LaoShi> laoshis = new ArrayList<LaoShi>();

	public boolean addLaoShi(LaoShi laoshi) {
		if (laoshis.add(laoshi))
			return true;
		else
			return false;
	}

	public boolean removeLaoShi(LaoShi laoshi) {
		if (laoshis.remove(laoshi))
			return true;
		else
			return false;
	}

	public int getNumOflaoShi() {
		return laoshis.size();
	}

	public LaoShi getLaoShi(String code) {
		int size = laoshis.size();
		for (int i = 0; i < size; i++) {
			if (laoshis.get(i).getCode().equals(code))
				return laoshis.get(i);
		}
		return null;
	}

	public LaoShi getLaoShi(int i) {
		return laoshis.get(i);
	}

}
