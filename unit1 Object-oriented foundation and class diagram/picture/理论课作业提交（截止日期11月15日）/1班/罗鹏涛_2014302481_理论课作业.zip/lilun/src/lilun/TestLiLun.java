package lilun;

import java.io.*;

public class TestLiLun {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private JiaoShiLieBiao jiaoshiliebiao;
	private KeChengLieBiao kechengliebiao;
	private LaoShiLieBiao laoshiliebiao;

	private TestLiLun() {

	}

	private void load() {
		this.jiaoshiliebiao = new JiaoShiLieBiao();
		this.kechengliebiao = new KeChengLieBiao();
		this.laoshiliebiao = new LaoShiLieBiao();
		LaoShi laoshi1 = new LaoShi("T001", "machunyan", "nv", "A", 10000);
		LaoShi laoshi2 = new LaoShi("T002", "liyong", "nan", "A", 10000);
		LaoShi laoshi3 = new LaoShi("T003", "wangyan", "nv", "B", 8000);
		LaoShi laoshi4 = new LaoShi("T004", "zhaolei", "nan", "B", 9000);
		XiuXiShi xiuxishi1 = new XiuXiShi("C002", true);
		XiuXiShi xiuxishi2 = new XiuXiShi("C010", true);
		ShangKeJiaoShi jiaoshi1 = new ShangKeJiaoShi("C001", 180, false);
		ShangKeJiaoShi jiaoshi2 = new ShangKeJiaoShi("C003", 150, false);
		ShangKeJiaoShi jiaoshi3 = new ShangKeJiaoShi("C004", 120, false);
		ShangKeJiaoShi jiaoshi4 = new ShangKeJiaoShi("C005", 100, false);
		ShangKeJiaoShi jiaoshi5 = new ShangKeJiaoShi("C006", 80, false);
		ShangKeJiaoShi jiaoshi6 = new ShangKeJiaoShi("C007", 60, false);
		ShangKeJiaoShi jiaoshi7 = new ShangKeJiaoShi("C008", 180, true);
		ShangKeJiaoShi jiaoshi8 = new ShangKeJiaoShi("C009", 100, true);
		KeCheng kecheng1 = new KeCheng("K001", "mianxiangduixiang", laoshi1, jiaoshi1);
		KeCheng kecheng2 = new KeCheng("K002", "mianxiangduixiangshiyan", laoshi2, jiaoshi3);
		KeCheng kecheng3 = new KeCheng("K003", "zhuanyeke1", laoshi3, jiaoshi4);
		KeCheng kecheng4 = new KeCheng("K004", "zhuanyeke2", laoshi4, jiaoshi2);
		KeCheng kecheng5 = new KeCheng("K005", "zhuanyeke3", laoshi1, jiaoshi5);
		KeCheng kecheng6 = new KeCheng("K006", "zhuanyeke4", laoshi2, jiaoshi6);
		laoshi1.addKeCheng(kecheng1);
		laoshi1.addKeCheng(kecheng5);
		laoshi2.addKeCheng(kecheng2);
		laoshi3.addKeCheng(kecheng3);
		laoshi4.addKeCheng(kecheng4);
		laoshi2.addKeCheng(kecheng6);
		jiaoshiliebiao.addJiaoShi(xiuxishi1);
		jiaoshiliebiao.addJiaoShi(xiuxishi2);
		jiaoshiliebiao.addJiaoShi(jiaoshi1);
		jiaoshiliebiao.addJiaoShi(jiaoshi2);
		jiaoshiliebiao.addJiaoShi(jiaoshi3);
		jiaoshiliebiao.addJiaoShi(jiaoshi4);
		jiaoshiliebiao.addJiaoShi(jiaoshi5);
		jiaoshiliebiao.addJiaoShi(jiaoshi6);
		jiaoshiliebiao.addJiaoShi(jiaoshi7);
		jiaoshiliebiao.addJiaoShi(jiaoshi8);
		laoshiliebiao.addLaoShi(laoshi1);
		laoshiliebiao.addLaoShi(laoshi2);
		laoshiliebiao.addLaoShi(laoshi3);
		laoshiliebiao.addLaoShi(laoshi4);
		kechengliebiao.addKeCheng(kecheng1);
		kechengliebiao.addKeCheng(kecheng2);
		kechengliebiao.addKeCheng(kecheng3);
		kechengliebiao.addKeCheng(kecheng4);
		kechengliebiao.addKeCheng(kecheng5);
		kechengliebiao.addKeCheng(kecheng6);
	}

	private void dispayjiaoshiliebiao() {
		int size = jiaoshiliebiao.getNumOfJiaoShi();
		if (size == 0)
			stdOut.println("the jiaoshiliebiao wei kong");
		else {
			for (int i = 0; i < size; i++) {
				stdOut.println(jiaoshiliebiao.getJiaoShi(i).toString());
			}
		}
		stdOut.flush();
	}

	private void displaylaoshiliebiao() {
		int size = laoshiliebiao.getNumOflaoShi();
		if (size == 0)
			stdOut.println("the laoshiliebiao wei kong");
		else {
			for (int i = 0; i < size; i++) {
				stdOut.println(laoshiliebiao.getLaoShi(i).toString());
			}
		}
		stdOut.flush();
	}

	private void displaykechengliebiao() {

		int size = kechengliebiao.getNumOfKengCheng();
		if (size == 0)
			stdOut.println("the kechengliebiao wei kong");
		else {
			for (int i = 0; i < size; i++) {
				stdOut.println(kechengliebiao.getKengCheng(i).toString());
			}
		}
		stdOut.flush();

	}

	public void displaylaoshi() throws IOException {
		String code = stdIn.readLine();

		stdOut.println(laoshiliebiao.getLaoShi(code));
		stdOut.flush();
	}

	public void displaykecheng() throws IOException {
		String code = stdIn.readLine();

		stdOut.println(kechengliebiao.getKeCheng(code));
		stdOut.flush();
	}

	public void displayjiaoshi() throws IOException {
		String code = stdIn.readLine();

		stdOut.println(jiaoshiliebiao.getJiaoShi(code));
		stdOut.flush();
	}

	public void run() throws IOException {
		int choice = getChoice();
		while (choice != 0) {
			if (choice == 1) {
				displaylaoshiliebiao();
			} else if (choice == 2) {
				displaykechengliebiao();
			} else if (choice == 3) {
				dispayjiaoshiliebiao();
			} else if (choice == 4) {
				displayjiaoshi();
			} else if (choice == 5) {
				displaykecheng();
			} else if (choice == 6) {
				displaylaoshi();
			}

			choice = getChoice();

		}
	}

	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdOut.println();
				stdOut.print("[0]  Quit\n" + "[1]  Display LaoShiLieBiao\n" + "[2]  Display KeChengLieBiao\n"
						+ "[3]  Display JiaoShiLieBiao\n" + "[4]  Display JiaoShi\n" + "[5]  Display KeCheng\n"
						+ "[6]  Display LaoShi\n" + "choice> ");
				stdOut.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdOut.println();

				if (0 <= input && 6 >= input) {
					break;
				} else {
					stdOut.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdOut.println(nfe);
			}
		} while (true);

		return input;
	}

	public static void main(String[] args) throws IOException {

		TestLiLun testlilun = new TestLiLun();
		testlilun.load();
		testlilun.run();
	}

}
