package lilun;

import java.util.*;

public class JiaoShiLieBiao {
	private ArrayList<JiaoShi> jiaoshis = new ArrayList<JiaoShi>();

	public boolean addJiaoShi(JiaoShi jiaoshi) {
		if (jiaoshis.add(jiaoshi))

			return true;
		else
			return false;
	}

	public boolean removeJiaoShi(JiaoShi jiaoshi) {
		if (jiaoshis.remove(jiaoshi))
			return true;
		else
			return false;
	}

	public JiaoShi getJiaoShi(String code) {
		int size = jiaoshis.size();
		for (int i = 0; i < size; i++) {
			if (jiaoshis.get(i).getCode().equals(code))
				return jiaoshis.get(i);
		}
		return null;
	}

	public JiaoShi getJiaoShi(int i) {
		return jiaoshis.get(i);
	}

	public int getNumOfJiaoShi() {
		return jiaoshis.size();
	}

}
