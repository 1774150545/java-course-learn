package lilun;

public class JiaoShi {
	private String code;

	public JiaoShi(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public String toString() {
		return "code" + this.getCode();
	}

	public boolean equals(JiaoShi jiaoshi) {
		if (jiaoshi.getCode().equals(code))
			return true;
		else
			return false;
	}
}
