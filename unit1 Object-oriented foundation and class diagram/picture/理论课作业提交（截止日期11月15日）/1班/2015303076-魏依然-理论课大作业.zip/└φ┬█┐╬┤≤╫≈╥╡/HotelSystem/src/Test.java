
public class Test {

	public static void main(String[] args) {
	        Hotel hotel1 = new Hotel();
	        HotelSystem manager = new HotelSystem(hotel1);
	        manager.printMenu();
	}

}
