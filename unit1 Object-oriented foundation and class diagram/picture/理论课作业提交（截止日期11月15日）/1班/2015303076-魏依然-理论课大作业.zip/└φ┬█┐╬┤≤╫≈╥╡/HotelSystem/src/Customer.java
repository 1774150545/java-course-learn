/**
 * 
 */

/**
 * @author DVD
 *
 */
public class Customer {

	private String name;
	
	protected double price;
	
	/**
	 * 
	 */
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setPrice(double price) {
		this.price = price;
	}	
	
	public double getPrice() {
		return price;
	}


}
