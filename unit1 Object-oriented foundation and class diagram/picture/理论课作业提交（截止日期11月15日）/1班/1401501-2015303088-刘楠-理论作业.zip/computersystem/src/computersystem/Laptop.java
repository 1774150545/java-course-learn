package computersystem;


/**
 * This class models a domestic tourism product. It extends 
 * {@link TourismProduct}.
 * @author Ning Yibo
 * @version  1.0.0
 * @see  TourismProduct
 */
public class Laptop extends ProductsCatalog {
	
	private String modelofmouse;
	/**
	 * Constructs a <code>CruiseTourism</code> object.
	 * <p>
	 * The collection of the tourism products is initially empty.
	 * <p>
	 *
	 * @param initialCode  the code of the product.
	 * @param initialTitle  the title of the product.
	 * @param initialDeparture  the departure of the product.
	 * @param initialDestination  the destination of the product.
	 * @param initialRoute  the route of the product.
	 * @param initialSellingPrice the selling price of the product.
	 * @param initialAgencyName  the agency name of the product.
	 */
	public Laptop(String initialBrand, String initialModel,
			String initialSize, String initialColour,String intitialModelofmouse) {
		
		super(initialBrand,initialModel,initialSize,initialColour);
		this.modelofmouse=intitialModelofmouse;
	}
	/**
	 * Returns the cruise company this product is from.
	 *
	 * @return  the cruise company this product is from.
	 */
	public String getModelofmouse() {

		return this.modelofmouse;
	}
	
	/**
	 * Returns the string representation of this tourism product.
	 *
	 * @return  the string representation of this tourism product.
	 */
public String toString(){
		
		return "Tourism["+getBrand()+","+getModel()+","+getSize()+","+getColour()+","+getModelofmouse()+"]";
	}
}
/*!End Snippet:file*/