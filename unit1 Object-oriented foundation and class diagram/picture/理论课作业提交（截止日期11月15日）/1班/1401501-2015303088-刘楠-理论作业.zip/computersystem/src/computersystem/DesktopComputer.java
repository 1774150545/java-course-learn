package computersystem;


/**
 * This class models a domestic computer product. It extends 
 * {@link TourismProduct}.
 * @author ���
 * @version  1.0.0
 * @see  TourismProduct
 */
public class DesktopComputer extends ProductsCatalog {
	
	private String modelofmouse;
	private String modelofkeyboard;
	private String modelofhost;
	/**
	 * Constructs a <code>CruiseTourism</code> object.
	 * <p>
	 * The collection of the computer products is initially empty.
	 * <p>
	 *
	 * @param initialCode  the code of the product.
	 * @param initialTitle  the title of the product.
	 * @param initialDeparture  the departure of the product.
	 * @param initialDestination  the destination of the product.
	 * @param initialRoute  the route of the product.
	 * @param initialSellingPrice the selling price of the product.
	 * @param initialAgencyName  the agency name of the product.
	 */
	public DesktopComputer(String initialBrand, String initialModel,
			String initialSize, String initialColour,String intitialModelofmouse,
			String intitialModelofkeyboard,String intitialModelofhost) {
		
		super(initialBrand,initialModel,initialSize,initialColour);
		this.modelofmouse=intitialModelofmouse;
		this.modelofmouse=intitialModelofkeyboard;
		this.modelofmouse=intitialModelofhost;
	}
	
	public String getModelofmouse() {

		return this.modelofmouse;
	}
	
	public String getModelofkeyboard() {

		return this.modelofkeyboard;
	}
	
	public String getModelofhost() {

		return this.modelofhost;
	}
	
	
	/**
	 * Returns the string representation of this computer product.
	 *
	 * @return  the string representation of this computer product.
	 */
public String toString(){
		
		return "Tourism["+getBrand()+","+getModel()+","+getSize()+","+getColour()+
				","+getModelofmouse()+","+getModelofkeyboard()+","+getModelofhost()+"]";
	}
}
/*!End Snippet:file*/