package computersystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * This class implements a computer Information System.
 *
 * @author ���
 * @version 1.1.0
 */
public class ComputerSystem  {

	private static BufferedReader  stdIn =
		new  BufferedReader(new  InputStreamReader(System.in));
	private static PrintWriter  stdOut =
		new  PrintWriter(System.out, true);
	private static PrintWriter  stdErr =
		new  PrintWriter(System.err, true);

	private static final NumberFormat CURRENCY =
		NumberFormat.getCurrencyInstance();

	private ProductsCatalog productsCatalog;
	

	/**
	 * Loads data into the catalog and starts the application.
	 *
	 * @param args  String arguments.  Not used.
	 * @throws IOException if there are errors in the input.
	 */
	public static void  main(String[] args) throws IOException, NullPointerException  {

		ComputerSystem  application = new ComputerSystem();
		application.run();

	


	