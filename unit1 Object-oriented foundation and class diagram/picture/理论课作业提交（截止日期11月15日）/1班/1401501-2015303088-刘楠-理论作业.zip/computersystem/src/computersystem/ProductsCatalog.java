package computersystem;
import java.util.ArrayList;
/**
 * Maintains a collection of {@link computerProduct}.
 * 
 * @author ���
 * @version 1.0.0
 * @see TourismProduct
 */
public class ProductsCatalog {
	
	/* Collection of <code>TourismProduct</code> objects.*/
    private ArrayList<ComputerProduct> productList;
	private String brand;
	private String model;
	private String size;
	private String colour;
    
    /**
	 * Sets the collection of {@link computerProduct} to empty.
	 */
    public ProductsCatalog() {
    	
    	this.productList = new ArrayList<ComputerProduct>();
    }
    
    /**
	 * Returns the product list of this products catalog.
	 *
	 * @return  the product list of this products catalog.
	 */
    public ArrayList<ComputerProduct> getProductList() {
    	
    	return productList;
    }
    
    /**
	 * Adds a {@link TourismProduct} object to this collection and
	 * sets the {@link TourismProduct} object as not available.
	 *
	 * @param computerProduct  the {@link computerProduct} object.
	 */
    public boolean addProduct(ComputerProduct product) {
    	
    	return (productList.add(product)? true : false);
    }
    
    /**
	 * Returns the {@link computerProduct} object with the specified
	 * <code>code</code>.
	 *
	 * @param code  the code of an product.
	 * @return  The {@link computerProduct} object with the specified
	 *          code. Returns <code>null</code> if the object with
	 *          the code is not found.
	 */
    public ComputerProduct findProductByCode(String brand) {
    	
    	for (ComputerProduct tourismProduct : this.productList) {
			if (tourismProduct.getBrand().equals(brand)) {

				return tourismProduct;
			}
		}

		return null;
    }
    
    /**
	 * Returns the {@link computerProduct} object with the specified
	 * <departure>departure</departure> and <destination>destination</destination>.
	 *
	 * @param departure  the departure of an product
	 *        destination  the destination of an product.
	 * @return The {@link computerProduct} object with the specified
	 *         departure and destination. Returns null if the object 
	 *         with the departure and destination is not found.
	 */
    public ComputerProduct findProduct(String departure, String model) {
    	
    	for (ComputerProduct tourismProduct : this.productList) {
    		if (tourismProduct.getModel().equals(model) && tourismProduct.getModel().equals(model)) {
    			
    			return tourismProduct;
    		}
    	}
    	
    	return null;
    }
/*!End Snippet:file*/
	/**
	 * Constructs a <code>computerProduct</code> object.
	 * <p>
	 * The collection of the computer products is initially empty.
	 * <p>
	 *
	 * @param initialCode  the code of the product.
	 * @param initialTitle  the title of the product.
	 * @param initialDeparture  the departure of the product.
	 * @param initialDestination  the destination of the product.
	 * @param initialRoute  the route of the product.
	 * @param initialSellingPrice the selling price of the product.
	 * @param initialAgencyName  the agency name of the product.
	 */
	public ProductsCatalog(String initialBrand, String initialModel,
			String initialSize, String initialColour) {

		this.brand = initialBrand;
		this.model = initialModel;
		this.size = initialSize;
		this.colour = initialColour;
	}
	
	/**
	 * Returns the brand of this product.
	 *
	 * @return  the brand of this product.
	 */
	public String getBrand() {

		return this.brand;
	}
	
	/**
	 * Returns the model of this product.
	 *
	 * @return  the model of this product.
	 */
	public String getModel() {

		return this.model;
	}
	
	/**
	 * Returns the size of this product.
	 *
	 * @return  the size of this product.
	 */
	public String getSize() {

		return this.size;
	}
	
	/**
	 * Returns the colour of this product.
	 *
	 * @return  the colour of this product.
	 */
	public String getColour() {

		return this.colour;
	}
	
	
	
	/**
	 * Sets the value of instance variable <code>code</code>.
	 *
	 * @param brand  the new value.
	 */
	public void setBrand(String brand) {
		
		this.brand = brand;
	}
	
	/**
	 * Sets the model  of instance variable <code>title</code>.
	 *
	 * @param model   the new value.
	 */
    public void setModel(String model) {
		
		this.model = model;
	}
    
    /**
	 * Sets the size of instance variable <code>departure</code>.
	 *
	 * @param size  the new value.
	 */
    public void setSize(String size) {
		
		this.size = size;
	}
    
    /**
	 * Sets the value of instance variable <code>destination</code>.
	 *
	 * @param colour  the new value.
	 */
    public void setColour(String colour) {
		
		this.colour = colour;
	}
    
    
	public boolean equals(Object object){
		
		return object instanceof ProductsCatalog
	       && getBrand().equals(((ProductsCatalog) object).getBrand())
		   && getModel()==(((ProductsCatalog) object).getModel());
	}
	
	/**
	 * Returns the string representation of this computer product.
	 *
	 * @return  the string representation of this computer product.
	 */
	public String toString(){
		
		return "Tourism["+getBrand()+","+getModel()+","+getSize()+","+getColour()+"]";
	}
}
