package computersystem;

/**
 * This class models a computer product. It contains the following
 * information:
 * </p>
 * <ol>
 * <li>the code of the product, a <code>String</code></li>
 * <li>the title of the product, a <code>String</code></li>
 * <li>the departure of the product, a <code>String</code></li>
 * <li>the destination of the product, a <code>String</code></li>
 * <li>the route of the product, a<code>TouristRoute</code></li>
 * <li>the selling price of the product, a<code>double</code></li>
 * <li>the agency name of the produt, a<code>String</code></li>
 * </ol>
 *
 * @author ���
 * @version  1.0.0

 */

public class ComputerProduct {
	
	/* brandof the product. */
	private String brand;
	
	/* model of the product. */
	private String model;
	
	/* size of the product. */
	private String size;
	
	/* colour of the product. */
	private String colour;
	
	
    
	/**
	 * Constructs a <code>TourismProduct</code> object.
	 * <p>
	 * The collection of the computer products is initially empty.
	 * <p>
	 *
	 * @param initialCode  the code of the product.
	 * @param initialTitle  the title of the product.
	 * @param initialDeparture  the departure of the product.
	 * @param initialDestination  the destination of the product.
	 * @param initialRoute  the route of the product.
	 * @param initialSellingPrice the selling price of the product.
	 * @param initialAgencyName  the agency name of the product.
	 */
	public ComputerProduct(String initialBrand, String initialModel,
			String initialSize, String initialColour) {

		this.brand = initialBrand;
		this.model = initialModel;
		this.size = initialSize;
		this.colour = initialColour;
	}
	
	/**
	 * Returns the brand of this product.
	 *
	 * @return  the brand of this product.
	 */
	public String getBrand() {

		return this.brand;
	}
	
	/**
	 * Returns the model of this product.
	 *
	 * @return  the model of this product.
	 */
	public String getModel() {

		return this.model;
	}
	
	/**
	 * Returns the size of this product.
	 *
	 * @return  the size of this product.
	 */
	public String getSize() {

		return this.size;
	}
	
	/**
	 * Returns the colour of this product.
	 *
	 * @return  the colour of this product.
	 */
	public String getColour() {

		return this.colour;
	}
	
	
	
	/**
	 * Sets the value of instance variable <code>code</code>.
	 *
	 * @param brand  the new value.
	 */
	public void setBrand(String brand) {
		
		this.brand = brand;
	}
	
	/**
	 * Sets the model  of instance variable <code>title</code>.
	 *
	 * @param model   the new value.
	 */
    public void setModel(String model) {
		
		this.model = model;
	}
    
    /**
	 * Sets the size of instance variable <code>departure</code>.
	 *
	 * @param size  the new value.
	 */
    public void setSize(String size) {
		
		this.size = size;
	}
    
    /**
	 * Sets the value of instance variable <code>destination</code>.
	 *
	 * @param colour  the new value.
	 */
    public void setColour(String colour) {
		
		this.colour = colour;
	}
    
    
	public boolean equals(Object object){
		
		return object instanceof ComputerProduct
	       && getBrand().equals(((ComputerProduct) object).getBrand())
		   && getModel()==(((ComputerProduct) object).getModel());
	}
	
	/**
	 * Returns the string representation of this tourism product.
	 *
	 * @return  the string representation of this tourism product.
	 */
	public String toString(){
		
		return "Tourism["+getBrand()+","+getModel()+","+getSize()+","+getColour()+"]";
	}
}

