package vendingmachine;

/**
 * 
 * 
 * @author wangchen
 * @version 1.1.0
 * 
 */
public class Food extends CatalogItem {
	private String type;

	/**
	 * ���췽��
	 * 
	 * @param name
	 * @param brand
	 * @param price
	 * @param type
	 */
	public Food(String name, String brand, double price, String type) {
		super(name, brand, price);
		this.type = type;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Food [" + super.toString() + ", type=" + type + "]";
	}

	/**
	 * 
	 * @param
	 * @return the type
	 */
	public String getType() {
		return type;
	}
}
