/**
 * 
 */
package vendingmachine;

/**
 * @author wangchen
 * @version 1.1.0
 */
public class SalesItem {
	private String info;

	/**
	 * @param info
	 */
	public SalesItem(String info) {
		super();
		this.info = info;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SalesItem [����" + info + "]";
	}

}
