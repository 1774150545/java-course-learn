package vendingmachine;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * @author wangchen
 * @version 1.1.0
 * @see RechargeCardCatalog
 * @see Catalog
 * @see TextSales
 * @see Sales
 * @see CatalogItem
 * @see RechargeCardItem
 */
public class VendingMachineSystem {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private RechargeCardCatalog recatalog = new RechargeCardCatalog();
	private Catalog catalog = new Catalog();
	private TextSales textsale = new TextSales();
	private Sales sales = new Sales();
	Scanner in = new Scanner(System.in);

	/**
	 * Displays a menu of options and verifies the user's choice.
	 * 
	 * @return an integer in the range [0,10]
	 * @throws InterruptedException
	 */
	private int getChoice() throws IOException, InterruptedException {

		int input;

		do {
			try {
				Thread.sleep(500);
				stdErr.println();
				stdErr.print("[0]  �˳�\n" + "[1]  �����¿�\n" + "[2]  ������Ʒ\n" + "[3]  ��ʾ���е����\n" + "[4]  ʹ���ֽ���\n"
						+ "[5]  ʹ�ÿ����� \n" + "[6]  ��ʾ��ƷĿ¼ \n" + "[7]  ��ֵ\n" + "[8]  ɾ����Ʒ   " + "[9]  ��ʾ���ۼ�¼\n"
						+ "[10] �����ۼ�¼д��salesRecords�ļ��д洢\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 10 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	/**
	 * 
	 * ��ʼ��������Ʒ
	 * 
	 * @param
	 * 
	 */
	public void loadinit() {
		CatalogItem itemload1 = new CatalogItem("niunai", "mengniu", 3);
		CatalogItem itemload2 = new CatalogItem("juzi", "gannan", 5);
		CatalogItem itemload3 = new CatalogItem("shupian", "leshi", 6);
		CatalogItem itemload4 = new CatalogItem("pingguo", "fushikang", 5);
		CatalogItem itemload5 = new CatalogItem("coffee", "xingbake", 7);
		catalog.addItem(itemload1);
		catalog.addItem(itemload2);
		catalog.addItem(itemload3);
		catalog.addItem(itemload4);
		catalog.addItem(itemload5);
	}

	/**
	 * 
	 * @param filename
	 *            , content
	 * @throws IOException
	 */
	public void writeFile(String filename, String content) throws IOException {

		PrintWriter writer = new PrintWriter(new FileWriter(filename));
		writer.println(content);
		writer.close();
	}

	/**
	 * ʹ�ÿ�����
	 */
	private void buybycash() {
		System.out.println("��������Ҫ�����Ʒ����");
		String name = in.next();
		ArrayList<CatalogItem> items = new ArrayList<CatalogItem>();
		items = catalog.getItemList();
		double price = 0.0;
		int key = 0;
		for (CatalogItem item : items) {
			if (item.getName().equals(name)) {
				price = item.getPrice();
				key = 1;
			}
		}
		if (key == 1) {
			System.out.println("�۸�Ϊ��" + price + "Ԫ����Ͷ��");
			System.out.print("Ͷ���");
			try {
				double money = in.nextDouble();
				if (money >= price) {
					System.out.println("�����·���ȡ��Ʒ");
					System.out.println("���㣺" + (money - price) + "Ԫ");
					sales.additem(new SalesItem(name + "�۸�Ϊ:" + price));
				} else {
					System.out.println("����");
				}
			} catch (InputMismatchException e) {
				System.out.println("������淶�����֣�����  123");
				in.nextLine();
			}
		} else {
			System.out.println("����Ʒ������");

		}

	}

	/**
	 * 
	 * ʹ���ֽ���
	 * 
	 */
	private void buybycard() {
		VendingMachineSystem vdmSystem = new VendingMachineSystem();
		ArrayList<CatalogItem> items = new ArrayList<CatalogItem>();
		ArrayList<RechargeCardItem> reitems = new ArrayList<RechargeCardItem>();
		double have = -1;
		int k = -1;
		items = catalog.getItemList();
		reitems = recatalog.getReList();
		System.out.println("�����뿨��");
		String cardname = in.next();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(cardname));
			String s = "";
			if ((s = reader.readLine()) != null) {
				StringTokenizer str = new StringTokenizer(s, ",");
				cardname = str.nextToken();
				System.out.println("�𾴵�" + cardname + ",����");
				have = Double.parseDouble(str.nextToken());
				k = 0;
				reader.close();
			}
		} catch (FileNotFoundException e) {
			System.out.println("�ÿ��Ų�����");
		} catch (IOException e) {
			System.out.println("��ʽ��ƥ��");
		}
		// for(int i = 0 ; i < reitems.size();i++){
		// if(reitems.get(i).getCardname().equals(cardname)){
		// System.out.println("�𾴵�"+ cardname +",����");
		// }
		// if(i==reitems.size()){
		// System.out.println("�˿�������");
		// }
		// }
		if (k == 0) {
			int p = -1;
			System.out.println("��������Ҫ�����Ʒ����");
			String name = in.next();
			double price = 0.0;
			for (CatalogItem item : items) {
				if (item.getName().equals(name)) {
					price = item.getPrice();
					p = 0;
				}
			}
			if (p == 0) {
				System.out.print("�۸�Ϊ��" + price + "Ԫ����");
				System.out.print("ˢ����");

				// for(RechargeCardItem reitem : reitems){
				// if(reitem.getCardname().equals(cardname)){
				// have = reitem.getBalance();
				// }
				// }
				if (have >= price) {
					System.out.println("�����·���ȡ��Ʒ");
					double s = have - price;
					String h = String.valueOf(s);
					System.out.println("���Ϊ��" + s + "Ԫ");
					sales.additem(new SalesItem(name + "�۸�Ϊ:" + price));
					try {
						vdmSystem.writeFile(cardname, cardname + "," + h);
					} catch (IOException e) {
						System.out.println("������������");
					}

					// for(RechargeCardItem reitem : reitems){
					// if(reitem.getCardname().equals(cardname)){
					// reitem.setBalance(have-price);
					// }
					// }
				} else {
					System.out.println("���е�����");
				}
			} else {
				System.out.println("����Ʒ������");
			}
		}
	}

	/**
	 * Presents the user with a menu of options and executes the selected task.
	 * 
	 * @throws InterruptedException
	 */
	private void run() throws IOException, InterruptedException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				Scanner in = new Scanner(System.in);
				System.out.println("�����뿨��");
				String name = in.nextLine();
				System.out.println("������Ԥ����");
				try {
					double balance = in.nextDouble();
					recatalog.addCard(name, balance);
					in.nextLine();

				} catch (InputMismatchException e) {
					System.out.println("������淶�����֣�����  123");
					in.nextLine();
				}
			} else if (choice == 2) {
				System.out.println("��������Ʒ������");
				String name = in.next();
				System.out.println("��������Ʒ��Ʒ��");
				String brand = in.next();
				System.out.println("��������Ʒ�ļ۸�");
				try {
					double price = in.nextDouble();
					catalog.addItem(new CatalogItem(name, brand, price));
					in.nextLine();
				} catch (InputMismatchException e) {
					System.out.println("������淶�����֣�����  123");
					in.nextLine();
				}

			} else if (choice == 3) {
				System.out.println("�����������ѯ�Ŀ���");
				String cardname = in.next();
				recatalog.displaybalance(cardname);

			} else if (choice == 4) {
				this.buybycash();
			} else if (choice == 5) {
				this.buybycard();

			} else if (choice == 6) {
				catalog.displayCatalog();
			} else if (choice == 7) {
				System.out.println("��������Ҫ��ֵ�Ŀ���");
				String card = in.next();
				System.out.println("�������ֵ�Ľ��");
				try {
					double num = in.nextDouble();
					recatalog.addBalance(card, num);
					recatalog.displaybalance(card);
					in.nextLine(); // �建��
				} catch (InputMismatchException e) {
					System.out.println("������淶�����֣�����  123");
					in.nextLine();
				}
			} else if (choice == 8) {
				System.out.println("��������Ҫɾ������Ʒ����");
				String name = in.next();
				catalog.removeItem(name);
			} else if (choice == 9) {
				textsale.formatSales(sales);
			} else if (choice == 10) {
				sales.saveintxt();
			}

			choice = getChoice();

		}
	}

	/**
	 * 
	 * @param args
	 *            String arguments.
	 * @throws IOException
	 *             if there are errors in the input.
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws IOException, InterruptedException {
		VendingMachineSystem vdSystem = new VendingMachineSystem();
		vdSystem.loadinit();
		vdSystem.run();
	}
}
