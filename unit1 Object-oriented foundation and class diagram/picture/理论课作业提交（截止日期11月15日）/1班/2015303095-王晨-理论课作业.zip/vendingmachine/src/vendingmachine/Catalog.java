package vendingmachine;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * 
 * @author wangchen
 * @version 1.1.0
 * @see CatalogItem
 */

public class Catalog {
	private ArrayList<CatalogItem> catalogitems = new ArrayList<CatalogItem>();
	Scanner in = new Scanner(System.in);

	/**
	 * �ж�catalogitem�Ƿ���catalogitems��
	 * 
	 * @param catalogitem
	 * @return
	 */
	public boolean catalogitemIsFound(CatalogItem catalogitem) {
		for (CatalogItem zitem : catalogitems) {
			if (zitem.getName().equals(catalogitem.getName())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * 
	 * @return catalogitems
	 */
	public ArrayList<CatalogItem> getItemList() {
		return catalogitems;
	}

	/**
	 * 
	 * @param catalogitem
	 * 
	 */
	public void addItem(CatalogItem catalogitem) {
		if (catalogitemIsFound(catalogitem) == false) {
			catalogitems.add(catalogitem);
		} else {
			System.out.println("�˲�Ʒ�Ѿ�����");
		}
	}

	/**
	 * 
	 * @param name
	 * 
	 */
	public void removeItem(String name) {

		for (CatalogItem item : catalogitems) {
			if (item.getName().equals(name)) {
				System.out.println("ɾ���ɹ�");
				catalogitems.remove(item);
				break;
			}
		}
	}

	/**
	 * 
	 * @param name
	 * @return
	 */
	public CatalogItem getItem(String name) {
		for (CatalogItem item : catalogitems) {
			if (item.getName().equals(name)) {
				return item;
			}
		}
		return null;
	}

	/**
	 * ����catalogitems
	 * 
	 * @param
	 * 
	 */
	public void displayCatalog() {
		for (CatalogItem item : catalogitems) {
			item.displayItem();
		}
	}
}
