/**
 * 
 */
package vendingmachine;

/**
 * @author wangchen
 * @version 1.1.0
 * @see Sales
 */
public interface Formatter {
	/**
	 * 
	 * @param sales
	 * 
	 */
	public void formatSales(Sales sales);
}
