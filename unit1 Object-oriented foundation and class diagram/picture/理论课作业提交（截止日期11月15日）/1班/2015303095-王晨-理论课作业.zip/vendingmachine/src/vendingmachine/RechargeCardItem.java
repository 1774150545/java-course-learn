package vendingmachine;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * 
 * 
 * @author wangchen
 * @version 1.1.0
 * 
 */
public class RechargeCardItem {
	private String cardname;
	private double balance;
	Scanner in = new Scanner(System.in);

	/**
	 * @param cardname
	 * @param balance
	 */
	public RechargeCardItem(String cardname, double balance) {
		super();
		this.cardname = cardname;
		this.balance = balance;
	}

	/**
	 * 
	 * ��ֵ���
	 * 
	 * @param num
	 * 
	 */
	public void addBalance(double num) {
		System.out.println("�����뿨��");
		String str = in.next();

		try {
			BufferedReader reader = new BufferedReader(new FileReader(str));
			String a = "";
			try {
				if ((a = reader.readLine()) != null) {
					StringTokenizer str1 = new StringTokenizer(a, ",");
					String cardname = str1.nextToken();
					String balance = str1.nextToken();
					double b = Double.parseDouble(balance);
					b = b + num;
					String newbalance = String.valueOf(b);
					PrintWriter write = new PrintWriter(new FileWriter(str));
					write.println(cardname + "," + newbalance);
					write.close();
					reader.close();
				}
			} catch (IOException e) {
				System.out.println("�ļ�������");
			}
		} catch (FileNotFoundException e) {
			System.out.println("�ÿ�������");
		}

	}

	/**
	 * ���ص�ǰ���
	 * 
	 * @return balance
	 * 
	 */
	public double getBalance() {
		return balance;
	}

	/**
	 * @param balance
	 *            the balance to set
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}

	/**
	 * @return the cardname
	 */
	public String getCardname() {
		return cardname;
	}

	/**
	 * @param filename
	 *            , content
	 * @throws IOException
	 */
	public void writeFile(String filename, String content) throws IOException {

		filename = this.getCardname();
		content = this.getCardname() + "," + this.getBalance();
		PrintWriter writer = new PrintWriter(new FileWriter(filename));
		writer.println(content);
		writer.close();
	}
}
