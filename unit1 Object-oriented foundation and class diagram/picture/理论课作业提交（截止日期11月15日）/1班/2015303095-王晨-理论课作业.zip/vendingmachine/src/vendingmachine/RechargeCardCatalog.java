package vendingmachine;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * 
 * 
 * @author wangchen
 * @version 1.1.0
 * @see RechargeCardItem
 */
public class RechargeCardCatalog {
	private ArrayList<RechargeCardItem> items = new ArrayList<RechargeCardItem>();
	Scanner in = new Scanner(System.in);

	/**
	 * 
	 * @param item
	 * @return
	 */
	public boolean itemIsFound(RechargeCardItem item) {
		for (RechargeCardItem zitem : items) {
			if (zitem.getCardname().equals(item.getCardname())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @param cardname,
	 *            balance
	 * 
	 * @return
	 */
	public void addCard(String cardname, double balance) throws IOException {

		int i = 0;
		for (RechargeCardItem item : items) {
			if (item.getCardname().equals(cardname)) {
				i = 1;
			}
		}
		if (i != 1) {
			RechargeCardItem item = new RechargeCardItem(cardname, balance);
			item.writeFile(cardname, item.getCardname() + "," + item.getBalance());
			items.add(item);
			System.out.println("�����ɹ�");
		} else {
			System.out.println("�ÿ����Ѵ����뻻һ���û���");
		}

	}

	/**
	 * 
	 * @param card
	 *            , num
	 * @return
	 */
	public void addBalance(String card, double num) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(card));
			String a = "";
			try {
				if ((a = reader.readLine()) != null) {
					StringTokenizer str1 = new StringTokenizer(a, ",");
					String cardname = str1.nextToken();
					String balance = str1.nextToken();
					double b = Double.parseDouble(balance);
					b = b + num;
					String newbalance = String.valueOf(b);
					PrintWriter write = new PrintWriter(new FileWriter(card));
					write.println(cardname + "," + newbalance);
					write.close();
					reader.close();
					System.out.println("��ֵ�ɹ�");
				}
			} catch (IOException e) {
				System.out.println("�ļ�������");
			}
		} catch (FileNotFoundException e) {
			System.out.println("�ÿ�������");
		}

	}

	/**
	 * 
	 * @param cardname
	 * @return
	 */
	public void displaybalance(String cardname) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(cardname));
			String str = "";
			try {
				if ((str = reader.readLine()) != null) {
					System.out.println("��ǰ�ÿ���Ϣ����");
					System.out.println(str);
					reader.close();
				}
			} catch (IOException e) {
				System.out.println("�ļ�������");
			}
		} catch (FileNotFoundException e) {
			System.out.println("�ÿ���δ����");
		}
	}

	/**
	 * 
	 * @param
	 * @return the items
	 */
	public ArrayList<RechargeCardItem> getReList() {
		return items;
	}
}
