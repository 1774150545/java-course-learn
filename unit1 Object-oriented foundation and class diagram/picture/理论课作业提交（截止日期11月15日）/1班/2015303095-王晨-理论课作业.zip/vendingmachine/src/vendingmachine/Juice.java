package vendingmachine;

/**
 * 
 * 
 * @author wangchen
 * @version 1.1.0
 * 
 */
public class Juice extends CatalogItem {
	private String taste;

	/**
	 * @param name
	 * @param brand
	 * @param price
	 * @param taste
	 */
	public Juice(String name, String brand, double price, String taste) {
		super(name, brand, price);
		this.taste = taste;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Juice [" + super.toString() + ", taste=" + taste + "]";
	}

	/*
	 * @return taste
	 */
	public String getTaste() {
		return taste;
	}
}
