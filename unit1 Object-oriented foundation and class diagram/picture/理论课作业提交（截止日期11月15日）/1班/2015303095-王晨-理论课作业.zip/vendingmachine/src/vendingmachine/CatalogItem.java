package vendingmachine;

/**
 * 
 * 
 * @author wangchen
 * @version 1.1.0
 * 
 */
public class CatalogItem {
	private String name;
	private String brand;
	private double price;

	/**
	 * ���캯��
	 * 
	 * @param name
	 * @param brand
	 * @param price
	 */
	public CatalogItem(String name, String brand, double price) {
		super();
		this.name = name;
		this.brand = brand;
		this.price = price;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param the
	 *            price
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "name=" + name + ", brand=" + brand + ", price=" + price + ",";
	}

	/**
	 * 
	 * @param
	 * 
	 */
	public void displayItem() {
		System.out.println(this.toString());
	}
}
