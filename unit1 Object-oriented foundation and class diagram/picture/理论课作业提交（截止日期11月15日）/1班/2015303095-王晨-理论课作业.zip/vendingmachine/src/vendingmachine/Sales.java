/**
 * 
 */
package vendingmachine;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * @author wangchen
 * @version 1.1.0
 */
public class Sales {
	private ArrayList<SalesItem> items = new ArrayList<SalesItem>();

	private static final char New = '\n';

	/**
	 * ��������¼���ӵ�salesitem��
	 * 
	 * @param salesitem
	 */
	public void additem(SalesItem salesitem) {
		items.add(salesitem);
	}

	/**
	 * 
	 * @return items
	 */
	public ArrayList<SalesItem> getSalesList() {
		return items;
	}

	/**
	 * ����������ۼ�¼д��salesRecords�ļ���
	 * 
	 * @param
	 * @throws IOException
	 */
	public void saveintxt() throws IOException {
		String str = "";
		for (SalesItem item : items) {
			str = str + item.toString() + New;
		}
		PrintWriter writer = new PrintWriter(new FileWriter("salesRecords", true));
		writer.print(str);
		writer.close();
		System.out.println("��Refresh��salesRecords�鿴");

	}
}
