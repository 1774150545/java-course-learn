package vendingmachine;

import java.util.ArrayList;

/**
 * @author wangchen
 * @version 1.1.0
 * @see Sales
 */

public class TextSales implements Formatter {

	@Override
	/**
	 * 
	 * @param sales
	 * 
	 */
	public void formatSales(Sales sales) {
		ArrayList<SalesItem> items = new ArrayList<SalesItem>();
		items = sales.getSalesList();
		String str = "";
		for (SalesItem item : items) {
			str = str + item.toString() + '\n';
		}
		System.out.println(str);
	}

}
