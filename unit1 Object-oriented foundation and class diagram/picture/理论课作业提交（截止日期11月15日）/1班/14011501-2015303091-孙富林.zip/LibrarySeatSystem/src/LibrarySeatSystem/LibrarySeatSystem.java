package LibrarySeatSystem;

import java.io.*;

/**
 * This class implements a Library Seat System.
 *
 * @author Frank
 * @version 1.1.0
 */
public class LibrarySeatSystem {

	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	
	private CustCatalog custCatalog;
	private SeatCatalog seatCatalog;
	
	/**
	 * Starts the application
	 * @throws IOException
	 *             if there are errors in the input.
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws IOException, InterruptedException{
		
		LibrarySeatSystem app=new LibrarySeatSystem();
		app.run();
	}
	
	/**
	 *
	 * @param initialCatalog
	 *            a product catalog
	 */
	public LibrarySeatSystem(){
		this.seatCatalog=loadSeatCatalog();
		this.custCatalog=loadCustCatalog();
	}
	
	/**
	 * Creates an empty catalog and then add seats to it.
	 *
	 * @return a seat catalog
	 */
	private SeatCatalog loadSeatCatalog(){
		
		SeatCatalog catalog=new SeatCatalog();
		
		Situation situ1=new Situation(0);
		Situation situ2=new Situation(0);
		Situation situ3=new Situation(0);
		Situation situ4=new Situation(0);
		Situation situ5=new Situation(0);
		Situation situ6=new Situation(0);
		Situation situ7=new Situation(0);
		Situation situ8=new Situation(0);
		Situation situ9=new Situation(0);
		Situation situ10=new Situation(0);
		
		catalog.addSeat(new Seat("A01",(situ1)));
		catalog.addSeat(new Seat("A02",(situ2)));
		catalog.addSeat(new Seat("A03",(situ3)));
		catalog.addSeat(new Seat("A04",(situ4)));
		catalog.addSeat(new Seat("A05",(situ5)));
		catalog.addSeat(new Seat("B01",(situ6)));
		catalog.addSeat(new Seat("B02",(situ7)));
		catalog.addSeat(new Seat("B03",(situ8)));
		catalog.addSeat(new Seat("B04",(situ9)));
		catalog.addSeat(new Seat("B05",(situ10)));
		return catalog;
	}
	
	/**
	 * Creates an empty catalog and then add cust to it.
	 *
	 * @return a cust catalog
	 */
	private CustCatalog loadCustCatalog(){
		
		CustCatalog custCatalog =new CustCatalog();
		
		custCatalog.addCust(new Cust("Adele",2016001,"123456"));
		custCatalog.addCust(new Cust("Adam",2016002,"123457"));
		custCatalog.addCust(new Cust("Alan",2016003,"123458"));
		
		return custCatalog;
	}
	
	/*
	 * Presents the user with a menu of options and executes the selected task.
	 */
	private void run() throws IOException {

		Login();
		int choice = getChoice();
		//String code0=Read.scan();
		
		while (choice != 0) {
			if (choice == 1) {
				System.out.println("������λ��");
				BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
				String code = stdIn.readLine();
				//String code = new 
				chooseSeat(code);
			}
			else if(choice==2){
				displaySeat();
			}
			else if(choice==3){
				//cancelSeat(code0);
			}
			else if(choice==4){
				break;
			}

			choice = getChoice();

		}
	}
	
	/*
	 * Displays a menu of options and verifies the user's choice.
	 *
	 * @return an integer in the range [1,4]
	 */
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[1]Ԥ����λ\n"+"[2]��ѯԤ�����\n"+"[3]ȡ��Ԥ��\n"+"[4]�˳�\n");
				stdErr.flush();

				input = Integer.parseInt(Read.scan());

				stdErr.println();

				if (1 <= input && 4 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}
	
	/**
	 * Choose a seat.
	 */
	public void chooseSeat(String code){
		
		Seat seat  = this.seatCatalog.findSeatByCode(code);
		System.out.println(seat);
		int s=seat.getSituation().getSitu();
		if(s==0){
			System.out.println("ѡ���ɹ���");
			seat.getSituation().changeSituation();
		}
		else{
			System.out.println("�ѱ�Ԥ����");
		}
	}
	
	/**
	 * Displays the seat catalog.
	 */
	public void displaySeat() throws IOException{
		for(Seat seat: seatCatalog.getSeatList()){
			stdOut.println(seat.toString());
		}
		getChoice();
	}
	
	/**
	 * Cancel the seat.
	 */
	public void cancelSeat(String code){
		Seat seat = this.seatCatalog.findSeatByCode(code);
		int s=seat.getSituation().getSitu();
		if(s==1){
			System.out.println("ȡ���ɹ���");
			seat.getSituation().cancelSituation();
		}
		else{
			System.out.println("δ��Ԥ����");
		}
	}
	
	/**
	 * Log in the system.
	 */
	public void Login(){
		while(true){
			System.out.println("�������˺ţ�");
			int Id=Integer.parseInt(Read.scan());
			Cust cust=custCatalog.getCust(Id);
			if(cust!=null){
				cust.run();
				break;
			}
			
		}
	}
}
