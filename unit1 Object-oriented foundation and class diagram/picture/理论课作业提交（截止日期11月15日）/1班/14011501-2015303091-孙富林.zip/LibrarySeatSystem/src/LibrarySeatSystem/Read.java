package LibrarySeatSystem;
import java.io.*;
/**
 * ��ȡ�� Read
 * 
 * @author Frank
 * @version 1.0
 *
 */
public class Read {

	/**
	 * ��ȡ�����ַ���
	 * 
	 * @return the string
	 */
	public static String scan(){
		String str="";
		try{
			BufferedReader buf=new BufferedReader(new InputStreamReader(System.in));
			str=buf.readLine();
		}
		catch(Exception e){}
		return str;
	}
}
