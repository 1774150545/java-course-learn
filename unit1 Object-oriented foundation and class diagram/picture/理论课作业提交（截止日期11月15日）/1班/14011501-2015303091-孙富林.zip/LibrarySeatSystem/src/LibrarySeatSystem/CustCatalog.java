package LibrarySeatSystem;
import java.util.*;

/**
 * �û�Ŀ¼�� CustCatalog
 * 
 * @author Frank
 * @version 1.0
 */
public class CustCatalog {

	private ArrayList<Cust> cust;
	
	
	public CustCatalog(){
		this.cust=new ArrayList<Cust>();
	}
	
	public Cust getCust(int ID){
		for(Iterator i=this.iterator();i.hasNext();){
			Cust cust1=(Cust)i.next();
			if(cust1.getID()==ID){
				return cust1;
			}
		}
		return null;
	}

	private Iterator<Cust> iterator() {
		return this.cust.iterator();
	}
	
	public boolean addCust(Cust cust1){
		cust.add(cust1);
		return true;
	}
}
