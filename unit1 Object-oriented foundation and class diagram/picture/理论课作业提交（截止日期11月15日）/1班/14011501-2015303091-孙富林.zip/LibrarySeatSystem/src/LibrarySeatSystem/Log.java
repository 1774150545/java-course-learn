package LibrarySeatSystem;

public class Log {
	
	private CustCatalog custcatalog;
	
	public void Login(){
		while(true){
			System.out.println("�������˺ţ�");
			int Id=Integer.parseInt(Read.scan());
			Cust cust2=custcatalog.getCust(Id);
			if(cust2!=null){
				cust2.run();
			}
			System.out.println("�Ƿ��˳�(Y/N)");
			String str=Read.scan();
			if(str.equals("Y")||str.equals("y")){
				break;
			}
		}
	}

}