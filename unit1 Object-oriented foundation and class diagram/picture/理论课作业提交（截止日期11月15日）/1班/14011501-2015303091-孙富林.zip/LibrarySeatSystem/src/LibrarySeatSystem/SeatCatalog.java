package LibrarySeatSystem;
import java.util.*;

/**
 * ·��Ŀ¼�� SeatCatalog
 * 
 * @author Frank
 * @version 1.0
 *
 */
public class SeatCatalog {

	private ArrayList<Seat> seatList;
	
	/**
	 * SeatCatalog��Ĺ��췽�� ��ʼ��SeatCatalog������
	 * 
	 * @param seatList
	 *            ��λ�б�
	 */
	public SeatCatalog(){
		seatList=new ArrayList<Seat>();
	}
	
	/**
	 * ��ȡ��λ�б�
	 * 
	 * @return the seatList
	 */
	public ArrayList<Seat> getSeatList(){
		return seatList;
	}
	
	/**
	 * ������λ
	 * 
	 * @param seat
	 * 
	 * @return true or false
	 */
	public boolean addSeat(Seat seat){
		seatList.add(seat);
		return true;
	}
	
	/**
	 * ͨ��code����·��
	 * 
	 * @param code
	 * 
	 * @return the seat
	 */
	public Seat findSeatByCode(String code){
		for(Iterator i=this.iterator();i.hasNext();){
			Seat seat1=(Seat)i.next();
			if(seat1.getCode().equals(code)){
				return seat1;
			}
		}
		return null;
	}
	
	/**
	 * Returns an iterator.
	 * @return an Iterator
	 */
	private Iterator<Seat> iterator() {
		return this.seatList.iterator();
	}
	
}
