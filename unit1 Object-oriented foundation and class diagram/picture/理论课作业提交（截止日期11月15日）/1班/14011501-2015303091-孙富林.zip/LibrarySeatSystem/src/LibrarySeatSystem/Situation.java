package LibrarySeatSystem;

public class Situation {

	private int situ;
	
	public int getSitu(){
		return situ;
	}
	
	public Situation(int newSitu){
		this.situ=newSitu;
	}
	
	public void changeSituation(){
		situ=1;
	}
	
	public void cancelSituation(){
		situ=0;
	}
	
	public String toString(){
		return " "+situ;
	}
}
