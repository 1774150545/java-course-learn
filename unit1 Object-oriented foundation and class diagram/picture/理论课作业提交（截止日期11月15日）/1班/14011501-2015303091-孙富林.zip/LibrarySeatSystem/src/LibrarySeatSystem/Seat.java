package LibrarySeatSystem;

/**
 * ��λ�� Seat
 * 
 * @author frank
 * @version 1.0
 */
public class Seat {

	String code;
	private Situation situation;
	
	/**
	 * Seat�Ĺ��췽�� ��ʼ��Seat������
	 * 
	 * @param code
	 *            seat��code
	 * @param situation
	 *            seat��situation
	 */
	public Seat(String newCode,Situation newSituation){
		this.code=newCode;
		this.situation=newSituation;
	}
	
	/**
	 * ��ȡcode
	 * 
	 * @return the code
	 */
	public String getCode(){
		return code;
	}
	
	/**
	 * ��ȡSituation
	 * 
	 * @return the situation
	 */
	public Situation getSituation(){
		return situation;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString() ���Seat����������
	 */
	public String toString(){
		return "Seat: "+code+",situation:"+situation;
	}
}
