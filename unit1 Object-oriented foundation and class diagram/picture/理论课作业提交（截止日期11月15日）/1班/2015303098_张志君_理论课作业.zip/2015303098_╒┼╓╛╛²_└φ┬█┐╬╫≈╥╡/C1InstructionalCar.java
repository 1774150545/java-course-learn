/**
 * C1������
 * @author ��־��
 * @version 1.0.0
 * @see InstructionalCar
 */
public class C1InstructionalCar extends InstructionalCar{

	public C1InstructionalCar(String number,Coach coach) {
		this.setNumber(number);
		this.setCoach(coach);
		
	}
}
