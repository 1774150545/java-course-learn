import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
  * ������
  * 
 * @author ��־��
 * @version 1.0.0
 */
public class DriverTrainingManagementSystem {

	private static BufferedReader  stdIn =
			new  BufferedReader(new  InputStreamReader(System.in));
	private static PrintWriter  stdOut =
			new  PrintWriter(System.out, true);
	private static PrintWriter  stdErr =
			new  PrintWriter(System.err, true);

	private InstructionalCarDatabase instructionalCarDB;

	public static void  main(String[]  args) throws IOException {

		DriverTrainingManagementSystem  app = new DriverTrainingManagementSystem();

			app.run();
		}
	
	private DriverTrainingManagementSystem() {

		instructionalCarDB = instructionalCars();
		
	}

	/*
	 * Loads a InstructionalCarDatabase object.
	 */
	private InstructionalCarDatabase instructionalCars() {

		InstructionalCarDatabase instructionalCarDB = new InstructionalCarDatabase();
       /*  ѧԱ��Ϣ��ʼ��   */
		Student student1 = new Student("Tom", "male", "14060319940710", "2016-2-12", "unlocal","Harry");
		Student student2 = new Student("Mary", "female", "14160319950614", "2016-3-12", "local","Harry");
		Student student3 = new Student("John", "male", "11012019970102", "2016-4-12", "local","Harry");
		Student student4= new Student("Amy","female", "15814518970205", "2016-5-12", "local","Harry");
		Student student5 = new Student("Peter", "male", "87945619950412", "2016-6-12", "local","Harry");
		Student student6 = new Student("Abby:", "female", "60012419920415", "2016-7-12", "unlocal","Harry");
		Student student7 = new Student("Adrian", "male", "60345919950714", "2016-8-12", "local","X");
		Student student8 = new Student("Angelia", "female", "12458519970206", "2016-1-12", "local","Jack");
		Student student9 = new Student("Alan", "male", "32145618890207", "2016-9-12", "unlocal","Jack");
		Student student10= new Student("Carrie", "female", "78945618790501", "2013-3-12", "local","Jack");
		Student student11 = new Student("Amos", "male", "12185419940801", "2014-2-12", "local","Jack");
		Student student12 = new Student("Daisy", "female", "12346819980601", "2015-3-12", "unlocal","Jack");
		Student student13 = new Student("Jim", "male", "19914719910106", "2016-2-12", "unlocal","Yilia");
		Student student14 = new Student("Iris", "female", "19875519960201", "2016-3-02", "local","Yilia");
		Student student15 = new Student("Dana", "male", "12415418890103", "2016-4-22", "local","Yilia");
		Student student16= new Student("Laura","female", "12345818840201", "2016-5-07", "local","Yilia");
		Student student17 = new Student("Eric", "male", "36954119940206", "2016-6-08", "local","Yilia");
		Student student18 = new Student("Vivian", "female", "12584519040306", "2016-9-12", "unlocal","Yilia");

		
		ArrayList<Student>  students1 = new ArrayList<Student>();
		students1.add(student1);     students1.add(student2);
		students1.add(student3);     students1.add(student4);
		students1.add(student5);     students1.add(student6);
		ArrayList<Student>  students2 = new ArrayList<Student>();
		students2.add(student7);    students2.add(student8);
		students2.add(student9);    students2.add(student10);
		students2.add(student11);    students2.add(student12);
		ArrayList<Student>  students3 = new ArrayList<Student>();
		students3.add(student13);students3.add(student14);
		students3.add(student15);    students3.add(student16);
		students3.add(student17);    students3.add(student18);
		 /*  ������Ϣ��ʼ��   */
		Coach coach1 = new Coach("Harry","male","A000",20,"A1",students1);
		Coach coach2 = new Coach("Jack","male","B000",15,"B1",students2);
		Coach coach3 = new Coach("Yilia","fmale","C000",10,"C1",students3);
		 /* ��������Ϣ��ʼ��   */
		
		C1InstructionalCar car1 =new C1InstructionalCar("A1111111",coach1) ;
		B1InstructionalCar car2 =new B1InstructionalCar("B22222",coach3) ;
		A1InstructionalCar car3 =new A1InstructionalCar("C33333",coach2);
		instructionalCarDB.addInstructionalCar(car1);
		instructionalCarDB.addInstructionalCar(car2);
		instructionalCarDB.addInstructionalCar(car3);
		return instructionalCarDB;
	}
	private void run() throws IOException  {

		int  choice = getChoice();

		while (choice != 0)  {
			if (choice == 1)  {
				displayStudents();
			} else if (choice == 2)  {
				displayCars();
			} else if (choice == 3)  {
				addStudent();		
			} else if (choice == 4)  {
				removeStudent();
			}
			choice = getChoice();
		}
	}

	private int  getChoice() throws IOException  {

		int  input;

		do  {
			try  {
				stdErr.println();
				stdErr.print("[0]  Quit\n"
				             + "[1]  Display students\n"
				             + "[2]  Display cars\n"
				             + "[3]  Add student\n"
				             + "[4]  Remove student\n"
				             + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 4 >= input)  {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException  nfe)  {
				stdErr.println(nfe);
			}
		}  while (true);

		return  input;
	}

	/**
	 * ����ѧԱ������Ϣɾ����ҵѧԱ
	 * @throws IOException
	 */
	private void removeStudent() throws IOException {
		Student student = new Student();
		student = readStudent();

			if (student != null) {
				for (InstructionalCar car:this.instructionalCarDB.getCars()){
				
					for (Student s: car.getCoach().getStudents()){
						if(s.toString().equals(student.toString())){
					car.getCoach().getStudents().remove(s);
						stdErr.println("delete successfully!");
						break;
						}
					}		
				}
			}
		
	}



	/**
	 * ����ѧԱ
	 * @throws IOException
	 */
	private void addStudent() throws IOException {
			Student tempStudent = new Student();
			stdErr.println("Now you can add the new one");
			stdErr.println("Please input name>");
			tempStudent.setName(stdIn.readLine());
			stdErr.println("Please input sex>");
			tempStudent.setSex(stdIn.readLine());
			stdErr.println("Please input idNumber>");
			tempStudent.setIdNumber(stdIn.readLine());
			stdErr.println("Please input enrollmentDate>");
			tempStudent.setEnrollmentDate(stdIn.readLine());
			stdErr.println("Please input registeredResidence>");
			tempStudent.setRegisteredResidence(stdIn.readLine());

			stdErr.println("Please input Coach's name ");
			String temp =stdIn.readLine();
			tempStudent.setCoachname(temp);
			if(temp.equals("Harry")){this.instructionalCarDB.getCars().get(0).getCoach().addStudent(tempStudent);
				System.out.println("Add Product Successful!!");
			}else if(temp.equals("Jack")){this.instructionalCarDB.getCars().get(2).getCoach().addStudent(tempStudent);
				System.out.println("Add Product Successful!!");
			}else if(temp.equals("Yilia")){this.instructionalCarDB.getCars().get(1).getCoach().addStudent(tempStudent);	
			System.out.println("Add Product Successful!!");
		} else {System.out.println("Add Product failed!");}
	}
	private void displayCars() throws IOException {
		int size = this.instructionalCarDB.getCars().size();
		if (size == 0) {
			stdErr.println("The catalog is empty");
		} else {
			stdOut.println();
			for (InstructionalCar car : this.instructionalCarDB.getCars()) {
				stdOut.println(car.toString());

			}
		}
		run();
		
	}

	private void displayStudents() {
		stdOut.println();
		for (InstructionalCar car : this.instructionalCarDB.getCars()) {
			stdOut.println(car.getCoach().displayStudentList());
			stdOut.println();
		}
	}
	private Student readStudent() throws IOException {

		stdErr.flush();
		Student tempStudent = new Student();
		stdErr.println("Please input name>");
		tempStudent.setName(stdIn.readLine());
		stdErr.println("Please input sex>");
		tempStudent.setSex(stdIn.readLine());
		stdErr.println("Please input idNumber>");
		tempStudent.setIdNumber(stdIn.readLine());
		stdErr.println("Please input enrollmentDate>");
		tempStudent.setEnrollmentDate(stdIn.readLine());
		stdErr.println("Please input registeredResidence>");
		tempStudent.setRegisteredResidence(stdIn.readLine());
		stdErr.println("Please input coachname>");
		tempStudent.setCoachname(stdIn.readLine());
		return tempStudent;
	}
}
