
/**
 *  A1������
 *  
 * @author ��־��
 * @version 1.0.0
 * @see InstructionalCar
 */
public class A1InstructionalCar extends InstructionalCar{
	public A1InstructionalCar(String number,Coach coach) {
		this.setNumber(number);
		this.setCoach(coach);

 }
	
}
