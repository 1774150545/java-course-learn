/**
 *  B1������
 *  
 * @author ��־��
 * @version 1.0.0
 * @see InstructionalCar
 */
public class B1InstructionalCar extends InstructionalCar{
	public B1InstructionalCar(String number,Coach coach) {
		this.setNumber(number);
		this.setCoach(coach);

 }
}
