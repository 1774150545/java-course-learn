import java.util.ArrayList;
import java.util.Iterator;

/**
 * ��У�����������ݿ�
 * 
 * @author ��־��
 * @version 1.0.0
 * @see InstructionalCar
 */
public class InstructionalCarDatabase {
		private ArrayList<InstructionalCar>  cars;
	
		public InstructionalCarDatabase()  {

			this.cars = new ArrayList<InstructionalCar>();
		}

		/**
		 * Adds a InstructionalCar to this collection.
		 *
		 * @param car  the {@link InstructionalCar} object.
		 */
		public void  addInstructionalCar(InstructionalCar car)  {

			this.cars.add(car);
		}

		/**
		 * Returns an iterator over the cars in this database.
		 *
		 * return  an {@link Iterator} of {@link InstructionalCar}
		 */
		public Iterator<InstructionalCar>  iterator() {

			return this.cars.iterator();
		}

		/**
		 * Returns the {@link InstructionalCar} object with the specified
		 * <code>id</code>.
		 *
		 * @param id  the license of the instructionalCar.
		 * @return  The {@link InstructionalCar} object with the specified license.
		 *          Returns <code>null</code> if the object with the
		 *          license not found.
		 */
		public InstructionalCar  getInstructionalCar(int n)  {

					return cars.get(n);
				
		}

		/**
		 * 
		 * @return cars
		 */
		public ArrayList<InstructionalCar> getCars() {
			return cars;
		}
        /**
         * @param car ɾ���ĳ���
         * @return ɾ���ɹ�����true
         */
        public boolean removeCar(InstructionalCar car){
        	if(this.cars.contains(car)){
        	this.cars.remove(car);
        	return true;}
			return false;
        }
		/**
		 * Returns the number of {@link InstructionalCar} objects in this collection.
		 *
		 * @return  the number of {@link InstructionalCar} objects in this collection.
		 */
		public int  getNumberOfInstructionalCars()  {

			return this.cars.size();
		}
		
}
