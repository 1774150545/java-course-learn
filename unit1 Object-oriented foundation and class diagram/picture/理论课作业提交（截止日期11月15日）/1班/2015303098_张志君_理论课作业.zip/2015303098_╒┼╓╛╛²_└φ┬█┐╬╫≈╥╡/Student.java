
/**
 * ѧԱ
 * 
 * @author ��־��
 * @version1.0.0
 *
 */
public class Student {
	private String name;
	private String sex;
	private String idNumber;
	private String enrollmentDate;
	private String registeredResidence;
	private String coachname;

	

	/**
	 * ���캯��
	 * @param name
	 * @param sex
	 * @param idNumber
	 * @param enrollmentDate
	 * @param registeredResidence
	 * @param coachname
	 */
	public Student(String name, String sex, String idNumber, String enrollmentDate, String registeredResidence,
			String coachname) {
		this.name = name;
		this.sex = sex;
		this.idNumber = idNumber;
		this.enrollmentDate = enrollmentDate;
		this.registeredResidence = registeredResidence;
		this.coachname = coachname;
	}
	/**
	 * ���캯��
	 */
	public Student(){
		
	}

	/**
	 * ��ȡѧԱ����
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * ��ȡ��������
	 * @return coachname
	 */
	public String getCoachname() {
		return coachname;
	}

	

	/**
	 * @param name Ҫ���õ� name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @param sex Ҫ���õ� sex
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}

	/**
	 * @param idNumber Ҫ���õ� idNumber
	 */
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	/**
	 * @param enrollmentDate Ҫ���õ� enrollmentDate
	 */
	public void setEnrollmentDate(String enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}

	/**
	 * @param registeredResidence Ҫ���õ� registeredResidence
	 */
	public void setRegisteredResidence(String registeredResidence) {
		this.registeredResidence = registeredResidence;
	}

	/**
	 * @param coachname Ҫ���õ� coachname
	 */
	public void setCoachname(String coachname) {
		this.coachname = coachname;
	}

	/**
	 * ��ȡ�Ա�
	 * @return sex
	 */
	public String getSex() {
		return sex;
	}

	/**
	 * ��ȡ����֤��
	 * @return idNumber
	 */
	public String getIdNumber() {
		return idNumber;
	}

	/**
	 * ��ȡ��ѧ����
	 * @return enrollmentDate
	 */
	public String getEnrollmentDate() {
		return enrollmentDate;
	}

	/**
	 * ��ȡ�������ڵ�
	 * @return registeredResidence
	 */
	public String getRegisteredResidence() {
		return registeredResidence;
	}
    public String toString(){
    	return name+" "+sex+" "+idNumber+" "+enrollmentDate+" "+registeredResidence+" "+coachname;

    }
}
