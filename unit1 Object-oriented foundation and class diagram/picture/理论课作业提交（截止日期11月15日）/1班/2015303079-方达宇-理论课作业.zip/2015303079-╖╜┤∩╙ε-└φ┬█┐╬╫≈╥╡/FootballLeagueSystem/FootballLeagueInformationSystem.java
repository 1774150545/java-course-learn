package FootballLeagueSystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author FANG
 *	FootballLeagueInformationSystem 
 */
public class FootballLeagueInformationSystem {
	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private FootballAssociation association;

/**
 * @param args
 * @throws IOException
 * main����
 */
	public static void main(String[] args) throws IOException {

		FootballLeagueInformationSystem application = new FootballLeagueInformationSystem();
		application.run();

	}
/**
 * �����ʼ���ݺ���
 */
	private FootballLeagueInformationSystem() {
		this.association = loadAssociation();
	}
/**
 * ��ʼ������ش�������
 * @return
 */
	private FootballAssociation loadAssociation() {

		Player player1 = new Player("Gao", "male", 18, "Forward", "A001");
		Player player2 = new Player("Xu", "male", 20, "Guard", "A002");
		Player player3 = new Player("Gu", "male", 22, "Guard", "A003");
		Player player4 = new Player("Wang", "male", 19, "Forward", "B001");
		Player player5 = new Player("Zheng", "male", 18, "Forward", "B002");
		Player player6 = new Player("Liu", "male", 22, "Guard", "B003");

		Ref ref1 = new Ref("Fang", "male", 35, "Z001");
		Ref ref2 = new Ref("Fan", "male", 42, "Z002");

		Coach coach1 = new Coach("Bai", "male", 50, "K001");
		Coach coach2 = new Coach("Bao", "male", 37, "K002");

		Team team1 = new Team("Henda", new ArrayList<Player>(Arrays.asList(player1, player2, player3)),
				new ArrayList<Coach>(Arrays.asList(coach1)));
		Team team2 = new Team("Shanggang", new ArrayList<Player>(Arrays.asList(player4, player5, player6)),
				new ArrayList<Coach>(Arrays.asList(coach2)));

		FootballAssociation Association = new FootballAssociation(new ArrayList<Team>(Arrays.asList(team1, team2)),
				new ArrayList<Ref>(Arrays.asList(ref1, ref2)));
		return Association;
	}
/**
 * 
 * @return
 * @throws IOException
 * �����û�������غ���
 */
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" + "[1] Display All team \n" + "[2] Display a player with specific code\n"
						+ "[3] Add a player\n" + "[4] remove a player with specific code\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 5 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}
/**
 * ������д�������
 * @throws IOException
 */
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				displayAllTeam();
			} else if (choice == 2) {
				displaySpecialPlayer();
			} else if (choice == 3) {
				addPlayer();
			} else if (choice == 4) {
				removePlayer();
			}
			choice = getChoice();
		}
	}
/**
 * display all teams information
 */
	public void displayAllTeam() {

		int size = this.association.getTeams().size();

		if (size == 0) {
			stdErr.println("There is no team");
		} else {
			for (Team i : this.association.getTeams()) {
				stdOut.println(i.toString());
			}
		}
	}
/**
 * display a player with special code
 * @throws IOException
 */
	public void displaySpecialPlayer() throws IOException {
		stdErr.print("Player code> ");
		stdErr.flush();
		String Code = stdIn.readLine();
		for (Team i : this.association.getTeams()) {
			for (Player j : i.getPlayers()) {
				if (j.getCode().equals(Code)) {
					stdOut.println(j.toString());
					return;
				}
			}
		}
		stdOut.println("No Player with this code");
	}
/**
 * add a player
 * @throws IOException
 */
	public void addPlayer() throws IOException {
		stdErr.println("add Player's code> ");
		stdErr.flush();

		String Code = stdIn.readLine();
		for (Team i : this.association.getTeams()) {
			for (Player j : i.getPlayers()) {
				if (j.getCode().equals(Code)) {
					stdOut.println("There is already a Player with this code!");
					return;
				}
			}
		}
		Player Q = new Player();
		Q.setCode(Code);
		stdErr.println("Please input Playername>");
		Q.setName(stdIn.readLine());
		stdErr.println("Please input Playergender>");
		Q.setGender(stdIn.readLine());
		stdErr.println("Please input Playerage>");
		Q.setAge(Integer.parseInt(stdIn.readLine()));
		stdErr.println("Please input Playerposition>");
		Q.setPosition(stdIn.readLine());
		stdErr.println("Please input a team number which this Player join in>");
		int t = Integer.parseInt(stdIn.readLine()) - 1;
		if (t >= 0 && t < association.getTeams().size()) {
			this.association.getTeams().get(t).getPlayers().add(Q);
			System.out.println("Add Player Successful!!");
		} else {
			System.out.println("There is no team with this number!!");
		}
	}
/**
 * remove a player with special code
 * @throws IOException
 */
	public void removePlayer() throws IOException {
		stdErr.print("Remove Player's code> ");
		stdErr.flush();

		String Code = stdIn.readLine();
		for (Team i : this.association.getTeams()) {
			for (Player j : i.getPlayers()) {
				if (j.getCode().equals(Code)) {
					i.getPlayers().remove(j);
					stdOut.println("Remove successfully!");
					return;
				}
			}
		}
		stdOut.println("There is no Player with this code!");
		return;
	}
}
