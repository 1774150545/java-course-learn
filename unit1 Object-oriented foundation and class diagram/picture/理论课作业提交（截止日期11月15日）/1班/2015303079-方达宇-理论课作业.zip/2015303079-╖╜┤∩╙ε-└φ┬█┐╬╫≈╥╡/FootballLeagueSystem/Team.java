package FootballLeagueSystem;

import java.util.ArrayList;
/**
 * 
 * @author FANG
 *	class Team
 */
public class Team {
	private String name;
	private ArrayList<Player> players;
	private ArrayList<Coach> coaches;
/**
 * Nonparametric constructor
 */
	public Team() {
		super();
	}
/**
 * constructor
 * @param name
 */
	public Team(String name) {
		super();
		this.name = name;
	}
/**
 * constructor
 * @param name
 * @param players
 * @param coaches
 */
	public Team(String name, ArrayList<Player> players, ArrayList<Coach> coaches) {
		super();
		this.name = name;
		this.players = players;
		this.coaches = coaches;
	}
/**
 * get name
 * @return
 */
	public String getName() {
		return name;
	}
/**
 * set name
 * @param name
 */
	public void setName(String name) {
		this.name = name;
	}
/**
 * get players
 * @return
 */
	public ArrayList<Player> getPlayers() {
		return players;
	}
/**
 * get coaches
 * @return
 */
	public ArrayList<Coach> getCoaches() {
		return coaches;
	}
/**
 * players toString
 * @return
 */
	public String playerstoString() {
		String j = "";
		for (Player i : this.getPlayers()) {
			j = j + i.toString();
		}
		return j;
	}
/**
 * coaches toString
 * @return
 */
	public String coachestoString() {
		String j = "";
		for (Coach i : this.getCoaches()) {
			j = j + i.toString();
		}
		return j;
	}
/**
 * toString()
 */
	@Override
	public String toString() {
		return "Team [name=" + name + ", players=" + playerstoString() + ", coaches=" + coachestoString() + "]";
	}

}
