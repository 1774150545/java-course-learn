package FootballLeagueSystem;

import java.util.ArrayList;
/**
 * class FootballAssociation
 * @author FANG
 *
 */
public class FootballAssociation {
	
	private ArrayList<Team> teams;
	private ArrayList<Ref> refs;
/**
 * Nonparametric constructor
 */
	public FootballAssociation() {
		super();
	}
/**
 * get arraylist teams
 * @return
 */
	public ArrayList<Team> getTeams() {
		return teams;
	}
/**
 * get arraylist refs
 * @return
 */
	public ArrayList<Ref> getRefs() {
		return refs;
	}
/**
 * Constructor
 * @param teams
 * @param refs
 */
	public FootballAssociation(ArrayList<Team> teams, ArrayList<Ref> refs) {
		super();
		this.teams = teams;
		this.refs = refs;
	}

}
