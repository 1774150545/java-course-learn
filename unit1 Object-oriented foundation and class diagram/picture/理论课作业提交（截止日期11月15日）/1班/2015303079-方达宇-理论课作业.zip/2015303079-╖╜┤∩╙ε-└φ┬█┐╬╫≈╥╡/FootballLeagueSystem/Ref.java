package FootballLeagueSystem;
/**
 * 
 * @author FANG
 *	class Ref
 */
public class Ref extends Person {
	/**
	 * 
	 * @param name
	 * @param gender
	 * @param age
	 * @param code
	 */
	private String code;

	/**
	 * constructor
	 */
	public Ref(String name, String gender, int age, String code) {
		super(name, gender, age);
		this.code = code;
	}
/**
 * get code
 * @return
 */
	public String getCode() {
		return code;
	}
/**
 * set code
 * @param code
 */
	public void setCode(String code) {
		this.code = code;
	}
/**
 * toString()
 */
	@Override
	public String toString() {
		return "Ref [yearofRef=" + code + "]";
	}

}
