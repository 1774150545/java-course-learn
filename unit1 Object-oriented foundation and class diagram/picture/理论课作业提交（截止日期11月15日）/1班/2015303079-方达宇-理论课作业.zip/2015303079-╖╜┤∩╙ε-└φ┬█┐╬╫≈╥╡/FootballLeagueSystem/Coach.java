package FootballLeagueSystem;
/**
 * 
 * @author FANG
 * class coach
 */
public class Coach extends Person {
	private String code;
/**
 * constructor
 * @param name
 * @param gender
 * @param age
 * @param code
 */
	public Coach(String name, String gender, int age, String code) {
		super(name, gender, age);
		this.code = code;
	}
/**
 * get code
 * @return
 */
	public String getCode() {
		return code;
	}
/**
 * set code
 * @param code
 */
	public void setCode(String code) {
		this.code = code;
	}

/**
 * toString()
 * 	@Override
 */
	public String toString() {
		return "Coach [Code=" + code + "]";
	}

}
