package FootballLeagueSystem;
/**
 * 
 * @author FANG
 *	class Player
 */
public class Player extends Person {
	/**
	 * 
	 * @param name
	 * @param gender
	 * @param age
	 * @param position
	 * @param code
	 */
	private String position;
	private String code;
/**
 *  constructor
 */
	public Player(String name, String gender, int age, String position, String code) {
		super(name, gender, age);
		this.position = position;
		this.code = code;
	}
/**
 * Nonparametric constructor
 */
	public Player() {
		super();
	}
/**
 * get position
 * @return
 */
	public String getPosition() {
		return position;
	}
/**
 * set position
 * @param position
 */
	public void setPosition(String position) {
		this.position = position;
	}
/**
 * getcode
 * @return
 */
	public String getCode() {
		return code;
	}
/**
 * set code
 * @param code
 */
	public void setCode(String code) {
		this.code = code;
	}
/**
 * toString()
 */
	@Override
	public String toString() {
		return "Player [name=" + getName() + ",gender=" + getGender() + ",age=" + getAge() + ",position=" + position
				+ ", code=" + code + "]";
	}

}
