package FootballLeagueSystem;
/**
 * 
 * @author FANG
 * class Person
 */
public class Person {
	private String name;
	private String gender;
	private int age;
/**
 * constructor
 * @param name
 * @param gender
 * @param age
 */
	public Person(String name, String gender, int age) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
	}
/**
 * Nonparametric constructor
 */
	public Person() {
		super();
	}
/**
 * get name
 * @return
 */
	public String getName() {
		return name;
	}
/**
 * set name
 * @param name
 */
	public void setName(String name) {
		this.name = name;
	}
/**
 * get gender
 * @return
 */
	public String getGender() {
		return gender;
	}
/**
 * set gender
 * @param gender
 */
	public void setGender(String gender) {
		this.gender = gender;
	}
/**
 * get age
 * @return
 */
	public int getAge() {
		return age;
	}
/**
 * set age
 * @param age
 */
	public void setAge(int age) {
		this.age = age;
	}
/**
 * to String()
 */
	@Override
	public String toString() {
		return "Person [name=" + name + ", gender=" + gender + ", age=" + age + "]";
	}

}
