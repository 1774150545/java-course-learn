/**
 * 
 */
package selfCreate;

import java.io.*;
import java.util.ArrayList;

/**
 * @author liyuanshen
 * @version 1.0
 * 
 */
public class CourseChosenSystem {

	private static BufferedReader stdIn = new BufferedReader(
			new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	private CourseCatalog courses;
	private StudentCatalog students;

	/**
	 * �޲ι��캯��������һ��ϵͳ����
	 * 
	 */
	public CourseChosenSystem() {

		courses = new CourseCatalog();
		students = new StudentCatalog();
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		CourseChosenSystem application = new CourseChosenSystem();
		application.run();
	}

	/**
	 * ����û������ѡ����
	 * 
	 * @return ѡ����
	 * @throws IOException
	 */
	public int getChoice() throws IOException {

		int input;
		do {
			try {
				stdErr
						.print("[0]Quit\n[1]Display courses\n[2]Find course by teacher\n[3]Display students\n[4]"
								+ "Find student by studentNumber\n[5]Add courses\n[6]Add students\n[7]Set teacher for course\nEnter your choice>");
				stdErr.flush();
				input = Integer.parseInt(stdIn.readLine());
				if (input <= 7 && input >= 0) {
					break;
				} else {
					stdErr.println("Invalid choice" + input);
				}
			} catch (NumberFormatException nef) {
				stdErr.println("Invalid choice");
			}
		} while (true);
		return input;
	}

	/**
	 * ����ϵͳ
	 * 
	 * @throws IOException
	 */
	public void run() throws IOException {

		do {
			int input = getChoice();
			if (input == 1) {
				displayCourses();
			} else if (input == 2) {
				stdErr.println("Enter teacher id>");
				this.displayCoursesByTeacher(stdIn.readLine());
			} else if (input == 3) {
				this.displayStudents();
			} else if (input == 4) {
				stdErr.println("Enter studentNumber>");
				this.displayStudentsByNumber(stdIn.readLine());
			} else if (input == 5) {
				this.addCourse();
			} else if (input == 6) {
				this.addStudent();
			} else if (input == 7) {
				this.setTeacherForCourse();
			} else {
				break;
			}
		} while (true);
	}

	/**
	 * չʾϵͳ�����еĿγ�
	 * 
	 */
	public void displayCourses() {

		if (courses.getCourses().size() == 0) {
			stdOut.println("None courses!");
		} else {
			for (Course course : courses.getCourses()) {
				stdOut.println(course.toString());
			}
		}
	}

	/**
	 * չʾϵͳ�����е�ѧ��
	 * 
	 */
	public void displayStudents() {

		if (students.getStudents().size() == 0) {
			stdOut.println("None students!");
		} else {
			for (Student student : students.getStudents()) {
				stdOut.println(student.toString());
			}
		}
	}

	/**
	 * չʾϵͳ�����û��ṩ��ID����ʦ����Ŀγ�
	 * 
	 * @param id
	 *            ��ʦID
	 */
	public void displayCoursesByTeacher(String id) {

		ArrayList<Course> temp = new ArrayList<Course>();
		for (Course course : courses.getCourses()) {
			if (course.getTeacher().getId().equals(id)) {
				temp.add(course);
			}
		}
		if (temp.size() == 0) {
			stdOut.println("None courses!");
		} else {
			for (Course course : temp) {
				stdOut.println(course.toString());
			}
		}
	}

	/**
	 * չʾϵͳ�����û��ṩѧ�ŵ�ѧ����Ϣ
	 * 
	 * @param number
	 *            ѧ��ѧ��
	 */
	public void displayStudentsByNumber(String number) {

		Student temp = null;
		for (Student student : students.getStudents()) {
			if (student.getStudentNumber().equals(number)) {
				temp = student;
			}
		}
		if (temp != null) {
			stdOut.println(temp.toString());
		} else {
			stdOut.println("None student has this number!");
		}
	}

	/**
	 * ����һ��ѧ����ϵͳ��
	 * 
	 * @throws IOException
	 */
	public void addStudent() throws IOException {

		stdErr.println("Enter student name>");
		String name = stdIn.readLine();
		stdErr.println("Enteer studentNumber>");
		String studentNumber = stdIn.readLine();
		stdErr.println("Enter telephone>");
		String telephone = stdIn.readLine();
		stdErr.println("Enter qq>");
		String qq = stdIn.readLine();
		students.getStudents().add(
				new Student(name, studentNumber, telephone, qq));
		stdOut.println("Add successfully!");
	}

	/**
	 * ����һ���γ̵�ϵͳ��
	 * 
	 * @throws IOException
	 */
	public void addCourse() throws IOException {

		stdErr
				.println("Enter the type of the course added(optional or required)>");
		String type = stdIn.readLine();
		if (type.equals("optional")) {
			stdErr.println("Enter code>");
			String code = stdIn.readLine();
			stdErr.println("Enter title>");
			String title = stdIn.readLine();
			stdErr.println("Enter time>");
			String time = stdIn.readLine();
			stdErr.println("Enter place>");
			String place = stdIn.readLine();
			courses.getCourses().add(
					new OptionalCourse(code, title, time, place));
		} else {
			stdErr.println("Enter code>");
			String code = stdIn.readLine();
			stdErr.println("Enter title>");
			String title = stdIn.readLine();
			stdErr.println("Enter time>");
			String time = stdIn.readLine();
			stdErr.println("Enter place>");
			String place = stdIn.readLine();
			stdErr.println("Enter credit>");
			int credit = Integer.parseInt(stdIn.readLine());
			courses.getCourses().add(
					new RequiredCourse(code, title, time, place, credit));
		}
		stdOut.println("Add successfully!");
	}

	/**
	 * ��ϵͳ�����û��ṩ����Ŀγ��趨�ο���ʦ
	 * 
	 * @throws IOException
	 */
	public void setTeacherForCourse() throws IOException {

		stdErr.println("Enter the course code>");
		String code = stdIn.readLine();
		stdErr.println("Enter the teacher name code>");
		String name = stdIn.readLine();
		stdErr.println("Enter the teacher id code>");
		String id = stdIn.readLine();
		stdErr.println("Enter the teacher office address code>");
		String address = stdIn.readLine();
		stdErr.println("Enter the teacher telephone code>");
		String telephone = stdIn.readLine();
		stdErr.println("Enter the teacher email code>");
		String email = stdIn.readLine();
		for (Course course : courses.getCourses()) {
			if (course.getCode().equals(code)) {
				course.setTeacher(new Teacher(name, id, address, telephone,
						email));
			}
		}
	}

}
