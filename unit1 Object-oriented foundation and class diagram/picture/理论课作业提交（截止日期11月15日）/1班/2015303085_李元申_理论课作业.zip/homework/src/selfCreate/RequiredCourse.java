/**
 * 
 */
package selfCreate;

/**
 * @author Liyuanshen
 * @version 1.0
 *
 */
public class RequiredCourse extends Course {

	private int credit;

	/**
	 * ����һ�����޿γ̵Ķ���
	 * 
	 * @param code
	 *            �γ̴���
	 * @param title
	 *            �γ�����
	 * @param time
	 *            �Ͽ�ʱ��
	 * @param place
	 *            �Ͽεص�
	 * @param teacher
	 *            �ο���ʦ
	 * @param credit
	 *            �γ�ѧ��
	 */
	public RequiredCourse(String code, String title, String time, String place, Teacher teacher, int credit) {
		super(code, title, time, place, teacher);
		this.credit = credit;
	}

	/**
	 * ����һ�����޿γ̵Ķ���
	 * 
	 * @param code
	 *            �γ̴���
	 * @param title
	 *            �γ�����
	 * @param time
	 *            �Ͽ�ʱ��
	 * @param place
	 *            �Ͽεص�
	 * @param credit
	 *            �γ�ѧ��
	 */
	public RequiredCourse(String code, String title, String time, String place, int credit) {
		super(code, title, time, place);
		this.credit = credit;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see selfCreate.Course#toString()
	 */
	public String toString() {

		if(this.getTeacher() != null) {
			return "RequiredCourse[" + getCode() + "," + getTitle() + "," + getTime() + "," + getPlace() + "," + this.credit + ","
					+ "Teacher" + getTeacher().toString() + "]";
		}else {
			return "RequiredCourse[" + getCode() + "," + getTitle() + "," + getTime() + "," + getPlace() + "," + this.credit + ","
			+ "None teacher" + "]";
		}
	}
}
