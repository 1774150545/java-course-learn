/**
 * 
 */
package selfCreate;

/**
 * @author liyuanshen
 * @version 1.0
 *
 */
public class OptionalCourse extends Course {

	/**
	 * ����һ���µ�ѡ�޿γ̶���
	 * 
	 * @param code
	 *            �γ̴���
	 * @param title
	 *            �γ�����
	 * @param time
	 *            �Ͽ�ʱ��
	 * @param place
	 *            �Ͽεص�
	 * @param teacher
	 *            �ο���ʦ
	 */
	public OptionalCourse(String code, String title, String time, String place, Teacher teacher) {

		super(code, title, time, place, teacher);
	}
	
	/**
	 * ����һ���µ�ѡ�޿γ̶���
	 * 
	 * @param code
	 *            �γ̴���
	 * @param title
	 *            �γ�����
	 * @param time
	 *            �Ͽ�ʱ��
	 * @param place
	 *            �Ͽεص�
	 */
	public OptionalCourse(String code, String title, String time, String place) {

		super(code, title, time, place);
	}
	
	public String toString() {

		if(this.getTeacher() != null) {
			return "OptionalCourse[" + getCode() + "," + getTitle() + "," + getTime() + "," + getPlace() + ","
					+ "Teacher" + getTeacher().toString() + "]";
		}else {
			return "OptionalCourse[" + getCode() + "," + getTitle() + "," + getTime() + "," + getPlace() + ","
					+ "None teacher" + "]";
		}
	}
}
