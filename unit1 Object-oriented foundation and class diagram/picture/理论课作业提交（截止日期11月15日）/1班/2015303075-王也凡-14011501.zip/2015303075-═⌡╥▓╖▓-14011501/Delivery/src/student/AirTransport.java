package student;

import java.io.PrintWriter;

/**
 * 
 * @author wangyefan
 *
 */
public class AirTransport extends Delivery{
	private static PrintWriter stdErr = new PrintWriter(System.err,true);

	private double price;
	
	
/**
 * 构造函数
 * @param sendPerson
 * @param receivePerson
 * @param courierPerson
 * @param information
 */
	public AirTransport(Person sendPerson,Person receivePerson,Person courierPerson,Information information) {
		super(sendPerson,receivePerson,courierPerson,information);
		this.price = computePrice();
		
	}
	
	
/**
 * 这个函数是计算空运的快递价格的
 * 会根据快递的重量来相应调整价格
 * @return price
 */
	public double computePrice()  {
		double weight = this.getInformation().getWeight();
		
		try{
			if(weight < 0)
				throw new DataFormatException("weight is under zero!");
		} catch(DataFormatException dfe) {
			stdErr.println(dfe);
		}
		
		if(weight <= 1){
			price = 15;
		}
		else 
			price = 15+(weight-1)*4;
		
		return price;
	}

	
/**
 * 得到价格
 * @return price
 */
	public double getPrice() {
		return price;
	}
	
	
/**
 * 表达函数
 */
	
	public String toString() {
		return ("sendPerson: "+this.getSendPerson()+"\nreceive: "+this.getReceivePerson()+"\ncourier: "+this.getCourierPerson()
		+"\nprice: "+this.getPrice());
				
	}

}
