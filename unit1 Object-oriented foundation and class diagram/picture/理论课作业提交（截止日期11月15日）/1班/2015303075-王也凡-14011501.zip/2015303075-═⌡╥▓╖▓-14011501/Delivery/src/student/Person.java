package student;

/**
 *这个类一般存放着三个人的信息（寄件人，收件人，快递员）
 * @author Wangyefan
 *
 */
public class Person {
	private String name;
	private String telephone;
	
/**
 * 构造函数
 * @param name
 * @param telephone
 */
	public Person(String name,String telephone) {
		this.name = name;
		this.telephone = telephone;
	}

/**
 * 得到名字
 * @return name
 */
	public String getName() {
		return name;
	}
	
/**
 * 得到电话
 * @return telephone
 */

	public String getTelephone() {
		return telephone;
	}
	
/**
 * 表达函数
 */
	
	public String toString() {
		return ("name: "+this.name+" telephone: "+this.telephone);
	}


}
