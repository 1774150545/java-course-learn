package student;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.*;
/**
 * 这个类为快递的管理系统
 * @author wangyefan
 *
 */
public class DeliverySystem {
	
	private static BufferedReader stdIn = new BufferedReader(
			new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	
	ArrayList<Delivery> deliverys = new ArrayList<Delivery>() ;
	
	
/**
 * 这是关于Delivery的迭代器
 * @return deliverys.iterator()
 */
	public Iterator<Delivery> iterator() {
		return deliverys.iterator();
	}
	
	
/**
 * 往deliverys的数组中添加元素delivery
 * @param delivery
 */
	public void addDelivery(Delivery delivery) {
		deliverys.add(delivery);
	}
	
	
/**
 * 根据收件人的电话移除快递
 * @param telephone
 */
	public void removeDelivery(String telephone) {
		Delivery a = null;
		for(Delivery delivery:deliverys){
			if(delivery.getReceivePerson().getTelephone().equals(telephone)){
				a=delivery;
			}
		}
		deliverys.remove(a);
	}
	
	
/**
 * 展示还剩哪些快递（快递的信息）
 * @return str
 */
	public String displayDelivery() {
		String str = "";
		for(Delivery delivery:deliverys){
			str += delivery.toString() + '\n';
		}
		return str;
	}
	
	
/**
 * 计算还剩多少个快递
 * @return deliverys.size()
 */
	public int numberOfDelivery() {
		return (deliverys.size());
	}
	
	
/**
 * 主函数  实现总任务
 * @param args
 * @throws IOException
 */
	public static void main(String[] args) throws IOException {
		DeliverySystem system = new DeliverySystem();
        system.run();
	}
	
	private void run() throws IOException {
		int choice = getChoice();
		
		while(choice != 0) {
			if(choice == 1) {
				stdOut.println("INPUT YOUR TYPE: (Air/Ground/Urgence)");
				String type = stdIn.readLine();
				if(type.equals("Air")) {
					stdOut.println("Input sender name");
					String senderName = stdIn.readLine();
					stdOut.println("Input sender telephone");
					String senderTelephone = stdIn.readLine();
					Person sender = new Person(senderName,senderTelephone);
					
					stdOut.println("Input receriver name");
					String receiverName = stdIn.readLine();
					stdOut.println("Input receiver telephone");
					String receiverTelephone = stdIn.readLine();
                    Person receiver = new Person(receiverName,receiverTelephone);

                    stdOut.println("Input courier name");
                    String courierName = stdIn.readLine();
                    stdOut.println("Input courier telephone");
                    String courierTelephone = stdIn.readLine();
                    Person courier = new Person(courierName,courierTelephone);

                    stdOut.println("Input the delivery's code");
                    String code = stdIn.readLine();
                    stdOut.println("Input the delivery's weight");
                    Double weight = Double.parseDouble(stdIn.readLine());
                    stdOut.println("Input the delivery's destination");
                    String destination = stdIn.readLine();
                    stdOut.println("Input the delivery's departure");
                    String departure = stdIn.readLine();
                    Information information = new Information(false,code,weight,destination,departure);

                    this.addDelivery(new AirTransport(sender,receiver,courier,information));
				} else if(type.equals("Ground")) {
                    stdOut.println("Input sender name");
                    String senderName = stdIn.readLine();
                    stdOut.println("Input sender telephone");
                    String senderTelephone = stdIn.readLine();
                    Person sender = new Person(senderName,senderTelephone);

                    stdOut.println("Input receriver name");
                    String receiverName = stdIn.readLine();
                    stdOut.println("Input receiver telephone");
                    String receiverTelephone = stdIn.readLine();
                    Person receiver = new Person(receiverName,receiverTelephone);

                    stdOut.println("Input courier name");
                    String courierName = stdIn.readLine();
                    stdOut.println("Input courier telephone");
                    String courierTelephone = stdIn.readLine();
                    Person courier = new Person(courierName,courierTelephone);

                    stdOut.println("Input the delivery's code");
                    String code = stdIn.readLine();
                    stdOut.println("Input the delivery's weight");
                    Double weight = Double.parseDouble(stdIn.readLine());
                    stdOut.println("Input the delivery's destination");
                    String destination = stdIn.readLine();
                    stdOut.println("Input the delivery's departure");
                    String departure = stdIn.readLine();
                    Information information = new Information(false,code,weight,destination,departure);

                    this.addDelivery(new GroundTransport(sender,receiver,courier,information));
                } else if (type.equals("Urgence")) {
                    stdOut.println("Input sender name");
                    String senderName = stdIn.readLine();
                    stdOut.println("Input sender telephone");
                    String senderTelephone = stdIn.readLine();
                    Person sender = new Person(senderName,senderTelephone);

                    stdOut.println("Input receriver name");
                    String receiverName = stdIn.readLine();
                    stdOut.println("Input receiver telephone");
                    String receiverTelephone = stdIn.readLine();
                    Person receiver = new Person(receiverName,receiverTelephone);

                    stdOut.println("Input courier name");
                    String courierName = stdIn.readLine();
                    stdOut.println("Input courier telephone");
                    String courierTelephone = stdIn.readLine();
                    Person courier = new Person(courierName,courierTelephone);

                    stdOut.println("Input the delivery's code");
                    String code = stdIn.readLine();
                    stdOut.println("Input the delivery's weight");
                    Double weight = Double.parseDouble(stdIn.readLine());
                    stdOut.println("Input the delivery's destination");
                    String destination = stdIn.readLine();
                    stdOut.println("Input the delivery's departure");
                    String departure = stdIn.readLine();
                    Information information = new Information(false,code,weight,destination,departure);

                    this.addDelivery(new Urgence(sender,receiver,courier,information));
                }
                stdOut.println("Add Successfully");
			} else if (choice == 2) {
                stdOut.println("Input the delivery's code");
                String code = stdIn.readLine();
                Delivery temp = null;
                for(Delivery delivery:deliverys) {
                    if(delivery.getInformation().getCode().equals(code))
                        temp = delivery;
                }
                if(temp == null)
                    stdOut.println("Don't have this delivery!");
                else {
                    deliverys.remove(temp);
                    stdOut.println("Delete Successfully");
                }
            } else if (choice == 3) {
                for(Delivery delivery:deliverys) {
                    stdOut.println(delivery.toString());
                }
            } else if (choice == 4) {
                stdOut.println(this.numberOfDelivery());
            }
            choice = getChoice();
		}
	}

    /**
     * 得到指令
     * @return
     * @throws IOException
     */
	private static int getChoice() throws IOException{
		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0]  Quit\n" + "[1] Add a delivery\n"
						+ "[2]  Delete a delivery\n"
						+ "[3]  Display deliveries\n"
						+ "[4]  Show the sum of deliveries\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 5 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

}
