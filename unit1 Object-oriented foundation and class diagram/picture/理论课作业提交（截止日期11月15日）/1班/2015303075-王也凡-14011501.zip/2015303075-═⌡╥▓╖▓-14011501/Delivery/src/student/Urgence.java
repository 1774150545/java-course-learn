package student;
import java.io.*;

/**
 * 这个类是加急快递（快递方式的一种）
 * @author wangyefan
 *
 */
public class Urgence extends Delivery{
	private static PrintWriter stdErr = new PrintWriter(System.err,true);

	private double price;
	
	
/**
 * 构造函数
 * @param sendPerson
 * @param receivePerson
 * @param courierPerson
 * @param information
 */
	public Urgence(Person sendPerson,Person receivePerson,Person courierPerson,Information information) {
		super(sendPerson,receivePerson,courierPerson,information);
		this.price = computPrice();
	}
	
	
/**
 * 计算加急快递的运费
 * 会根据快递的重量计算运费
 * @return
 */
	
	public double computPrice()  {
		double weight = this.getInformation().getWeight();
		
		try{
			if(weight < 0)
				throw new DataFormatException("weight is under zero!");
		} catch(DataFormatException dfe) {
			stdErr.println(dfe);
		}
		
		if(weight <= 1){
			price = 20;
		}
		else 
			price = 20+(weight-1)*5;
		
		return price;
	}


/**
 * 得到价格
 * @return price
 */
	public double getPrice() {
		return price;
	}
	
	
/**
 * 表达函数
 */
	public String toString() {
		return ("sendPerson: "+this.getSendPerson()+" receive: "+this.getReceivePerson()+" courier: "+this.getCourierPerson()
		+" price: "+this.getPrice());
				
	}
}
