package student;

import java.io.*;

/**
 * @author Wangyefan
 */
public class TestDeliverySystem {
    /* Standard output stream */
    private static PrintWriter stdOut = new PrintWriter(System.out, true);

    /* Standard error stream */
    private static PrintWriter stdErr = new PrintWriter(System.err, true);

    /**
     * Displays a message in the standard error stream if the value specified by
     * argument <code>condition<code> is <code>false</code>.
     *
     * @param message the error message.
     */
    public static void assertTrue(String message, boolean condition) {

        if (!condition) {
            stdErr.print("** Test failure ");
            stdErr.println(message);
        }
    }

    /**
     * Displays a message in the standard error stream.
     *
     * @param message the error message.
     */
    public static void fail(String message) {

        stdErr.print("** Test failure ");
        stdErr.println(message);
    }

    public static void main(String[] args) {
        stdOut.println("");
        stdOut.println("Testing class DeliverySystem");

        Person person = new Person("test", "133");
        Information information = new Information(false, "1", 20, "xi'an", "beijing");
        Delivery delivery = new Delivery(person, person, person, information);

        DeliverySystem deliverySystem = new DeliverySystem();

        //Testing addDelivery
        deliverySystem.addDelivery(delivery);
        assertTrue("1: testing method addDelivery",deliverySystem.numberOfDelivery() == 1);

        //Testing deleteDelivery
        deliverySystem.removeDelivery("133");
        assertTrue("2: testing method deleteDelivery",deliverySystem.numberOfDelivery() == 0);

        stdOut.println("Done");
    }
}
