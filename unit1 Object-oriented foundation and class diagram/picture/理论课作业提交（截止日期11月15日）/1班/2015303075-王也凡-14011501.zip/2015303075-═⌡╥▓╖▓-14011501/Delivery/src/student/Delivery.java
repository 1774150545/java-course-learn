package student;

/**
 * 此类是快递类，它可以调用快递信息类，也可以调用收件人、寄件人、快递员的信息。
 * @author wangyefan
 *
 */
public class Delivery {
	private Person sendPerson;
	private Person receivePerson;
	private Person courierPerson;
	private Information information;
	
/**
 * 
 * @param sendPerson
 * @param receivePerson
 * @param courierPerson
 * @param information
 */
	public Delivery(Person sendPerson,Person receivePerson,Person courierPerson,Information information) {
		this.sendPerson = sendPerson;
		this.receivePerson = receivePerson;
		this.courierPerson = courierPerson;
		this.information = information;
	}
	
/**
 * 得到sendPerson
 * @return sendPerson
 */
	
	public Person getSendPerson() {
		return sendPerson;
	}

/**
 * 得到receivePerson
 * @return receivePerson
 */

	public Person getReceivePerson() {
		return receivePerson;
	}

/**
 * 得到courierPerson
 * @return courierPerson
 */

	public Person getCourierPerson() {
		return courierPerson;
	}
	
/**
 * 得到information
 * @return information
 */


	public Information getInformation() {
		return information;
	}

/**
 * 表达函数
 */
	
	public String toString() {
		return("sendPerson"+sendPerson+"receivePeron"+receivePerson+"courierPerson"+courierPerson+"information"+information);
	}

}
