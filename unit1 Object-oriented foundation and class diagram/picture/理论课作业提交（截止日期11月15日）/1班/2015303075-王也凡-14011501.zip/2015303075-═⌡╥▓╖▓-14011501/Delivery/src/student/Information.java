package student;

/**
 * 此类是显示快递信息
 * @author wangyefan
 *
 */
public class Information {

	private boolean situation;
	private String code;
	private double weight;
	private String destination;
	private String departure;
	
/**
 * 构造函数
 * @param situation
 * @param code
 * @param weight
 * @param destination
 * @param departure
 */
	public Information(boolean situation,String code,double weight,String destination,String departure) {
		this.situation = situation;
		this.code = code;
		this.weight = weight;
		this.destination = destination;
		this.departure = departure;
	}
	
/**
 * 得到快递的状态
 * @return situation
 */
	public boolean getSituation() {
		return situation;
	}
	
/**
 * 得到快递的号码
 * @return code
 */
	public String getCode() {
		return code;
	}
	
/**
 * 得到快递的重量
 * @return weight
 */
	public double getWeight() {
		return weight;
	}
	
/**
 * 得到快递的目的地
 * @return destination
 */
	
	public String getDestination() {
		return destination;
	}
	
/**
 * 得到快递的出发地
 * @return departure
 */
	public String getDeparture() {
		return departure;
	}
	
/**
 * 表达函数	
 */
	public String toString() {
		return ("situation"+this.situation+"code"+this.code+"weight"+this.weight+"destination"+this.destination+"departure"+this.departure);
	}

}
