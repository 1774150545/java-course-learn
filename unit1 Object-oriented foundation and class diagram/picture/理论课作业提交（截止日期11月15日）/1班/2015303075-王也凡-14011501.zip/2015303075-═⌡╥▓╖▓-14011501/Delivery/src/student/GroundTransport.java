package student;

import java.io.PrintWriter;

/**
 * 这个类是陆运（快递方式的一种）
 * @author wangyefan 
 *
 */
public class GroundTransport extends Delivery{
	private static PrintWriter stdErr = new PrintWriter(System.err,true);

	private double price;
	
/**
 * 构造函数
 * @param sendPerson
 * @param receivePerson
 * @param courierPerson
 * @param information
 */
	public GroundTransport(Person sendPerson,Person receivePerson,Person courierPerson,Information information) {
		super(sendPerson,receivePerson,courierPerson,information);
		this.price = computPrice();
	}
	
/**
 * 这个函数是计算陆运方式的运费
 * @return price
 */
	public double computPrice()  {
		double weight = this.getInformation().getWeight();
		
		try{
			if(weight < 0)
				throw new DataFormatException("weight is under zero!");
		} catch(DataFormatException dfe) {
			stdErr.println(dfe);
		}
		
		if(weight <= 1){
			price = 10;
		}
		else 
			price = 10+(weight-1)*3;
		
		return price;
	}

/**
 * 得到价格
 * @return price
 */
	public double getPrice() {
		return price;
	}
	
/**
 * 表达函数
 */
	
	public String toString() {
		return ("sendPerson: "+this.getSendPerson()+" receive: "+this.getReceivePerson()+" courier: "+this.getCourierPerson()
		+" price: "+this.getPrice());
				
	}
}