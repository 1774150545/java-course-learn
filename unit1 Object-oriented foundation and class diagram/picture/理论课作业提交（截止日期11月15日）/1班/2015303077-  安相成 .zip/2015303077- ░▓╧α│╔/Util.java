package aq;

public class Util
{

	public static void main(String[] args){
	
		Person lzq =new Person();

		
	
		Birthday b = new Birthday();

		b.setYear(2011);
	
		lzq.setBirth(b);

		if(isLeapYear(lzq)){
			System.out.println("������");
		}else{
			System.out.println("��������");
		}
	}

	public static boolean isLeapYear(Person p){
	
		Birthday birth = p.getBirth();
		int year = birth.getYear();
		
		boolean flag = false;

		if((year%100)==0){
		
			if((year%400)==0){
				flag = true;
			}
			else{
			
				flag = false;
			}
		}else{
		
			if((year%4)==0){
				flag = true;
			}else{
				flag = false;
			}
		
		}


		return flag;
	
	}
};