package aq;

public class Man {

}
