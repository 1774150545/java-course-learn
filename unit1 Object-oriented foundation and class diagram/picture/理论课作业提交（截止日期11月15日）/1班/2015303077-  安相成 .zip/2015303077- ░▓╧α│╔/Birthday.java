package aq;

public class Birthday
{

	int year;
	int mounth;
	int day;

	public void setYear(int year){
	
		this.year = year;
	}

	public int getYear(){
	
		return this.year;
	}
};