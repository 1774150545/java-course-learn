package aq;

public class Person
{

	int age;
	String name;


	Birthday birth;


	public void setBirth(Birthday b){
	
		this.birth = b;
	}

	public Birthday getBirth(){
	
		return this.birth;
	
	}
};