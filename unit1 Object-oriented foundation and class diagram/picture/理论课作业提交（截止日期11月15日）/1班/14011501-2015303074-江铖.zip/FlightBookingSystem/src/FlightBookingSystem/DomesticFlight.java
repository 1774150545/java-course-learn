/**
 * 
 */
package FlightBookingSystem;

/**
 * @author ����
 *
 */
public class DomesticFlight extends Flight {

	private String food;

	/**
	 * @param flightNumber
	 * @param destination
	 * @param departure
	 * @param price
	 * @param schedule
	 * @param food
	 */
	public DomesticFlight(String flightNumber, String destination,
			String departure, double price, String schedule, String food) {
		super(flightNumber, destination, departure, price, schedule);
		this.food = food;
	}
	
	
}
