/**
 * 
 */
package FlightBookingSystem;

import java.util.ArrayList;

/**
 * @author ����
 *
 */
public class Passenger {

	private String name;
	private int age;
	private String iD;
	private String telephone;
	private ArrayList<Flight> flights = new ArrayList<Flight>() ;
	
	/**
	 * @param name
	 * @param age
	 * @param iD
	 * @param telephone
	 */
	public Passenger(String name, int age, String iD, String telephone) {
		super();
		this.name = name;
		this.age = age;
		this.iD = iD;
		this.telephone = telephone;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return the iD
	 */
	public String getiD() {
		return iD;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setiD(String iD) {
		this.iD = iD;
	}

	/**
	 * @return the telephone
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * @param telephone the telephone to set
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 * @return the flights
	 */
	public ArrayList<Flight> getFlights() {
		return flights;
	}

	
	
	
}
