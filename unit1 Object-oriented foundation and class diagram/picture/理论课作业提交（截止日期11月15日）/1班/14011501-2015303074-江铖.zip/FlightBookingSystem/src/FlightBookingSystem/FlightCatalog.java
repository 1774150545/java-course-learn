/**
 * 
 */
package FlightBookingSystem;

import java.util.ArrayList;

/**
 * @author ����
 *
 */
public class FlightCatalog {

	private ArrayList<Flight> flights = new ArrayList<Flight>();
}
