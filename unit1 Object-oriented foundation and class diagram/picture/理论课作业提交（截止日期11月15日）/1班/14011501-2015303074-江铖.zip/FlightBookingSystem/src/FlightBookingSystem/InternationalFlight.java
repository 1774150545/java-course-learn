/**
 * 
 */
package FlightBookingSystem;

/**
 * @author ����
 *
 */
public class InternationalFlight extends Flight {

	private double tax;

	/**
	 * @param flightNumber
	 * @param destination
	 * @param departure
	 * @param price
	 * @param schedule
	 * @param tax
	 */
	public InternationalFlight(String flightNumber, String destination,
			String departure, double price, String schedule, double tax) {
		super(flightNumber, destination, departure, price, schedule);
		this.tax = tax;
	}
	
	
}
