/**
 * 
 */
package FlightBookingSystem;

/**
 * @author ����
 *
 */
public class FlightBookingSystem {

	private FlightCatalog catalog;
	
}
