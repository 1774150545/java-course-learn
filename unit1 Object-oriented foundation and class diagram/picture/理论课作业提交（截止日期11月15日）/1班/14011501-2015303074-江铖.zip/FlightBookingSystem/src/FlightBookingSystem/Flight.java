/**
 * 
 */
package FlightBookingSystem;

import java.util.ArrayList;

/**
 * @author ����
 *
 */
public class Flight {

	private ArrayList<Discount> discounts = new ArrayList<Discount>() ;
	private String flightNumber;
	private String destination;
	private String departure;
	private double price;
	private String schedule;
	private int seats;
	private ArrayList<Passenger> passenger = new ArrayList<Passenger>();
	/**
	 * @param flightNumber
	 * @param destination
	 * @param departure
	 * @param price
	 * @param schedule
	 */
	public Flight(String flightNumber, String destination, String departure,
			double price, String schedule) {
		super();
		this.flightNumber = flightNumber;
		this.destination = destination;
		this.departure = departure;
		this.price = price;
		this.schedule = schedule;
	}
	
	
}
