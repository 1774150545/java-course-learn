/**
 * 
 */
package FlightBookingSystem;

/**
 * @author ����
 *
 */
public class Discount {

	private String agencyName;
	private double discount;
	private double total;
	/**
	 * @param agencyName
	 * @param discount
	 * @param total
	 */
	public Discount(String agencyName, double discount, double total) {
		super();
		this.agencyName = agencyName;
		this.discount = discount;
		this.total = total;
	}
	
	
}
