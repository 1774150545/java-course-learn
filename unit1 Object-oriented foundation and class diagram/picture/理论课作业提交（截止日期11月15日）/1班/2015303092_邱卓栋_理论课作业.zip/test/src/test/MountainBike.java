package test;

public class MountainBike extends Bike{
	
	/**
	 * ����ٶ�
	 */
	private double speed;

	/**
	 * @return the speed
	 */
	public double getSpeed() {
		return speed;
	}

	/**
	 * @param speed the speed to set
	 */
	public void setSpeed(double speed) {
		this.speed = speed;
	}

	/**
	 * @param name
	 * @param id
	 * @param cost
	 */
	public MountainBike(String name, int id, double cost, double profit, double speed) {
		super(name, id, cost, profit);
		this.speed = speed;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MountainBike [" + this.getName() + ", id=" + this.getId() + ", cost=" + this.getCost() + ", profit=" + this.getProfit() + ", speed=" + this.getSpeed() + "]";
	}
	
}
