package test;

public class LeisureBike extends Bike{
	/**
	 * ���г��ķ��
	 */
	private String style;

	/**
	 * @return the style
	 */
	public String getStyle() {
		return style;
	}

	/**
	 * @param style the style to set
	 */
	public void setStyle(String style) {
		this.style = style;
	}

	/**
	 * @param name
	 * @param id
	 * @param cost
	 */
	public LeisureBike(String name, int id, double cost, double profit, String style) {
		super(name, id, cost, profit);
		this.style = style;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LeisureBike [" + this.getName() + ", id=" + this.getId()
		+ ", cost=" + this.getCost() + ", profit=" + this.getProfit() 
		+ ", style=" + this.getStyle() + "]";
	}
}
