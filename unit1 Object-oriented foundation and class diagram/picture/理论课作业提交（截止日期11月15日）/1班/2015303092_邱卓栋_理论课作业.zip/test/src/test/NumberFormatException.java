package test;

public class NumberFormatException extends Exception{

	/**
	 * 
	 */
	public NumberFormatException() {
	}

	/**
	 * @param message
	 */
	public NumberFormatException(String message) {
		super(message);
	}
}
