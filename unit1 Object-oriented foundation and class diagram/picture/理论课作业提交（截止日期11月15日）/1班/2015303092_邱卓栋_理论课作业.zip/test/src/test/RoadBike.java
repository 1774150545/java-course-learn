package test;

public class RoadBike extends Bike{
	/**
	 * ���ٵ�λ
	 */
	private int transmission;

	/**
	 * @return the transmission
	 */
	public int getTransmission() {
		return transmission;
	}

	/**
	 * @param biansu the transmission to set
	 */
	public void setTransmission(int transmission) {
		this.transmission = transmission;
	}

	/**
	 * @param name
	 * @param id
	 * @param cost
	 */
	public RoadBike(String name, int id, double cost, double profit, int transmission) {
		super(name, id, cost, profit);
		this.transmission = transmission;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RoadBike [" + this.getName() + ", id=" + this.getId() + ", cost=" + this.getCost() + ", profit=" + this.getProfit() + ", transmission=" + this.getTransmission() + "]";
	}
}
