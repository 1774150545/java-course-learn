package test;

public class BikeFormatException extends Exception{
	/**
	 * Constructs a <code>DataFormatException</code> with no detail message.
	 */
	public BikeFormatException() {
		
	}

	/**
	 * Constructs a <code>DataFormatException</code> with the specified detail
	 * message.
	 * 
	 * @param message
	 *            the malformed data
	 */
	public BikeFormatException(String message) {

		super(message);
	}
}
