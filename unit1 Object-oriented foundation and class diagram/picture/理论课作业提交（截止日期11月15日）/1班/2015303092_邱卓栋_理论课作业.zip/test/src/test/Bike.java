package test;

public class Bike {
	
	/**
	 * name ����
	 * id ���
	 * cost �۸�
	 * profit ����
	 */
	private String name;
	private int id;
	private double cost;
	private double profit;
	
	/**
	 * @return the profit
	 */
	public double getProfit() {
		return profit;
	}

	/**
	 * @param profit the profit to set
	 */
	public void setProfit(double profit) {
		this.profit = profit;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * @return the cost
	 */
	public double getCost() {
		return cost;
	}
	
	/**
	 * @param cost the cost to set
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Bike [name=" + this.getName() + ", id=" + this.getId() 
		+ ", cost=" + this.getCost() + ", profit=" + this.getProfit() + "]";
	}

	/**
	 * @param name
	 * @param id
	 *  cost
	 * @paraml profit
	 */
	public Bike(String name, int id, double cost, double profit) {
		this.name = name;
		this.id = id;
		this.cost = cost;
		this.profit = profit;
	}
}
