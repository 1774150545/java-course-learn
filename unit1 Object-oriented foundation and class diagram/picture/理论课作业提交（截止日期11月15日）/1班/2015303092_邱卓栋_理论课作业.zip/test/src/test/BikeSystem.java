package test;

import java.io.*;
import java.util.*;
import java.lang.NumberFormatException;
import java.lang.String;
import java.util.StringTokenizer;

public class BikeSystem {

	private static BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);

	private BikeShop bikeShop;

	private static final double MIN_COST = 100.0;
	private static final double MAX_COST = 500.0;
	private static final int MIN_NUMBER = 1;
	private static final int MAX_NUMBER = 200;

	public static void main(String[] args) throws IOException, BikeFormatException, NumberFormatException {

		BikeSystem system = new BikeSystem();
		system.run();
	}

	private void run() throws IOException, BikeFormatException, NumberFormatException {

		bikeShop = new BikeShop();

		int choice = getChoice();

		while (choice != 0) {

			if (choice == 1) {
				addModifyBike();
			} else if (choice == 2) {
				stdOut.println("Please enter the ID(int) of the bike.\n");
				bikeShop.removeBike(readID());
			} else if (choice == 3) {
				stdOut.println(bikeShop.toString());
			} else if (choice == 4) {
				stdOut.println("Total Cost: " + bikeShop.getTotalCost());
			} else if (choice == 5) {
				stdOut.println("Total Profit: " + bikeShop.getTotalProfit());
			} else if (choice == 6) {
				writeFile(readFilename(), bikeShop.toString());
			}

			choice = getChoice();
		}
	}

	/**
	 * Modifies the current product: if the specified product is already exist,
	 * it is update; otherwise, the specified product is added.
	 */
	public void addModifyBike() throws IOException {
		stdErr.print("Bike id> \nId should range from 1 to 200.");
		stdErr.flush();
		int id = Integer.parseInt(stdIn.readLine());
		Bike bike = readBike(id);

		if (bike == null) {
			String temp = "";
			Double sellingprice = 0.0d;
			stdErr.println("Now you can add the new one.\nType to choose: LeisureBike, MountainBike, RoadBike.\n");
			stdErr.println("Please input type>");
			String type = stdIn.readLine();
			if (type.equals("LeisureBike")) {
				stdOut.println(
						"Please input name(String), cost(Double), profit(Double), style(String).\nUse \"_\" to devide.");
				String input = stdIn.readLine();
				StringTokenizer tokenizer = new StringTokenizer(input, "_");
				String name = tokenizer.nextToken();
				double cost = Double.parseDouble(tokenizer.nextToken());
				double profit = Double.parseDouble(tokenizer.nextToken());
				String style = tokenizer.nextToken();
				if (id < MIN_NUMBER || id > MAX_NUMBER || cost < MIN_COST || cost > MAX_COST)
					stdOut.println("An Error Message.\n");
				else {
					LeisureBike leisurebike = new LeisureBike(name, id, cost, profit, style);
					this.bikeShop.addBike(leisurebike);
				}
			} else if (type.equals("MountainBike")) {
				stdOut.println(
						"Please input name(String), cost(Double), profit(Double), speed(Double).\nUse \"_\" to devide.");
				String input = stdIn.readLine();
				StringTokenizer tokenizer = new StringTokenizer(input, "_");
				String name = tokenizer.nextToken();
				double cost = Double.parseDouble(tokenizer.nextToken());
				double profit = Double.parseDouble(tokenizer.nextToken());
				double speed = Double.parseDouble(tokenizer.nextToken());
				if (id < MIN_NUMBER || id > MAX_NUMBER || cost < MIN_COST || cost > MAX_COST)
					stdOut.println("An Error Message.\n");
				else {
					MountainBike mountainbike = new MountainBike(name, id, cost, profit, speed);
					this.bikeShop.addBike(mountainbike);
				}
			} else if (type.equals("RoadBike")) {
				stdOut.println(
						"Please input name(String), cost(Double), profit(Double), transmission(Integer).\nUse \"_\" to devide.");
				String input = stdIn.readLine();
				StringTokenizer tokenizer = new StringTokenizer(input, "_");
				String name = tokenizer.nextToken();
				double cost = Double.parseDouble(tokenizer.nextToken());
				double profit = Double.parseDouble(tokenizer.nextToken());
				int transmission = Integer.parseInt(tokenizer.nextToken());
				if (id < MIN_NUMBER || id > MAX_NUMBER || cost < MIN_COST || cost > MAX_COST)
					stdOut.println("An Error Message.\n");
				else {
					RoadBike roadbike = new RoadBike(name, id, cost, profit, transmission);
					this.bikeShop.addBike(roadbike);
				}
			}
		} else {
			stdErr.println("The bike is already exist!");
		}
	}

	/*
	 * Prompts user for a product code and locates the associated
	 * <code>Product</code> object.
	 *
	 * @return reference to the <code>Product</code> object with the specified
	 * code
	 */
	private Bike readBike(int id) throws IOException {

		Bike bike = this.getBikeShop().findBikeById(id);
		if (bike != null) {
			return bike;
		} else {
			stdErr.println("There are no bikes with that code");
			return null;
		}
	}

	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Terminates the program.\n" + "[1] Adds a bike to the bike shop.\n"
						+ "[2] Removes a bike from the bike shop.\n"
						+ "[3] Displays the information of all the bike in bike shop.\n"
						+ "[4] Displays the total cost of all the bike in the shop.\n"
						+ "[5] Displays the total profit of all the bike in the shop.\n"
						+ "[6] Save all the information (Plain Text)\n" + "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 9 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (IOException ioe) {
				stdErr.println(ioe);
			}
		} while (true);

		return input;
	}

	private int readID() throws NumberFormatException, IOException {
		String input;
		do {
			try {
				stdErr.flush();
				input = stdIn.readLine();
				return Integer.parseInt(input);
			} catch (IOException ioe) {
				stdErr.println(ioe);
			}
		} while (true);
	}

	/**
	 * Prompts the user for a filename (the name of the file that will store the
	 * sales information) and returns the user's response.
	 * 
	 * @return name of a file
	 */
	private String readFilename() throws IOException {

		stdErr.print("Filename> ");
		stdErr.flush();

		return stdIn.readLine();
	}

	/**
	 * Creates a new file (which has the specified name) and writes the
	 * specified string to the new file.
	 * 
	 * @param filename
	 *            name of the file that will store the data
	 * @param content
	 *            data to be stored
	 */
	private void writeFile(String filename, String content) throws IOException {
		FileWriter filewriter = new FileWriter(filename);
		filewriter.write(content);
		filewriter.close();
	}

	/**
	 * @return the bikeShop
	 */
	public BikeShop getBikeShop() {
		return bikeShop;
	}

}