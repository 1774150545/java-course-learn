package test;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

public class BikeShop {

	/**
	 * ˽�б���
	 */
	private BikeList cart = new BikeList();

	/**
	 * �޲ι��캯��
	 */
	public BikeShop() {
		
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * ��дtoString()����
	 */
	public String toString() {
		if (this.cart.SizeOfList() == 0)
			return "empty";
		Iterator iterator = this.cart.iterator();
		StringBuffer stringbuffer = new StringBuffer(iterator.next().toString());
		for (; iterator.hasNext(); stringbuffer.append(iterator.next().toString())) {
			stringbuffer.append("\r\n");
		}
		return stringbuffer.toString();
	}

	/**
	 * @return Double
	 * ��ȡ�ܼ۸�
	 */
	public double getTotalCost() {
		double d = 0.0D;
		if (this.cart.SizeOfList() == 0) {
			System.err.println("There is no bike in the cart!");
			return 0.0D;
		}
		for (Iterator iterator = this.cart.iterator(); iterator.hasNext();) {
			d += ((Bike) iterator.next()).getCost();
		}
		return d;
	}

	/**
	 * @param bike
	 * �����Ա�������Ԫ��
	 */
	public void addBike(Bike bike) {
		this.cart.addBike(bike);
		PrintWriter stdOut = new PrintWriter(System.out, true);
		stdOut.println("Add successfully!\n");
	}
	
	
	/**
	 * @param ID
	 * �����Ա����Ƴ�Ԫ��
	 */
	public void removeBike(int ID) {
		Boolean outcome = this.cart.removeBike(ID);
		if (outcome == true)
			System.out.println("Remove Successfully.");
		else 
			System.out.println("The assigned bike dosen't exit");
	}

	/**
	 * @param string
	 * @return Bike
	 * Ѱ��ָ��ID�����г�
	 */
	public Bike findBikeById(int id) {
		Iterator<Bike> iterator = this.cart.iterator();
		while (iterator.hasNext()) {
			Bike next = iterator.next();
			if (next.getId() == id){
				return next;
			}
		}
		return null;
	}

	/**
	 * @return Double
	 * ��������
	 */
	public double getTotalProfit() {
		double d = 0.0D;
		if (this.cart.SizeOfList() == 0) {
			System.err.println("There is no bike in the cart!");
			return 0.0D;
		}
		for (Iterator iterator = this.cart.iterator(); iterator.hasNext();) {
			d += ((Bike) iterator.next()).getProfit();
		}
		return d;
	}
	
	/**
	 * @return BikeList
	 * ����˽�б���
	 */
	public BikeList getBikeList(){
		return this.cart;
	}
}
