/**
 * 
 */
package homework;

/**
 * @author liangyu
 * 
 */
public class Book {
	private String code;
	private String name;
	private double price;
	private int number;
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price
	 *            the price to change
	 */
	public void changePrice(double price) {
		this.price = price;
	}

	/**
	 * @return the number
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * @param number
	 *            the number to change
	 */
	public void changeNumber(int number) {
		this.number = this.number + number;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "Book [code=" + code + ", name=" + name + ", price=" + price
				+ ", number=" + number + "]";
	}
	
	
	/**
	 * @param code
	 * @param name
	 * @param price
	 * @param number
	 */
	public Book(String code, String name, double price, int number) {
		super();
		this.code = code;
		this.name = name;
		this.price = price;
		this.number = number;
	}
}
