/**
 * 
 */
package homework;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;


/**
 * @author liangyu
 *
 */
public class TestBookSystem {
	
	private static BufferedReader stdIn = new BufferedReader(
			new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);
	
	private List list;
	private Sales sales;
	private BuyBook buyBook;
	private BookstoreSystem bookstoreSystem;
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		List list = new List();
		Sales sales = new Sales();
		BuyBook buyBook = new BuyBook();
		BookstoreSystem bookstoreSystem = new BookstoreSystem();
		//initialize the inventory
		Book book1 = new Book("A001", "amazing", 11.1, 5);
		Book book2 = new Book("A002", "abstract", 11.2, 4);
		Book book3 = new Book("A003", "abundant", 11.3, 3);
		list.addBook(book1);
		list.addBook(book2);
		list.addBook(book3);
		
		
		TestBookSystem application = new TestBookSystem();
		
		//
		int choice = application.getChoice();
		
		while (choice != 0) {
			if (choice == 1) {
				System.out.println("input the name of the book >>");
					String name = stdIn.readLine();
				System.out.println("input the number of the book");
					int number = Integer.parseInt(stdIn.readLine());
					bookstoreSystem.saleOneKindOfBook(list, name, number);
					System.out.println(list.getBookInformation(name));
					
			} else if (choice == 2) {
				System.out.println("input the name of the book >>");
				String name = stdIn.readLine();
				System.out.println("input the number of the book");
				int number = Integer.parseInt(stdIn.readLine());
				buyBook.buyOneKindOfBook(list, name, number);
				System.out.println(list.getBookInformation(name));
					
			} else if (choice == 3) {
				System.out.println("input the code of the new book >>");
				String code = stdIn.readLine();
				System.out.println("input the name of the new book >>");
				String name = stdIn.readLine();
				System.out.println("input the price of the new book >>");
				double price = Double.parseDouble(stdIn.readLine());
				System.out.println("input the number of the new book >>");
				int number = Integer.parseInt(stdIn.readLine());
				Book book = new Book(code, name, price, number);
				list.addBook(book);
				System.out.print(list.getBookInformation(name));
			
			} else if (choice == 4) {
				System.out.println("input the name of the book >>");
				String name = stdIn.readLine();
				System.out.println("input the price which you want to change to >>");
				double price = Double.parseDouble(stdIn.readLine());
				for(Book aBook : list){
					if(aBook.getName().equals(name)){
						aBook.changePrice(price);
						System.out.println("the new information of the book >>");
						System.out.println(list.getBookInformation(name));
					}
				}
			} else if (choice == 5) {
				System.out.println("input the name of the book >>");
				String name = stdIn.readLine();
			    System.out.println("input the number of the book");
				int number = Integer.parseInt(stdIn.readLine());
				System.out.println("the income is >>");
				bookstoreSystem.saleOneKindOfBook(list, name, number);
			
				System.out.println(sales.computingIncome(list, name, number));
				
			}else if(choice == 6) {
				System.out.println("intput the name of the book >>");
				
				System.out.println(list.getBookInformation(stdIn.readLine()));
			}
			choice = application.getChoice();
			}
	}
	
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0]  Quit\n" + "[1]  sale one kind of books\n"
						+ "[2]  buy one kind of books\n"
						+ "[3]  add a new book to the inventory\n"
						+ "[4]  change the price for one book\n"
						+ "[5]  compute the income \n"
						+ "[6]  list the inventory a book" + "\n" +"choice>");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 7 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}
}
