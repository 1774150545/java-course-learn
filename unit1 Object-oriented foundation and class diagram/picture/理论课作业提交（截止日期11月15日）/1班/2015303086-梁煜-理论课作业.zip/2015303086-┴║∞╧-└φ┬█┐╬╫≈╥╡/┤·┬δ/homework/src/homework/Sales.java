/**
 * 
 */
package homework;

/**
 * @author liangyu
 *
 */
public class Sales {
	private double income;
	
	//computing the income of all  books saled out
	public double computingIncome(List list, String name, int number){
		for(Book aBook : list){
			if(aBook.getName().equals(name)){
				income += aBook.getPrice() * number;
			}
		}
		return income;
	}
	
}
