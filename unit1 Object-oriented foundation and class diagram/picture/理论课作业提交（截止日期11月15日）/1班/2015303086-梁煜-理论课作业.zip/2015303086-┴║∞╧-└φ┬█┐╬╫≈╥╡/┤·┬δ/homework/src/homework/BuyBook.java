/**
 * 
 */
package homework;

/**
 * @author liangyu
 *
 */
public class BuyBook {
	private double outcome = 0;
	
	//buy one kind of book
	public void buyOneKindOfBook(List list, String name, int number){
		for(Book aBook : list){
			if(aBook.getName().equals(name)){
				aBook.changeNumber(number);
			}
		}
	}
	
	//computing the outcome of books buried in
	public double computingOutcome(List list, String name, int number){
		for(Book aBook : list){
			if(aBook.getName().equals(name)){
				outcome += aBook.getPrice() * number; 
			}
		}
		return outcome;
	}
}
