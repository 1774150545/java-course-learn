/**
 * 
 */
package homework;

import java.util.ArrayList;
import java.util.Iterator;
/**
 * @author liangyu
 *
 */
public class List implements Iterable<Book>{
	private ArrayList<Book> books = new ArrayList<Book>();
	
	//add books to the inventory
	public void addBook(Book book){
		books.add(book);
	}
	
	//remove books from the inventory
	public boolean removeBook (String name) {
		boolean a = false;
		for(int i = 0; i < books.size(); i++){
			if(books.get(i).getName().equals(name)){
				books.remove(i);
				a = true;
			}
		}
		return a;
	}
	
	//get number of books
	public int getNumberOfBook(){
		return books.size();
	}
	
	//get information of books
	public String getBookInformation(String name){
		String aString = "we do not have this book.";
		for(Book aBook : books){
			if(aBook.getName().equals(name)){
				aString = aBook.toString();
				return aString;
			}
		}
		return aString;
	}
	/* (non-Javadoc)
	 * @see java.lang.Iterable#iterator()
	 */
	@Override
	public Iterator<Book> iterator() {
		// TODO Auto-generated method stub
		Iterator<Book> eIterator  = books.iterator();
		return eIterator;
	}
	
}
