/**
 * 
 */
package homework;

/**
 * @author liangyu
 *
 */
public class BookstoreSystem {
	
	private double total = 0;
	
	public double getIncome(){
		
		return total;
	}
	//sale one kind of book
	public void saleOneKindOfBook(List list, String name, int number){
		for(Book aBook : list){
			if(aBook.getName().equals(name)){
				aBook.changeNumber((-number));
			}
		}
	}
}
