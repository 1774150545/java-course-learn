/**
 * 
 */
package FlightBookingSystem;

/**
 * @author ����
 *
 */
public class DomesticFlight extends Flight {

	private String food;

	

	/**
	 * @param flightNumber
	 * @param destination
	 * @param departure
	 * @param price
	 * @param schedule
	 * @param seats
	 * @param food
	 */
	public DomesticFlight(String flightNumber, String destination,
			String departure, double price, String schedule, int seats,
			String food) {
		super(flightNumber, destination, departure, price, schedule, seats);
		this.food = food;
	}



	/**
	 * @return the food
	 * food��ʾ�Ƿ��в�ʳ
	 * foodֵΪYes ���� No
	 */
	public String getFood() {
		return food;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DomesticFlight [ "+"toString()="+ super.toString() +",  Food()=" + getFood()+"]";
	}



	

	

	
	
}
