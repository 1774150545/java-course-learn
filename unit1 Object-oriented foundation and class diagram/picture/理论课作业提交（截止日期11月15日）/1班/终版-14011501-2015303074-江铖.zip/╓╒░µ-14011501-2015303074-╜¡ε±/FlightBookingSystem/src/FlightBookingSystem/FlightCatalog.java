/**
 * 
 */
package FlightBookingSystem;

import java.util.ArrayList;

/**
 * @author ����
 *
 */
public class FlightCatalog {

	private ArrayList<Flight> flights = new ArrayList<Flight>();
	private Flight flight;

	/**
	 * �޲ι��캯��
	 */
	public FlightCatalog() {
		super();
	}
		
	

	/**
	 * @param flight
	 */
	public FlightCatalog(Flight flight) {
		super();
		this.flight = flight;
	}



	/**
	 * @return the flights
	 */
	public ArrayList<Flight> getFlights() {
		return flights;
	}
	
	public Flight getFlight() {
		return flight;
	}
	
	public void displayFlight () {
		for (Flight airline : flights) {
			System.out.println(airline.toString());
			for (Discount discount : this.flight.getDiscounts()) {
				System.out.println(discount.toString());
			}
		}
	}
	
	
	
}
