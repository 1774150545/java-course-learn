/**
 * 
 */
package FlightBookingSystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * @author ����
 *
 */
public class FlightBookingSystem {

	private static BufferedReader stdIn = new BufferedReader(
			new InputStreamReader(System.in));
	private static PrintWriter stdOut = new PrintWriter(System.out, true);
	private static PrintWriter stdErr = new PrintWriter(System.err, true);

	private FlightCatalog catalog;
	private ArrayList<Passenger> passenger = new ArrayList<Passenger>();

	public static void main(String[] args) throws IOException,
			InterruptedException {
		FlightBookingSystem application = new FlightBookingSystem();
		application.run();
	}

	private FlightBookingSystem() {
		this.catalog = loadCatalog();
		this.passenger = loadPassenger();
	}

	private ArrayList<Passenger> loadPassenger() {

		ArrayList<Passenger> passenger = new ArrayList<Passenger>();

		passenger.add(new Passenger("����", 19, "562210199712241256", "6865324"));
		passenger.add(new Passenger("��һ",16,"412568200003254589","4562358"));
		passenger.add(new Passenger("����",18,"410000199805061456","8896254"));
		passenger.add(new Passenger("����",20,"530021199606122356","4512896"));
		passenger.add(new Passenger("�Ծ�", 21, "523512199502162356", "2158669"));
		passenger.add(new Passenger("����", 26, "110123199008315236", "4125663"));
		passenger.add(new Passenger("����", 22, "145230199403254515", "4562385"));
		passenger.add(new Passenger("��ʮһ", 23, "524812199311261425", "7845145"));
		passenger.add(new Passenger("��ʮ��", 30, "23654519860913", "1256456"));
		passenger.add(new Passenger("Ǯ��", 46, "562345197005038956", "4525312"));
		
		
		return passenger;
	}

	private FlightCatalog loadCatalog() {

		FlightCatalog catalog = new FlightCatalog();

		InternationalFlight internationalFlight1 = new InternationalFlight("CZ3351", "CAN", "AAT", 2300, "14:00~18:20", 235, 230.6);
		Flight flight1 = internationalFlight1;
		InternationalFlight internationalFlight2 = new InternationalFlight("CA5963", "ELF", "AKT", 1400, "18:10~19:50", 335, 350.8);
		Flight flight2 = internationalFlight2;
		InternationalFlight internationalFlight3 = new InternationalFlight("MU1425", "CIH", "GUR", 3500, "13:05~18:25", 256, 145.9);
		Flight flight3 = internationalFlight3;
		InternationalFlight internationalFlight4 = new InternationalFlight("HU2526", "JGS", "BNN", 3600, "21:45~23:50", 256, 562.4);
		Flight flight4 = internationalFlight4;
		InternationalFlight internationalFlight5 = new InternationalFlight("OH3325", "CYS", "KCL", 2800, "16:15~19:40", 328, 358.7);
		Flight flight5 = internationalFlight5;
		
		DomesticFlight DomesticFlight1 = new DomesticFlight("ZH7706", "CSX", "CTU", 2400, "05:30~08:10", 423, "Yes");
		Flight flight6 = DomesticFlight1;
		DomesticFlight DomesticFlight2 = new DomesticFlight("FM3526", "DLC", "DYG", 1600, "09:00~12:05", 157, "No");
		Flight flight7 = DomesticFlight2;
		DomesticFlight DomesticFlight3 = new DomesticFlight("SC1203", "GOQ", "FOC", 1000, "10:10~14:05", 256, "Yes");
		Flight flight8 = DomesticFlight3;
		
		
		return catalog;
	}

	
	/*
	 * Presents the user with a menu of options and executes the selected task.
	 */
	private void run() throws IOException {

		int choice = getChoice();

		while (choice != 0) {
			if (choice == 1) {
				displayCatalog();
			} else if (choice == 2) {
				findFlightByNumber();
			} else if (choice == 3) {
				findFlightByPlace();
			} else if (choice == 4) {
				addPassenger();
			} else if (choice == 5) {
				bookingFlight();
			}
			choice = getChoice();
		}
	}

	/*
	 * Displays a menu of options and verifies the user's choice.
	 * 
	 * @return an integer in the range [0,7]
	 */
	private int getChoice() throws IOException {

		int input;

		do {
			try {
				stdErr.println();
				stdErr.print("[0] Quit\n" 
				+ "[1] Display fight catalog\n"
						+ "[2] Find flight by number\n"
						+ "[3] Find flight by place\n" 
						+ "[4] Add passenger\n"
						+ "[5] Booking flight\n" 
						+ "choice> ");
				stdErr.flush();

				input = Integer.parseInt(stdIn.readLine());

				stdErr.println();

				if (0 <= input && 9 >= input) {
					break;
				} else {
					stdErr.println("Invalid choice:  " + input);
				}
			} catch (NumberFormatException nfe) {
				stdErr.println(nfe);
			}
		} while (true);

		return input;
	}

	// ѡ��1
	/**
	 * Displays flight catalog.
	 */
	public void displayCatalog() {

		int size = this.catalog.getFlights().size();

		if (size == 0) {
			stdErr.println("The catalog is empty");
		} else {
			this.catalog.displayFlight();
		}

	}

	// ѡ��2
	/**
	 * Find flight by number
	 * @throws IOException 
	 */
	public void findFlightByNumber() throws IOException {

		
		stdErr.println("Please input the flight number");
		String number = stdIn.readLine();
		
		for (Flight airline : this.catalog.getFlights()) {
			if (this.catalog.getFlight().getFlightNumber().equals(number)) {
				stdOut.println(airline.toString());
			}
		}
		run();
	}

	
	
	// ѡ��3
	/**
	 * Find flight by place
	 * @throws IOException 
	 */
	public void findFlightByPlace() throws IOException {
		stdErr.println("Please input the departure place");
		String departure = stdIn.readLine();
		stdErr.println("Please input the destination");
		String destination = stdIn.readLine();
		
		for (Flight airline : this.catalog.getFlights()) {
			if ((this.catalog.getFlight().getDeparture().equals(departure))||(this.catalog.getFlight().getDestination().equals(destination))) {
				stdOut.println(airline.toString());
			}
		}
		run();
	}
	

	// ѡ��4
	/**
	 * Modifies the current passenger: if the specified passenger is already
	 * exist, it is update; otherwise, the specified passenger is added.
	 */
	public void addPassenger() throws IOException {
		Passenger passenger = readPassenger();

		if (passenger == null) {
			Passenger tempPassenger = new Passenger();
			String temp = "";

			stdErr.println("Now, please add the new passenger");
			stdErr.println("please input name>");
			tempPassenger.setName(stdIn.readLine());
			stdErr.println("please input age>");
			tempPassenger.setAge(Integer.parseInt(stdIn.readLine()));
			stdErr.println("please input ID>");
			tempPassenger.setiD(stdIn.readLine());
			stdErr.println("please input telephone>");
			tempPassenger.setTelephone(stdIn.readLine());

			this.passenger.add(tempPassenger);
			System.out.println("Add Passenger Successful!");
		} else {
			stdErr.println("This passenger is already exist");
		}
		run();
	}

	protected Passenger findPassengerByID(String iD) {
		for (Passenger people : passenger) {
			if (people.getiD().equals(iD)) {
				return people;
			}
		}
		return null;
	}

	private Passenger readPassenger() throws IOException {

		stdErr.print("Passenger ID>");
		stdErr.flush();

		Passenger passenger = findPassengerByID(stdIn.readLine());

		if (passenger != null) {
			return passenger;
		} else {
			stdErr.println("Cannot find the corresponding passenger");
			return null;
		}
	}



	// ѡ��5
	/**
	 * Booking flight
	 * @throws IOException 
	 */
	public void bookingFlight() throws IOException {
		
		stdErr.println("Please input the flight number");
		String number = stdIn.readLine();
		Flight plane = null;
		for (Flight airline : this.catalog.getFlights()) {
			if (this.catalog.getFlight().getFlightNumber().equals(number)) {
				stdOut.println(airline.toString());
				plane = airline;
			}
		}

		stdErr.println("Please input the passenger ID");
		String ID = stdIn.readLine();
		
		for (Passenger people : passenger) {
			if (people.getiD().equals(ID)) {
				people.addBookedFlights(plane);
				this.catalog.getFlight().setSeats();
			}
		}
		
		run();

	}

	

}
