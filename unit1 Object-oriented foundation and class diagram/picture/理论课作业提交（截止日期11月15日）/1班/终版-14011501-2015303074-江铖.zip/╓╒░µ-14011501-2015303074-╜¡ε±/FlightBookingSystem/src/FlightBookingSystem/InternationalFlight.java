/**
 * 
 */
package FlightBookingSystem;

/**
 * @author ����
 *
 */
public class InternationalFlight extends Flight {

	private double tax;

	/**
	 * @param flightNumber
	 * @param destination
	 * @param departure
	 * @param price
	 * @param schedule
	 * @param seats
	 * @param tax
	 */
	public InternationalFlight(String flightNumber, String destination,
			String departure, double price, String schedule, int seats,
			double tax) {
		super(flightNumber, destination, departure, price, schedule, seats);
		this.tax = tax;
	}

	/**
	 * @return the tax
	 */
	public double getTax() {
		return tax;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InternationalFlight [ "+"toString()="
				+ super.toString() + ", getTax()=" + getTax() + "]";
	}

	

	
	
	
}
