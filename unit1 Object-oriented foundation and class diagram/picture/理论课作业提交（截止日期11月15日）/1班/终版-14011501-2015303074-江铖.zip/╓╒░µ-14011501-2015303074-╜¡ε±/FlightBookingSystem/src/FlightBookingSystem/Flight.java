/**
 * 
 */
package FlightBookingSystem;

import java.util.ArrayList;

/**
 * @author ����
 *
 */
public class Flight {

	private ArrayList<Discount> discounts = new ArrayList<Discount>() ;
	private ArrayList<Passenger> passenger = new ArrayList<Passenger>();
	private String flightNumber;
	private String destination;
	private String departure;
	private double price;
	private String schedule;
	private int seats;
	
	

	/**
	 * �޲ι��캯��
	 */
	public Flight() {
		super();
	}



	/**
	 * @param flightNumber
	 * @param destination
	 * @param departure
	 * @param price
	 * @param schedule
	 * @param seats
	 */
	public Flight(String flightNumber, String destination, String departure,
			double price, String schedule, int seats) {
		super();
		this.flightNumber = flightNumber;
		this.destination = destination;
		this.departure = departure;
		this.price = price;
		this.schedule = schedule;
		this.seats = seats;
	}



	/**
	 * @return the discounts
	 */
	public ArrayList<Discount> getDiscounts() {
		return discounts;
	}

	/**
	 * @return the flightNumber
	 */
	public String getFlightNumber() {
		return flightNumber;
	}

	/**
	 * @return the destination
	 */
	public String getDestination() {
		return destination;
	}


	/**
	 * @return the departure
	 */
	public String getDeparture() {
		return departure;
	}


	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}


	/**
	 * @return the schedule
	 */
	public String getSchedule() {
		return schedule;
	}


	/**
	 * @return the seats
	 */
	public int getSeats() {
		return seats;
	}


	

	/**
	 * @param ���Ŀ�ʹ����λ����
	 */
	public void setSeats() {
		this.seats = seats--;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Flight [FlightNumber()=" + getFlightNumber()
				+ ", Destination()=" + getDestination()
				+ ", Departure()=" + getDeparture() + ", Price()="
				+ getPrice() + ", Schedule()=" + getSchedule()
				+ ", Seats()=" + getSeats() + "]";
	}


	
	
	
	
	
}
